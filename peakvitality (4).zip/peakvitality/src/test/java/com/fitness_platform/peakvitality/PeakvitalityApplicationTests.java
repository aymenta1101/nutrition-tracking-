package com.fitness_platform.peakvitality;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeakvitalityApplicationTests {

	@Test
	void contextLoads() {
	}

}
