package com.fitness_platform.peakvitality.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Data // Lombok generates getters and setters
@NoArgsConstructor
@AllArgsConstructor
public class CalorieEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;

    private int calories;

    private LocalDate date;  //Change for test 6
}