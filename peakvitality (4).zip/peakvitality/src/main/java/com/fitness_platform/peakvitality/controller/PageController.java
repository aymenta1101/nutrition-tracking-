package com.fitness_platform.peakvitality.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;



@Controller
public class PageController 
{

    @GetMapping("/login")
    public String login() 
    {
        return "login";
    }

    @GetMapping("/bmi-calculator")
    public String bmiCalculator() 
    {
        return "bmi-calculator";
    }

    @GetMapping("/")
    public String home() 
    {
        return "home";
    }

    @GetMapping("/home")
    public String homepage() 
    {
        return "home";
    }

    @GetMapping("/dashboard")
    public String dashBoard() 
    {
        return "index";
    }

    @GetMapping("/hydration-tool")
    public String HydrationTool()
    {
        return "hydration-tool";
    }

    @GetMapping("/calorie-tracker")
    public String CalorieTracker()
    {
        return "calorie-tracker";
    }

    @GetMapping("/surveys")
    public String Surveys()
    {
        return "surveys";
    }

    @GetMapping("/create-habit")
    public String Habit()
    {
        return "create-habit";
    } 
}
