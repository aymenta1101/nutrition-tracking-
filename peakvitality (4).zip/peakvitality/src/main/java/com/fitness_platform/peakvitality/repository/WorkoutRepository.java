package com.fitness_platform.peakvitality.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.fitness_platform.peakvitality.model.WorkoutTool;
public interface WorkoutRepository extends JpaRepository<WorkoutTool, Long> {
}
