package com.fitness_platform.peakvitality.model;

import java.util.List;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
//recipe entity used for meal plan generation
@Entity //persist data in a table
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "recipes")
public class Recipe {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long recipeId;
    //primary key for each recipe


//recipe name and description
    @NotBlank
    private String recipeName;
    @NotBlank
    private String recipeDescription;
    @NotBlank
    private String recipeInstructions;
//which category the food/snack fits into (in relation to form submission)
    private String macroCategory;
    @Min(1)
    private int calories;
    @Min(0)
    private int protein;
    @Min(0)
    private int fats;
    @Min(0)
    private int carbs;

    private String mealType;
    //field to indicate if meal or snack
    
//calorie + macro information
    @ElementCollection
    private List<String> DietaryTags;
//list of dietary requirements satisfied by each recipe, stored in a separate JOIN table linked by the recipeId
    

    

    //link recipes uploaded to users
     @ManyToOne
     @JoinColumn(name = "user_id")
     private User user;
}
