package com.fitness_platform.peakvitality.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
//daily plan class, used as a utility to create daily plan objects in creation of a weekly diet plan (which is stored as a List<DailyPlan> object)
public class DailyPlan {
    private List<Recipe> recipes; //store a list of all recipes in a days plan
    private int totalCalories; //store total calories in a days plan
    private int totalProtein;
    private int totalCarbs;
    private int totalFats; //store macro values within the days plan
    
}
