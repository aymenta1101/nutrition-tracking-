package com.fitness_platform.peakvitality.controller;

import org.springframework.web.bind.annotation.*;

import com.fitness_platform.peakvitality.model.WorkoutTool;
import com.fitness_platform.peakvitality.service.WorkoutService;

import java.util.List;

@RestController
@RequestMapping("/api/workouts")
@CrossOrigin("*") // Allows frontend requests
public class WorkoutController {
    private final WorkoutService service;

    public WorkoutController(WorkoutService service) {
        this.service = service;
    }

    @PostMapping("/save")
    public WorkoutTool saveWorkout(@RequestBody WorkoutTool workout) {
        return service.saveWorkout(workout);
    }

    @GetMapping("/all")
    public List<WorkoutTool> getAllWorkouts() {
        return service.getAllWorkouts();
    }
}
