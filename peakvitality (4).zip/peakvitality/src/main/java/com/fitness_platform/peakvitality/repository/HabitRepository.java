package com.fitness_platform.peakvitality.repository;

import com.fitness_platform.peakvitality.model.Habit;
import com.fitness_platform.peakvitality.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface HabitRepository extends JpaRepository<Habit, Long> {
    List<Habit> findByUser(User user);
    void deleteByUser(User user);
    void deleteById(Long id);
    List<Habit> findByUserAndHabitName(User user, String habitName);
    Optional<Habit> findByUserIdAndHabitName(Long userId, String habitName);
}
