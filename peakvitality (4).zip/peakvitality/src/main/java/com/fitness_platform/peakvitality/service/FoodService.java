package com.fitness_platform.peakvitality.service;

import com.fitness_platform.peakvitality.model.Food;
import com.fitness_platform.peakvitality.model.FoodEntry;
import com.fitness_platform.peakvitality.model.User;
import com.fitness_platform.peakvitality.repository.FoodEntryRepository;
import com.fitness_platform.peakvitality.repository.FoodRepository;
import com.fitness_platform.peakvitality.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class FoodService {

    @Autowired
    private FoodRepository foodRepository;

    @Autowired
    private FoodEntryRepository foodEntryRepository;

    @Autowired
    private UserRepository userRepository;

    public List<Food> getAllFoods() {

        List<Food> foods = foodRepository.findAll();
        if (foods.isEmpty()) {
            Food food = new Food();
            food.setName("Chicken Breast");
            food.setProtein(31.0);
            food.setCarbs(0.0);
            food.setFats(3.6);
            foodRepository.save(food);
            foods.add(food);


            food = new Food();
            food.setName("Brown Rice");
            food.setProtein(2.6);
            food.setCarbs(23.0);
            food.setFats(0.9);
            foodRepository.save(food);
            foods.add(food);


            food = new Food();
            food.setName("Avocado");
            food.setProtein(2.0);
            food.setCarbs(8.5);
            food.setFats(15.0);
            foodRepository.save(food);
            foods.add(food);
        }
        return foods;
    }

    public void addFoodEntry(Long foodId, double quantity) {
        try {
            Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            String username = "";
            if (principal instanceof UserDetails) {
                username = ((UserDetails) principal).getUsername();
            } else {
                username = principal.toString();
            }
            User user = userRepository.findByUsername(username).orElseThrow();
            Food food = foodRepository.findById(foodId).orElseThrow();

            FoodEntry entry = new FoodEntry();
            entry.setUser(user);
            entry.setFood(food);
            entry.setQuantity(quantity);
            entry.setDate(LocalDate.now());

            // Calculate macros based on quantity
            double factor = quantity / 100.0;
            entry.setProtein(food.getProtein() * factor);
            entry.setCarbs(food.getCarbs() * factor);
            entry.setFats(food.getFats() * factor);

            foodEntryRepository.save(entry);
        }catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error adding food entry: " + e.getMessage());
        }
    }

    public List<FoodEntry> getWeeklyEntries() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = "";
        if (principal instanceof UserDetails) {
            username = ((UserDetails) principal).getUsername();
        } else {
            username = principal.toString();
        }
        User user = userRepository.findByUsername(username).orElseThrow();

        LocalDate start = LocalDate.now().minusDays(6);
        LocalDate end = LocalDate.now();
        return foodEntryRepository.findByUserIdAndDateBetween(user.getId(), start, end);
    }
}