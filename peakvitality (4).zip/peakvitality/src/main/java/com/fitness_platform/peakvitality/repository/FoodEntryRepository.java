package com.fitness_platform.peakvitality.repository;

import com.fitness_platform.peakvitality.model.FoodEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;

public interface FoodEntryRepository extends JpaRepository<FoodEntry, Long> {
    List<FoodEntry> findByUserIdAndDateBetween(Long userId, LocalDate start, LocalDate end);
}