package com.fitness_platform.peakvitality.config;

import com.fitness_platform.peakvitality.model.Recipe;
import com.fitness_platform.peakvitality.repository.RecipeRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
//AI-Generated class used to populate recipe database with a wide range of sample recipes and snacks, used for testing meal plan generation
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
//NOTE: THESE RECIPES WERE GENERATED USING CHATGPT 4o
@Configuration
public class recipeDataLoader {

    @Bean
    public CommandLineRunner loadData(RecipeRepository recipeRepository) {
        return args -> {
            if (recipeRepository.count() > 0){
                System.out.println("Recipes already inserted, skipping data load");
                return;
                //only insert the sample generated recipes if the database is empty, ensures duplicates arent added at every startup
            }

            List<Recipe> recipes = new ArrayList<>();

            // -----------------------
            //      MEALS (1-50)
            // -----------------------

            // 1. Grilled Chicken Salad
            {
                Recipe r = new Recipe();
                r.setRecipeName("Grilled Chicken Salad");
                r.setRecipeDescription("A hearty salad with grilled chicken, mixed greens, cherry tomatoes, and a tangy lemon-herb vinaigrette.");
                r.setRecipeInstructions("Marinate chicken in olive oil, lemon, garlic, and herbs. Grill until cooked through, slice, and toss with fresh greens and tomatoes. Drizzle with vinaigrette and serve immediately.");
                r.setMacroCategory("High Protein");
                r.setCalories(550);
                r.setProtein(45);
                r.setFats(15);
                r.setCarbs(35);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 2. Beef Stir-Fry
            {
                Recipe r = new Recipe();
                r.setRecipeName("Beef Stir-Fry");
                r.setRecipeDescription("Tender beef strips stir-fried with broccoli, bell peppers, and snap peas in a savory soy-ginger sauce.");
                r.setRecipeInstructions("Marinate thinly sliced beef in soy sauce, ginger, and garlic. Stir-fry beef and veggies on high heat until crisp-tender. Serve immediately.");
                r.setMacroCategory("High Protein");
                r.setCalories(680);
                r.setProtein(50);
                r.setFats(20);
                r.setCarbs(60);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 3. Spaghetti Bolognese
            {
                Recipe r = new Recipe();
                r.setRecipeName("Spaghetti Bolognese");
                r.setRecipeDescription("Classic spaghetti topped with a rich, slow-simmered meat sauce featuring ground beef, tomatoes, and Italian herbs.");
                r.setRecipeInstructions("Sauté ground beef with onions and garlic; add crushed tomatoes, basil, and oregano. Simmer until thick, then serve over al dente spaghetti with a sprinkle of parmesan.");
                r.setMacroCategory("Balanced");
                r.setCalories(720);
                r.setProtein(35);
                r.setFats(25);
                r.setCarbs(90);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 4. Vegetable Curry
            {
                Recipe r = new Recipe();
                r.setRecipeName("Vegetable Curry");
                r.setRecipeDescription("A vibrant curry bursting with seasonal vegetables simmered in a fragrant blend of spices and light coconut milk.");
                r.setRecipeInstructions("Sauté onions, garlic, and spices. Add mixed vegetables and coconut milk; simmer until veggies are tender. Serve with a side of cauliflower rice.");
                r.setMacroCategory("Low Carb");
                r.setCalories(480);
                r.setProtein(15);
                r.setFats(22);
                r.setCarbs(55);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegan", "dairy_free", "vegetarian"));
                recipes.add(r);
            }

            // 5. Quinoa Bowl
            {
                Recipe r = new Recipe();
                r.setRecipeName("Quinoa Bowl");
                r.setRecipeDescription("A nutritious bowl of protein-rich quinoa mixed with roasted vegetables and drizzled with a zesty lemon-tahini dressing.");
                r.setRecipeInstructions("Cook quinoa as directed. Roast seasonal veggies until tender, then toss with quinoa and dressing. Serve warm.");
                r.setMacroCategory("Balanced");
                r.setCalories(500);
                r.setProtein(30);
                r.setFats(18);
                r.setMealType("Meal");
                r.setCarbs(60);
                r.setDietaryTags(Arrays.asList("gluten_free", "vegan", "vegetarian"));
                recipes.add(r);
            }

            // 6. Turkey Meatloaf
            {
                Recipe r = new Recipe();
                r.setRecipeName("Turkey Meatloaf");
                r.setRecipeDescription("Lean turkey meatloaf seasoned with herbs and spices, baked to perfection and served with a side of steamed greens.");
                r.setRecipeInstructions("Mix ground turkey with diced onions, garlic, breadcrumbs, and herbs. Form into a loaf, bake until cooked through, and slice to serve.");
                r.setMacroCategory("High Protein");
                r.setCalories(600);
                r.setProtein(48);
                r.setFats(16);
                r.setCarbs(40);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 7. Salmon with Asparagus
            {
                Recipe r = new Recipe();
                r.setRecipeName("Salmon with Asparagus");
                r.setRecipeDescription("Oven-roasted salmon fillet with tender asparagus, drizzled with a lemon-dill sauce.");
                r.setRecipeInstructions("Season salmon and asparagus with salt, pepper, and olive oil. Roast until salmon flakes easily; drizzle with lemon-dill sauce and serve.");
                r.setMacroCategory("High Protein");
                r.setCalories(520);
                r.setProtein(42);
                r.setFats(20);
                r.setCarbs(30);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
                recipes.add(r);
            }

            // 8. Lentil Soup
            {
                Recipe r = new Recipe();
                r.setRecipeName("Lentil Soup");
                r.setRecipeDescription("A hearty, warming soup packed with lentils, carrots, celery, and tomatoes, perfect for a nutritious meal.");
                r.setRecipeInstructions("Sauté onions, carrots, and celery. Add lentils, tomatoes, vegetable broth, and spices. Simmer until lentils are soft; blend partially for a creamy texture.");
                r.setMacroCategory("Balanced");
                r.setCalories(450);
                r.setProtein(20);
                r.setFats(10);
                r.setCarbs(65);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 9. Shrimp Tacos
            {
                Recipe r = new Recipe();
                r.setRecipeName("Shrimp Tacos");
                r.setRecipeDescription("Light and flavorful shrimp tacos with cabbage slaw, avocado, and a squeeze of lime, wrapped in corn tortillas.");
                r.setRecipeInstructions("Sauté shrimp with taco seasoning. Assemble tacos with shrimp, shredded cabbage, avocado slices, and a squeeze of lime.");
                r.setMacroCategory("High Protein");
                r.setCalories(600);
                r.setProtein(40);
                r.setFats(18);
                r.setCarbs(50);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
                recipes.add(r);
            }

            // 10. Stuffed Bell Peppers
            {
                Recipe r = new Recipe();
                r.setRecipeName("Stuffed Bell Peppers");
                r.setRecipeDescription("Colorful bell peppers filled with a savory mix of ground beef, rice, tomatoes, and spices, baked until tender.");
                r.setRecipeInstructions("Hollow out peppers and stuff with a mixture of cooked beef, rice, tomatoes, and spices. Bake until peppers soften and filling is hot.");
                r.setMacroCategory("Balanced");
                r.setCalories(650);
                r.setProtein(38);
                r.setFats(20);
                r.setCarbs(70);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 11. Chicken Fajitas
            {
                Recipe r = new Recipe();
                r.setRecipeName("Chicken Fajitas");
                r.setRecipeDescription("Sizzling strips of marinated chicken with bell peppers and onions, served with warm tortillas and fresh salsa.");
                r.setRecipeInstructions("Marinate chicken in lime and spices. Sauté with sliced bell peppers and onions. Serve with tortillas and toppings of your choice.");
                r.setMacroCategory("High Protein");
                r.setCalories(700);
                r.setProtein(45);
                r.setFats(22);
                r.setCarbs(65);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 12. Pork Chops with Veggies
            {
                Recipe r = new Recipe();
                r.setRecipeName("Pork Chops with Veggies");
                r.setRecipeDescription("Juicy pork chops seared and oven-finished with a medley of roasted root vegetables.");
                r.setRecipeInstructions("Season pork chops and sear in a hot pan. Roast with carrots, parsnips, and potatoes until tender.");
                r.setMacroCategory("High Protein");
                r.setCalories(680);
                r.setProtein(48);
                r.setFats(25);
                r.setCarbs(50);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 13. Eggplant Parmesan
            {
                Recipe r = new Recipe();
                r.setRecipeName("Eggplant Parmesan");
                r.setRecipeDescription("Layers of breaded eggplant baked with marinara sauce and melted mozzarella, served over a bed of basil.");
                r.setRecipeInstructions("Bread and bake eggplant slices. Layer with marinara and mozzarella; bake until bubbly.");
                r.setMacroCategory("Balanced");
                r.setCalories(620);
                r.setProtein(25);
                r.setFats(30);
                r.setCarbs(65);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegetarian"));
                recipes.add(r);
            }

            // 14. Greek Salad with Grilled Chicken
            {
                Recipe r = new Recipe();
                r.setRecipeName("Greek Salad with Grilled Chicken");
                r.setRecipeDescription("Crisp romaine lettuce, cucumbers, olives, red onions, and feta topped with slices of grilled chicken.");
                r.setRecipeInstructions("Grill chicken seasoned with oregano and lemon. Toss salad ingredients with olive oil and vinegar, then top with chicken.");
                r.setMacroCategory("High Protein");
                r.setCalories(560);
                r.setProtein(42);
                r.setFats(18);
                r.setCarbs(40);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 15. Beef and Broccoli
            {
                Recipe r = new Recipe();
                r.setRecipeName("Beef and Broccoli");
                r.setRecipeDescription("A Chinese takeout favorite, featuring tender beef and crisp broccoli in a savory garlic-soy sauce.");
                r.setRecipeInstructions("Marinate beef in soy and garlic. Stir-fry beef with broccoli; add sauce and serve over a small portion of rice.");
                r.setMacroCategory("High Protein");
                r.setCalories(640);
                r.setProtein(46);
                r.setFats(20);
                r.setCarbs(55);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 16. Chickpea Stew
            {
                Recipe r = new Recipe();
                r.setRecipeName("Chickpea Stew");
                r.setRecipeDescription("A hearty stew with chickpeas, tomatoes, spinach, and warm spices—a comforting bowl of plant-powered goodness.");
                r.setRecipeInstructions("Sauté onions and garlic; add chickpeas, tomatoes, and spices. Simmer until flavors meld; stir in spinach just before serving.");
                r.setMacroCategory("Balanced");
                r.setCalories(500);
                r.setProtein(20);
                r.setFats(15);
                r.setCarbs(70);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 17. Grilled Tofu Stir-Fry
            {
                Recipe r = new Recipe();
                r.setRecipeName("Grilled Tofu Stir-Fry");
                r.setRecipeDescription("Marinated tofu stir-fried with mixed vegetables in a light soy-ginger sauce for a protein-packed vegan meal.");
                r.setRecipeInstructions("Press and marinate tofu in soy and ginger. Stir-fry with bell peppers, broccoli, and snap peas; serve hot.");
                r.setMacroCategory("Balanced");
                r.setCalories(520);
                r.setProtein(28);
                r.setFats(18);
                r.setCarbs(55);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 18. Baked Cod with Lemon
            {
                Recipe r = new Recipe();
                r.setRecipeName("Baked Cod with Lemon");
                r.setRecipeDescription("A delicate fillet of cod baked with lemon, garlic, and fresh dill, served with a side of steamed vegetables.");
                r.setRecipeInstructions("Season cod with lemon zest, garlic, and dill. Bake until flaky; serve with steamed broccoli and carrots.");
                r.setMacroCategory("High Protein");
                r.setCalories(500);
                r.setProtein(42);
                r.setFats(12);
                r.setCarbs(40);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
                recipes.add(r);
            }

            // 19. Chicken Caesar Salad
            {
                Recipe r = new Recipe();
                r.setRecipeName("Chicken Caesar Salad");
                r.setRecipeDescription("Crisp romaine tossed in a creamy Caesar dressing, topped with grilled chicken, croutons, and parmesan.");
                r.setRecipeInstructions("Grill seasoned chicken breast. Toss romaine with Caesar dressing and croutons; top with sliced chicken and parmesan.");
                r.setMacroCategory("High Protein");
                r.setCalories(600);
                r.setProtein(40);
                r.setFats(22);
                r.setCarbs(45);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 20. Mushroom Risotto
            {
                Recipe r = new Recipe();
                r.setRecipeName("Mushroom Risotto");
                r.setRecipeDescription("A creamy risotto loaded with earthy mushrooms, simmered slowly with vegetable broth and finished with parmesan.");
                r.setRecipeInstructions("Sauté mushrooms and onions; add Arborio rice and warm broth gradually while stirring. Finish with parmesan and herbs.");
                r.setMacroCategory("Balanced");
                r.setCalories(680);
                r.setProtein(20);
                r.setFats(22);
                r.setCarbs(100);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegetarian"));
                recipes.add(r);
            }

            // 21. Turkey Chili
            {
                Recipe r = new Recipe();
                r.setRecipeName("Turkey Chili");
                r.setRecipeDescription("A hearty chili made with lean ground turkey, kidney beans, tomatoes, and a blend of spicy seasonings.");
                r.setRecipeInstructions("Brown turkey with onions; add beans, tomatoes, and chili spices. Simmer for 30 minutes; serve hot with a dollop of Greek yogurt.");
                r.setMacroCategory("High Protein");
                r.setCalories(630);
                r.setProtein(42);
                r.setFats(18);
                r.setCarbs(65);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 22. Veggie Burger
            {
                Recipe r = new Recipe();
                r.setRecipeName("Veggie Burger");
                r.setRecipeDescription("A flavorful patty made from black beans, quinoa, and spices, served on a whole-grain bun with fresh toppings.");
                r.setRecipeInstructions("Mash black beans and mix with cooked quinoa, onions, and spices. Form patties; pan-fry until crisp; assemble on a bun with lettuce and tomato.");
                r.setMacroCategory("Balanced");
                r.setCalories(600);
                r.setProtein(25);
                r.setFats(15);
                r.setCarbs(80);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegetarian"));
                recipes.add(r);
            }

            // 23. Shrimp Pasta
            {
                Recipe r = new Recipe();
                r.setRecipeName("Shrimp Pasta");
                r.setRecipeDescription("Al dente pasta tossed with succulent shrimp, garlic, olive oil, and a hint of red pepper flakes for a spicy kick.");
                r.setRecipeInstructions("Sauté shrimp with garlic and red pepper flakes; toss with cooked pasta and olive oil; finish with fresh parsley.");
                r.setMacroCategory("Balanced");
                r.setCalories(700);
                r.setProtein(38);
                r.setFats(22);
                r.setCarbs(85);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 24. Roasted Chicken with Quinoa
            {
                Recipe r = new Recipe();
                r.setRecipeName("Roasted Chicken with Quinoa");
                r.setRecipeDescription("Oven-roasted chicken breast served alongside a fluffy quinoa salad mixed with herbs and diced vegetables.");
                r.setRecipeInstructions("Season and roast chicken until golden. Toss cooked quinoa with chopped veggies and herbs; serve together.");
                r.setMacroCategory("High Protein");
                r.setCalories(640);
                r.setProtein(44);
                r.setFats(18);
                r.setCarbs(60);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 25. Spinach and Feta Stuffed Chicken
            {
                Recipe r = new Recipe();
                r.setRecipeName("Spinach and Feta Stuffed Chicken");
                r.setRecipeDescription("Juicy chicken breast stuffed with spinach, crumbled feta, and sun-dried tomatoes, baked to perfection.");
                r.setRecipeInstructions("Butterfly chicken breasts; fill with spinach, feta, and tomatoes. Bake until chicken is cooked through.");
                r.setMacroCategory("High Protein");
                r.setCalories(610);
                r.setProtein(46);
                r.setFats(17);
                r.setCarbs(50);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 26. Slow-Cooked Barbecue Chicken
            {
                Recipe r = new Recipe();
                r.setRecipeName("Slow-Cooked Barbecue Chicken");
                r.setRecipeDescription("Tender chicken slow-cooked in a smoky barbecue sauce, served with a side of roasted vegetables.");
                r.setRecipeInstructions("Marinate chicken in barbecue sauce overnight; slow-cook until falling off the bone. Serve with roasted seasonal veggies.");
                r.setMacroCategory("High Protein");
                r.setCalories(670);
                r.setProtein(47);
                r.setFats(20);
                r.setCarbs(55);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 27. Zucchini Noodles with Pesto
            {
                Recipe r = new Recipe();
                r.setRecipeName("Zucchini Noodles with Pesto");
                r.setRecipeDescription("Light zucchini noodles tossed in a fresh basil pesto with cherry tomatoes and toasted pine nuts.");
                r.setRecipeInstructions("Spiralize zucchini; toss with homemade basil pesto and halved cherry tomatoes. Serve chilled or at room temperature.");
                r.setMacroCategory("Low Carb");
                r.setCalories(420);
                r.setProtein(15);
                r.setFats(28);
                r.setCarbs(25);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 28. Baked Salmon with Dill
            {
                Recipe r = new Recipe();
                r.setRecipeName("Baked Salmon with Dill");
                r.setRecipeDescription("Flaky baked salmon fillet seasoned with lemon, dill, and olive oil, served with steamed green beans.");
                r.setRecipeInstructions("Season salmon with lemon, dill, salt, and pepper; bake until flaky. Serve with steamed green beans.");
                r.setMacroCategory("High Protein");
                r.setCalories(530);
                r.setProtein(43);
                r.setFats(16);
                r.setCarbs(32);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
                recipes.add(r);
            }

            // 29. Moroccan Lamb Tagine
            {
                Recipe r = new Recipe();
                r.setRecipeName("Moroccan Lamb Tagine");
                r.setRecipeDescription("A spiced lamb stew with apricots, almonds, and Moroccan spices, slow-cooked to tender perfection.");
                r.setRecipeInstructions("Brown lamb cubes; add onions, garlic, spices, apricots, and broth. Simmer slowly until tender; garnish with toasted almonds.");
                r.setMacroCategory("High Protein");
                r.setCalories(700);
                r.setProtein(45);
                r.setFats(30);
                r.setCarbs(50);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 30. Chicken Stir-Fry with Snow Peas
            {
                Recipe r = new Recipe();
                r.setRecipeName("Chicken Stir-Fry with Snow Peas");
                r.setRecipeDescription("Quick stir-fried chicken with crisp snow peas, carrots, and a savory garlic-ginger sauce.");
                r.setRecipeInstructions("Stir-fry chicken pieces with garlic; add snow peas and carrots; toss with sauce and serve immediately.");
                r.setMacroCategory("High Protein");
                r.setCalories(630);
                r.setProtein(44);
                r.setFats(18);
                r.setCarbs(58);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
                recipes.add(r);
            }

            // 31. Grilled Steak with Veggies
            {
                Recipe r = new Recipe();
                r.setRecipeName("Grilled Steak with Veggies");
                r.setRecipeDescription("Juicy grilled steak served with a side of mixed grilled vegetables and a light herb butter.");
                r.setRecipeInstructions("Season steak and grill to desired doneness; grill vegetables alongside; top steak with a dab of herb butter before serving.");
                r.setMacroCategory("High Protein");
                r.setCalories(750);
                r.setProtein(50);
                r.setFats(28);
                r.setCarbs(45);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 32. Seafood Paella
            {
                Recipe r = new Recipe();
                r.setRecipeName("Seafood Paella");
                r.setRecipeDescription("A vibrant Spanish rice dish loaded with shrimp, mussels, and calamari in a saffron-infused broth.");
                r.setRecipeInstructions("Sauté seafood with garlic; add rice and saffron broth; simmer until rice is tender; garnish with parsley.");
                r.setMacroCategory("Balanced");
                r.setCalories(720);
                r.setProtein(38);
                r.setFats(22);
                r.setCarbs(85);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 33. Veggie Lasagna
            {
                Recipe r = new Recipe();
                r.setRecipeName("Veggie Lasagna");
                r.setRecipeDescription("Layers of pasta, ricotta, spinach, zucchini, and marinara sauce baked to golden perfection.");
                r.setRecipeInstructions("Layer lasagna noodles with ricotta, spinach, sliced zucchini, and marinara; bake until bubbly and top with basil.");
                r.setMacroCategory("Balanced");
                r.setCalories(680);
                r.setProtein(30);
                r.setFats(24);
                r.setCarbs(90);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegetarian"));
                recipes.add(r);
            }

            // 34. Chicken Curry
            {
                Recipe r = new Recipe();
                r.setRecipeName("Chicken Curry");
                r.setRecipeDescription("A warming chicken curry with tender pieces simmered in a spiced tomato and coconut milk sauce.");
                r.setRecipeInstructions("Brown chicken with onions and garlic; add curry spices, tomatoes, and coconut milk; simmer until thick; serve with cauliflower rice.");
                r.setMacroCategory("High Protein");
                r.setCalories(660);
                r.setProtein(42);
                r.setFats(22);
                r.setCarbs(58);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 35. Broccoli Cheddar Soup
            {
                Recipe r = new Recipe();
                r.setRecipeName("Broccoli Cheddar Soup");
                r.setRecipeDescription("A creamy soup loaded with fresh broccoli and sharp cheddar, perfect for a comforting meal.");
                r.setRecipeInstructions("Simmer broccoli in low-sodium broth; blend partially; stir in shredded cheddar until melted; serve hot.");
                r.setMacroCategory("Balanced");
                r.setCalories(600);
                r.setProtein(22);
                r.setFats(26);
                r.setCarbs(65);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 36. Black Bean Burrito Bowl
            {
                Recipe r = new Recipe();
                r.setRecipeName("Black Bean Burrito Bowl");
                r.setRecipeDescription("A nutritious bowl featuring black beans, brown rice, corn, and fresh salsa topped with avocado slices.");
                r.setRecipeInstructions("Layer brown rice, black beans, corn, and salsa in a bowl; top with avocado and a squeeze of lime.");
                r.setMacroCategory("Balanced");
                r.setCalories(650);
                r.setProtein(24);
                r.setFats(18);
                r.setCarbs(90);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 37. Pesto Pasta with Cherry Tomatoes
            {
                Recipe r = new Recipe();
                r.setRecipeName("Pesto Pasta with Cherry Tomatoes");
                r.setRecipeDescription("Al dente pasta tossed in a fresh basil pesto with sweet cherry tomatoes and a sprinkle of pine nuts.");
                r.setRecipeInstructions("Cook pasta; toss with basil pesto and halved cherry tomatoes; top with pine nuts and serve warm.");
                r.setMacroCategory("Balanced");
                r.setCalories(700);
                r.setProtein(22);
                r.setFats(28);
                r.setCarbs(95);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegetarian"));
                recipes.add(r);
            }

            // 38. Teriyaki Chicken Bowl
            {
                Recipe r = new Recipe();
                r.setRecipeName("Teriyaki Chicken Bowl");
                r.setRecipeDescription("Grilled teriyaki chicken served over steamed rice with stir-fried vegetables and a drizzle of teriyaki glaze.");
                r.setRecipeInstructions("Marinate chicken in teriyaki sauce; grill and slice; serve over rice with sautéed veggies and extra sauce.");
                r.setMacroCategory("High Protein");
                r.setCalories(680);
                r.setProtein(44);
                r.setFats(20);
                r.setCarbs(70);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 39. Grilled Portobello Mushrooms
            {
                Recipe r = new Recipe();
                r.setRecipeName("Grilled Portobello Mushrooms");
                r.setRecipeDescription("Large Portobello mushrooms marinated in balsamic vinegar and herbs, grilled to tender perfection.");
                r.setRecipeInstructions("Marinate mushrooms in balsamic and olive oil; grill until tender; serve as a main or side dish.");
                r.setMacroCategory("Low Carb");
                r.setCalories(400);
                r.setProtein(12);
                r.setFats(18);
                r.setCarbs(30);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegetarian", "gluten_free"));
                recipes.add(r);
            }

            // 40. Lemon Garlic Shrimp
            {
                Recipe r = new Recipe();
                r.setRecipeName("Lemon Garlic Shrimp");
                r.setRecipeDescription("Succulent shrimp sautéed in a lemon garlic butter sauce, served over a bed of sautéed spinach.");
                r.setRecipeInstructions("Sauté shrimp in garlic and butter; add lemon juice; toss with fresh spinach; serve immediately.");
                r.setMacroCategory("High Protein");
                r.setCalories(520);
                r.setProtein(40);
                r.setFats(16);
                r.setCarbs(34);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
                recipes.add(r);
            }

            // 41. Spicy Tofu Bowl
            {
                Recipe r = new Recipe();
                r.setRecipeName("Spicy Tofu Bowl");
                r.setRecipeDescription("Crispy tofu tossed in a spicy chili-garlic sauce, served over mixed greens and shredded carrots.");
                r.setRecipeInstructions("Press and cube tofu; fry until crispy; toss with spicy sauce; serve over salad greens with shredded carrots.");
                r.setMacroCategory("Balanced");
                r.setCalories(500);
                r.setProtein(24);
                r.setFats(20);
                r.setCarbs(55);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 42. Roast Beef with Sweet Potatoes
            {
                Recipe r = new Recipe();
                r.setRecipeName("Roast Beef with Sweet Potatoes");
                r.setRecipeDescription("Tender roast beef served with caramelized sweet potatoes and a side of steamed green beans.");
                r.setRecipeInstructions("Roast beef seasoned with herbs until medium-rare; serve with oven-roasted sweet potatoes and green beans.");
                r.setMacroCategory("High Protein");
                r.setCalories(740);
                r.setProtein(48);
                r.setFats(26);
                r.setCarbs(60);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 43. Quinoa and Black Bean Salad
            {
                Recipe r = new Recipe();
                r.setRecipeName("Quinoa and Black Bean Salad");
                r.setRecipeDescription("A refreshing salad of quinoa, black beans, corn, and diced bell peppers with a lime-cilantro dressing.");
                r.setRecipeInstructions("Mix cooked quinoa, black beans, corn, and bell peppers; toss with lime juice, olive oil, and cilantro.");
                r.setMacroCategory("Balanced");
                r.setCalories(600);
                r.setProtein(22);
                r.setFats(16);
                r.setCarbs(85);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 44. Chicken and Vegetable Skewers
            {
                Recipe r = new Recipe();
                r.setRecipeName("Chicken and Vegetable Skewers");
                r.setRecipeDescription("Grilled skewers of marinated chicken and colorful vegetables, served with a herbed yogurt dipping sauce.");
                r.setRecipeInstructions("Thread chicken and veggies onto skewers; grill until cooked; serve with a side of herbed yogurt sauce.");
                r.setMacroCategory("High Protein");
                r.setCalories(630);
                r.setProtein(42);
                r.setFats(20);
                r.setCarbs(55);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 45. Pasta Primavera
            {
                Recipe r = new Recipe();
                r.setRecipeName("Pasta Primavera");
                r.setRecipeDescription("A light pasta dish loaded with fresh seasonal vegetables tossed in a garlic and olive oil sauce.");
                r.setRecipeInstructions("Sauté mixed vegetables with garlic; toss with pasta and olive oil; garnish with fresh basil; serve warm.");
                r.setMacroCategory("Balanced");
                r.setCalories(680);
                r.setProtein(20);
                r.setFats(24);
                r.setCarbs(95);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegetarian"));
                recipes.add(r);
            }

            // 46. Veggie Stir-Fry with Brown Rice
            {
                Recipe r = new Recipe();
                r.setRecipeName("Veggie Stir-Fry with Brown Rice");
                r.setRecipeDescription("Crisp vegetables stir-fried in a tangy sauce, served over steamed brown rice.");
                r.setRecipeInstructions("Stir-fry broccoli, carrots, and bell peppers in a light sauce; serve over steamed brown rice.");
                r.setMacroCategory("Balanced");
                r.setCalories(640);
                r.setProtein(18);
                r.setFats(20);
                r.setCarbs(90);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegetarian", "gluten_free"));
                recipes.add(r);
            }

            // 47. Baked Tilapia with Herbs
            {
                Recipe r = new Recipe();
                r.setRecipeName("Baked Tilapia with Herbs");
                r.setRecipeDescription("Light, flaky tilapia baked with lemon, garlic, and herbs, served with steamed vegetables.");
                r.setRecipeInstructions("Season tilapia with lemon, garlic, and herbs; bake until flaky; serve with steamed broccoli and carrots.");
                r.setMacroCategory("High Protein");
                r.setCalories(510);
                r.setProtein(43);
                r.setFats(14);
                r.setCarbs(38);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
                recipes.add(r);
            }

            // 48. Chicken Pad Thai
            {
                Recipe r = new Recipe();
                r.setRecipeName("Chicken Pad Thai");
                r.setRecipeDescription("A flavorful Thai noodle dish with chicken, rice noodles, bean sprouts, and a tangy tamarind sauce.");
                r.setRecipeInstructions("Stir-fry chicken with garlic; add rice noodles, bean sprouts, and tamarind sauce; toss well; garnish with peanuts and lime.");
                r.setMacroCategory("Balanced");
                r.setCalories(700);
                r.setProtein(38);
                r.setFats(24);
                r.setCarbs(90);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 49. Beef Fajitas
            {
                Recipe r = new Recipe();
                r.setRecipeName("Beef Fajitas");
                r.setRecipeDescription("Sizzling beef strips with bell peppers and onions served with warm tortillas and fresh guacamole.");
                r.setRecipeInstructions("Marinate beef with fajita spices; stir-fry with peppers and onions; serve in tortillas with guacamole and salsa.");
                r.setMacroCategory("High Protein");
                r.setCalories(680);
                r.setProtein(45);
                r.setFats(22);
                r.setCarbs(65);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 50. Roasted Vegetable Medley
            {
                Recipe r = new Recipe();
                r.setRecipeName("Roasted Vegetable Medley");
                r.setRecipeDescription("A colorful mix of roasted seasonal vegetables drizzled with balsamic glaze for a light, flavorful dish.");
                r.setRecipeInstructions("Toss assorted vegetables with olive oil; roast until tender; drizzle with balsamic reduction; serve warm.");
                r.setMacroCategory("Balanced");
                r.setCalories(550);
                r.setProtein(15);
                r.setFats(20);
                r.setCarbs(75);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // -----------------------
            //     SNACKS (51-100)
            // -----------------------

            // 51. Avocado Toast
            {
                Recipe r = new Recipe();
                r.setRecipeName("Avocado Toast");
                r.setRecipeDescription("Toasted whole-grain bread topped with mashed avocado, a squeeze of lemon, and a sprinkle of chili flakes.");
                r.setRecipeInstructions("Toast bread; mash avocado with lemon juice and salt; spread on toast; sprinkle chili flakes; serve.");
                r.setMacroCategory("Balanced");
                r.setCalories(220);
                r.setProtein(8);
                r.setFats(12);
                r.setCarbs(20);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegetarian", "dairy_free"));
                recipes.add(r);
            }

            // 52. Greek Yogurt Parfait
            {
                Recipe r = new Recipe();
                r.setRecipeName("Greek Yogurt Parfait");
                r.setRecipeDescription("Creamy Greek yogurt layered with fresh berries, honey, and a crunch of granola.");
                r.setRecipeInstructions("Layer Greek yogurt with mixed berries and granola; drizzle with honey; serve chilled.");
                r.setMacroCategory("High Protein");
                r.setCalories(300);
                r.setProtein(18);
                r.setFats(10);
                r.setCarbs(35);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 53. Fruit Smoothie Bowl
            {
                Recipe r = new Recipe();
                r.setRecipeName("Fruit Smoothie Bowl");
                r.setRecipeDescription("A vibrant blend of mixed berries and banana, topped with seeds and a drizzle of almond butter.");
                r.setRecipeInstructions("Blend fruits with almond milk until smooth; pour into a bowl; top with seeds and almond butter; serve immediately.");
                r.setMacroCategory("Low Carb");
                r.setCalories(250);
                r.setProtein(6);
                r.setFats(8);
                r.setCarbs(40);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 54. Nutty Energy Bites
            {
                Recipe r = new Recipe();
                r.setRecipeName("Nutty Energy Bites");
                r.setRecipeDescription("Chewy bites made from oats, nut butter, and mixed chopped nuts—perfect for an energy boost.");
                r.setRecipeInstructions("Mix oats, nut butter, and chopped nuts; roll into bite-sized balls; chill until firm.");
                r.setMacroCategory("High Protein");
                r.setCalories(180);
                r.setProtein(10);
                r.setFats(8);
                r.setCarbs(20);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 55. Hummus and Veggie Sticks
            {
                Recipe r = new Recipe();
                r.setRecipeName("Hummus and Veggie Sticks");
                r.setRecipeDescription("Creamy hummus paired with crisp carrot and celery sticks for a healthy snack.");
                r.setRecipeInstructions("Scoop hummus into a bowl; serve with freshly cut veggie sticks for dipping.");
                r.setMacroCategory("Balanced");
                r.setCalories(150);
                r.setProtein(5);
                r.setFats(6);
                r.setCarbs(18);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 56. Apple Slices with Almond Butter
            {
                Recipe r = new Recipe();
                r.setRecipeName("Apple Slices with Almond Butter");
                r.setRecipeDescription("Crisp apple slices served with a generous dollop of almond butter.");
                r.setRecipeInstructions("Core and slice an apple; serve with almond butter for dipping.");
                r.setMacroCategory("Balanced");
                r.setCalories(210);
                r.setProtein(6);
                r.setFats(12);
                r.setCarbs(24);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 57. Cottage Cheese with Pineapple
            {
                Recipe r = new Recipe();
                r.setRecipeName("Cottage Cheese with Pineapple");
                r.setRecipeDescription("Creamy cottage cheese mixed with sweet pineapple chunks.");
                r.setRecipeInstructions("Combine cottage cheese and diced pineapple; chill and serve.");
                r.setMacroCategory("High Protein");
                r.setCalories(230);
                r.setProtein(20);
                r.setFats(8);
                r.setCarbs(22);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 58. Mixed Nuts and Dried Fruit
            {
                Recipe r = new Recipe();
                r.setRecipeName("Mixed Nuts and Dried Fruit");
                r.setRecipeDescription("A balanced mix of unsalted almonds, walnuts, and dried cranberries for a quick energy boost.");
                r.setRecipeInstructions("Portion out a mix of nuts and dried fruit; enjoy as a portable snack.");
                r.setMacroCategory("Balanced");
                r.setCalories(250);
                r.setProtein(8);
                r.setFats(18);
                r.setCarbs(22);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 59. Rice Cake with Peanut Butter
            {
                Recipe r = new Recipe();
                r.setRecipeName("Rice Cake with Peanut Butter");
                r.setRecipeDescription("Crisp rice cakes spread with natural peanut butter and topped with banana slices.");
                r.setRecipeInstructions("Spread peanut butter on rice cakes; top with banana slices; serve.");
                r.setMacroCategory("Balanced");
                r.setCalories(200);
                r.setProtein(7);
                r.setFats(10);
                r.setCarbs(25);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 60. Protein Bar
            {
                Recipe r = new Recipe();
                r.setRecipeName("Protein Bar");
                r.setRecipeDescription("A homemade protein bar packed with oats, protein powder, and honey for natural sweetness.");
                r.setRecipeInstructions("Mix oats, protein powder, and honey; press into a pan; chill; cut into bars.");
                r.setMacroCategory("High Protein");
                r.setCalories(280);
                r.setProtein(20);
                r.setFats(9);
                r.setCarbs(30);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 61. Celery with Cream Cheese
            {
                Recipe r = new Recipe();
                r.setRecipeName("Celery with Cream Cheese");
                r.setRecipeDescription("Crisp celery sticks filled with a light spread of cream cheese.");
                r.setRecipeInstructions("Fill celery sticks with cream cheese; serve immediately.");
                r.setMacroCategory("Balanced");
                r.setCalories(140);
                r.setProtein(5);
                r.setFats(9);
                r.setCarbs(10);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 62. Boiled Eggs
            {
                Recipe r = new Recipe();
                r.setRecipeName("Boiled Eggs");
                r.setRecipeDescription("Simple and satisfying hard-boiled eggs, a classic high-protein snack.");
                r.setRecipeInstructions("Boil eggs for 9–10 minutes; peel; serve with a sprinkle of salt and pepper.");
                r.setMacroCategory("High Protein");
                r.setCalories(150);
                r.setProtein(13);
                r.setFats(10);
                r.setCarbs(1);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 63. Banana Oat Muffins
            {
                Recipe r = new Recipe();
                r.setRecipeName("Banana Oat Muffins");
                r.setRecipeDescription("Moist muffins made with ripe bananas and oats, perfect for a grab-and-go snack.");
                r.setRecipeInstructions("Mix mashed bananas with oats and a bit of honey; bake in muffin tins until golden.");
                r.setMacroCategory("Balanced");
                r.setCalories(220);
                r.setProtein(6);
                r.setFats(8);
                r.setCarbs(35);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 64. Edamame Pods
            {
                Recipe r = new Recipe();
                r.setRecipeName("Edamame Pods");
                r.setRecipeDescription("Steamed edamame sprinkled with sea salt, offering a protein-packed, satisfying snack.");
                r.setRecipeInstructions("Steam edamame until tender; sprinkle with salt; serve warm.");
                r.setMacroCategory("High Protein");
                r.setCalories(200);
                r.setProtein(17);
                r.setFats(8);
                r.setCarbs(15);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 65. Veggie Chips
            {
                Recipe r = new Recipe();
                r.setRecipeName("Veggie Chips");
                r.setRecipeDescription("Crunchy, baked veggie chips made from thinly sliced kale, sweet potato, and beetroot.");
                r.setRecipeInstructions("Toss veggie slices in olive oil; bake until crisp; serve.");
                r.setMacroCategory("Low Carb");
                r.setCalories(150);
                r.setProtein(3);
                r.setFats(7);
                r.setCarbs(20);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 66. Chia Seed Pudding
            {
                Recipe r = new Recipe();
                r.setRecipeName("Chia Seed Pudding");
                r.setRecipeDescription("A creamy pudding made from chia seeds soaked in almond milk and sweetened with maple syrup.");
                r.setRecipeInstructions("Combine chia seeds with almond milk; refrigerate overnight; top with berries before serving.");
                r.setMacroCategory("Balanced");
                r.setCalories(230);
                r.setProtein(8);
                r.setFats(10);
                r.setCarbs(28);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 67. Fresh Fruit Salad
            {
                Recipe r = new Recipe();
                r.setRecipeName("Fresh Fruit Salad");
                r.setRecipeDescription("A refreshing medley of seasonal fruits, chopped and tossed for a naturally sweet snack.");
                r.setRecipeInstructions("Chop a variety of fresh fruits; toss together; serve chilled.");
                r.setMacroCategory("Balanced");
                r.setCalories(180);
                r.setProtein(3);
                r.setFats(1);
                r.setCarbs(45);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 68. Almond Flour Crackers
            {
                Recipe r = new Recipe();
                r.setRecipeName("Almond Flour Crackers");
                r.setRecipeDescription("Crunchy crackers made from almond flour and seasoned with herbs, perfect for a low-carb nibble.");
                r.setRecipeInstructions("Mix almond flour with egg and herbs; roll out thinly; cut into shapes; bake until crisp.");
                r.setMacroCategory("Low Carb");
                r.setCalories(160);
                r.setProtein(6);
                r.setFats(12);
                r.setCarbs(10);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 69. Dark Chocolate Almonds
            {
                Recipe r = new Recipe();
                r.setRecipeName("Dark Chocolate Almonds");
                r.setRecipeDescription("Roasted almonds lightly coated in dark chocolate for a sweet yet nutritious treat.");
                r.setRecipeInstructions("Roast almonds; toss in melted dark chocolate; let cool until the chocolate sets.");
                r.setMacroCategory("Balanced");
                r.setCalories(210);
                r.setProtein(7);
                r.setFats(14);
                r.setCarbs(18);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 70. Smoothie Shot
            {
                Recipe r = new Recipe();
                r.setRecipeName("Smoothie Shot");
                r.setRecipeDescription("A concentrated, low-cal smoothie shot made from spinach, cucumber, and a hint of lemon.");
                r.setRecipeInstructions("Blend spinach, cucumber, and lemon juice until smooth; strain if desired; serve chilled.");
                r.setMacroCategory("Low Carb");
                r.setCalories(130);
                r.setProtein(4);
                r.setFats(2);
                r.setCarbs(20);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 71. Protein Shake
            {
                Recipe r = new Recipe();
                r.setRecipeName("Protein Shake");
                r.setRecipeDescription("A classic protein shake blended with your favorite protein powder, almond milk, and a banana.");
                r.setRecipeInstructions("Blend protein powder, almond milk, and banana until smooth; serve immediately.");
                r.setMacroCategory("High Protein");
                r.setCalories(300);
                r.setProtein(25);
                r.setFats(7);
                r.setCarbs(35);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 72. Spiced Roasted Chickpeas
            {
                Recipe r = new Recipe();
                r.setRecipeName("Spiced Roasted Chickpeas");
                r.setRecipeDescription("Crunchy roasted chickpeas tossed in cumin, paprika, and a touch of sea salt.");
                r.setRecipeInstructions("Toss chickpeas with olive oil and spices; roast until crispy; serve warm.");
                r.setMacroCategory("High Protein");
                r.setCalories(200);
                r.setProtein(10);
                r.setFats(6);
                r.setCarbs(28);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 73. Avocado and Tomato Bruschetta
            {
                Recipe r = new Recipe();
                r.setRecipeName("Avocado and Tomato Bruschetta");
                r.setRecipeDescription("Toasted baguette slices topped with a fresh mix of diced avocado, tomatoes, basil, and a drizzle of balsamic glaze.");
                r.setRecipeInstructions("Toast baguette slices; top with avocado and tomato mix; drizzle with balsamic glaze; serve.");
                r.setMacroCategory("Balanced");
                r.setCalories(240);
                r.setProtein(6);
                r.setFats(14);
                r.setCarbs(22);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegetarian"));
                recipes.add(r);
            }

            // 74. Pumpkin Seed Trail Mix
            {
                Recipe r = new Recipe();
                r.setRecipeName("Pumpkin Seed Trail Mix");
                r.setRecipeDescription("A wholesome mix of pumpkin seeds, dried cranberries, and a few dark chocolate chips.");
                r.setRecipeInstructions("Combine pumpkin seeds, dried cranberries, and dark chocolate pieces; portion out for a quick snack.");
                r.setMacroCategory("High Protein");
                r.setCalories(220);
                r.setProtein(8);
                r.setFats(14);
                r.setCarbs(20);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 75. Kale Chips
            {
                Recipe r = new Recipe();
                r.setRecipeName("Kale Chips");
                r.setRecipeDescription("Crispy baked kale leaves lightly seasoned with olive oil and sea salt for a nutrient-packed snack.");
                r.setRecipeInstructions("Toss kale leaves with olive oil and salt; bake until crisp; serve.");
                r.setMacroCategory("Low Carb");
                r.setCalories(140);
                r.setProtein(4);
                r.setFats(8);
                r.setCarbs(10);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 76. Mini Caprese Skewers
            {
                Recipe r = new Recipe();
                r.setRecipeName("Mini Caprese Skewers");
                r.setRecipeDescription("Bite-sized skewers featuring cherry tomatoes, fresh mozzarella, and basil drizzled with balsamic reduction.");
                r.setRecipeInstructions("Thread tomatoes, basil, and mozzarella onto skewers; drizzle with balsamic reduction; serve.");
                r.setMacroCategory("Balanced");
                r.setCalories(180);
                r.setProtein(9);
                r.setFats(10);
                r.setCarbs(12);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegetarian"));
                recipes.add(r);
            }

            // 77. Zucchini Fritters
            {
                Recipe r = new Recipe();
                r.setRecipeName("Zucchini Fritters");
                r.setRecipeDescription("Lightly pan-fried fritters made from grated zucchini, herbs, and a touch of almond flour.");
                r.setRecipeInstructions("Mix grated zucchini with almond flour, herbs, and an egg; form small patties; fry until golden brown.");
                r.setMacroCategory("Low Carb");
                r.setCalories(200);
                r.setProtein(8);
                r.setFats(12);
                r.setCarbs(14);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 78. Protein Cookies
            {
                Recipe r = new Recipe();
                r.setRecipeName("Protein Cookies");
                r.setRecipeDescription("Soft, chewy cookies enriched with protein powder, oats, and a hint of vanilla for a guilt-free treat.");
                r.setRecipeInstructions("Combine oats, protein powder, mashed banana, and vanilla; form cookies; bake until set.");
                r.setMacroCategory("High Protein");
                r.setCalories(250);
                r.setProtein(15);
                r.setFats(9);
                r.setCarbs(30);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 79. Berry Yogurt Bowl
            {
                Recipe r = new Recipe();
                r.setRecipeName("Berry Yogurt Bowl");
                r.setRecipeDescription("A refreshing bowl of Greek yogurt topped with mixed berries and a drizzle of honey.");
                r.setRecipeInstructions("Scoop Greek yogurt into a bowl; top with fresh berries; drizzle with honey; serve chilled.");
                r.setMacroCategory("High Protein");
                r.setCalories(280);
                r.setProtein(20);
                r.setFats(7);
                r.setCarbs(32);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 80. Oatmeal Energy Balls
            {
                Recipe r = new Recipe();
                r.setRecipeName("Oatmeal Energy Balls");
                r.setRecipeDescription("No-bake energy balls made from oats, nut butter, and honey, rolled in shredded coconut.");
                r.setRecipeInstructions("Mix oats, nut butter, honey, and coconut; form into balls; refrigerate until firm.");
                r.setMacroCategory("High Protein");
                r.setCalories(210);
                r.setProtein(10);
                r.setFats(11);
                r.setCarbs(25);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 81. Grapes and Cheese Bites
            {
                Recipe r = new Recipe();
                r.setRecipeName("Grapes and Cheese Bites");
                r.setRecipeDescription("A simple, balanced snack pairing juicy grapes with bite-sized cheddar cheese cubes.");
                r.setRecipeInstructions("Arrange grapes and cheese cubes on a small plate; serve chilled.");
                r.setMacroCategory("Balanced");
                r.setCalories(190);
                r.setProtein(8);
                r.setFats(10);
                r.setCarbs(18);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 82. Cucumber Sandwiches
            {
                Recipe r = new Recipe();
                r.setRecipeName("Cucumber Sandwiches");
                r.setRecipeDescription("Refreshing cucumber slices layered with light cream cheese and fresh dill, perfect for a low-carb bite.");
                r.setRecipeInstructions("Slice cucumber thickly; spread with cream cheese; add dill; sandwich together; serve.");
                r.setMacroCategory("Low Carb");
                r.setCalories(150);
                r.setProtein(5);
                r.setFats(8);
                r.setCarbs(12);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 83. Baked Sweet Potato Fries
            {
                Recipe r = new Recipe();
                r.setRecipeName("Baked Sweet Potato Fries");
                r.setRecipeDescription("Crispy baked fries made from sweet potatoes, seasoned with paprika and garlic.");
                r.setRecipeInstructions("Cut sweet potatoes into fries; toss with olive oil and spices; bake until crispy; serve.");
                r.setMacroCategory("Balanced");
                r.setCalories(220);
                r.setProtein(3);
                r.setFats(10);
                r.setCarbs(35);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 84. Roasted Edamame
            {
                Recipe r = new Recipe();
                r.setRecipeName("Roasted Edamame");
                r.setRecipeDescription("Crunchy roasted edamame seasoned with sea salt and a dash of chili powder.");
                r.setRecipeInstructions("Toss edamame with olive oil and spices; roast until crisp; serve warm.");
                r.setMacroCategory("High Protein");
                r.setCalories(200);
                r.setProtein(16);
                r.setFats(7);
                r.setCarbs(18);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 85. Banana Protein Pancakes
            {
                Recipe r = new Recipe();
                r.setRecipeName("Banana Protein Pancakes");
                r.setRecipeDescription("Mini pancakes made with mashed banana, eggs, and protein powder, served with a drizzle of honey.");
                r.setRecipeInstructions("Mix mashed banana with eggs and protein powder; cook small pancakes on a griddle until golden; serve with honey.");
                r.setMacroCategory("High Protein");
                r.setCalories(240);
                r.setProtein(18);
                r.setFats(8);
                r.setCarbs(30);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 86. Strawberry Banana Smoothie
            {
                Recipe r = new Recipe();
                r.setRecipeName("Strawberry Banana Smoothie");
                r.setRecipeDescription("A refreshing smoothie blending strawberries and banana with a splash of almond milk.");
                r.setRecipeInstructions("Blend strawberries, banana, and almond milk until smooth; serve immediately.");
                r.setMacroCategory("Balanced");
                r.setCalories(230);
                r.setProtein(6);
                r.setFats(4);
                r.setCarbs(50);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 87. Guacamole with Veggie Sticks
            {
                Recipe r = new Recipe();
                r.setRecipeName("Guacamole with Veggie Sticks");
                r.setRecipeDescription("Creamy homemade guacamole served with crisp carrot and cucumber sticks.");
                r.setRecipeInstructions("Mash avocados with lime juice, salt, and diced tomatoes; serve with freshly cut veggie sticks.");
                r.setMacroCategory("Balanced");
                r.setCalories(210);
                r.setProtein(4);
                r.setFats(14);
                r.setCarbs(20);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 88. Pecan and Date Bites
            {
                Recipe r = new Recipe();
                r.setRecipeName("Pecan and Date Bites");
                r.setRecipeDescription("Sweet, nutty bites made from ground pecans and chopped dates, pressed into small clusters.");
                r.setRecipeInstructions("Blend pecans and dates; form into small bites; chill until set; serve.");
                r.setMacroCategory("High Protein");
                r.setCalories(230);
                r.setProtein(7);
                r.setFats(14);
                r.setCarbs(26);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 89. Mini Quinoa Salad Cups
            {
                Recipe r = new Recipe();
                r.setRecipeName("Mini Quinoa Salad Cups");
                r.setRecipeDescription("Bite-sized cups filled with a refreshing quinoa salad mixed with diced vegetables and herbs.");
                r.setRecipeInstructions("Mix cooked quinoa with chopped vegetables and herbs; spoon into small lettuce cups; serve.");
                r.setMacroCategory("Balanced");
                r.setCalories(210);
                r.setProtein(8);
                r.setFats(7);
                r.setCarbs(30);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 90. Broccoli Tots
            {
                Recipe r = new Recipe();
                r.setRecipeName("Broccoli Tots");
                r.setRecipeDescription("Bite-sized tots made from finely chopped broccoli, bound with a bit of cheese and breadcrumbs, baked until crispy.");
                r.setRecipeInstructions("Combine steamed broccoli, cheese, and breadcrumbs; form into tots; bake until golden; serve.");
                r.setMacroCategory("Low Carb");
                r.setCalories(190);
                r.setProtein(9);
                r.setFats(8);
                r.setCarbs(18);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 91. Protein Ice Cream
            {
                Recipe r = new Recipe();
                r.setRecipeName("Protein Ice Cream");
                r.setRecipeDescription("A refreshing, high-protein frozen treat made by blending protein powder with frozen bananas and almond milk.");
                r.setRecipeInstructions("Blend frozen bananas, protein powder, and almond milk until creamy; serve immediately.");
                r.setMacroCategory("High Protein");
                r.setCalories(220);
                r.setProtein(20);
                r.setFats(6);
                r.setCarbs(28);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 92. Fig and Walnut Bites
            {
                Recipe r = new Recipe();
                r.setRecipeName("Fig and Walnut Bites");
                r.setRecipeDescription("Sweet and crunchy bites made with dried figs and walnuts for a nutrient-dense treat.");
                r.setRecipeInstructions("Finely chop figs and walnuts; mix and form into small balls; chill before serving.");
                r.setMacroCategory("Balanced");
                r.setCalories(210);
                r.setProtein(5);
                r.setFats(12);
                r.setCarbs(26);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 93. Celery and Peanut Butter Sticks
            {
                Recipe r = new Recipe();
                r.setRecipeName("Celery and Peanut Butter Sticks");
                r.setRecipeDescription("Crisp celery sticks filled with natural peanut butter for a classic, satisfying snack.");
                r.setRecipeInstructions("Fill celery sticks with peanut butter; serve immediately.");
                r.setMacroCategory("Balanced");
                r.setCalories(160);
                r.setProtein(6);
                r.setFats(10);
                r.setCarbs(12);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 94. Frozen Yogurt Bark
            {
                Recipe r = new Recipe();
                r.setRecipeName("Frozen Yogurt Bark");
                r.setRecipeDescription("Frozen Greek yogurt spread thin, topped with berries and nuts, then broken into pieces.");
                r.setRecipeInstructions("Spread Greek yogurt on a baking sheet; top with berries and nuts; freeze until firm; break into pieces; serve.");
                r.setMacroCategory("High Protein");
                r.setCalories(190);
                r.setProtein(14);
                r.setFats(6);
                r.setCarbs(22);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 95. Carrot and Hummus Cups
            {
                Recipe r = new Recipe();
                r.setRecipeName("Carrot and Hummus Cups");
                r.setRecipeDescription("Fresh carrot sticks served in a small cup with a side of creamy hummus for dipping.");
                r.setRecipeInstructions("Cut carrots into sticks; portion hummus into small cups; serve together.");
                r.setMacroCategory("Balanced");
                r.setCalories(170);
                r.setProtein(5);
                r.setFats(8);
                r.setCarbs(18);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 96. Protein Muffins
            {
                Recipe r = new Recipe();
                r.setRecipeName("Protein Muffins");
                r.setRecipeDescription("Moist muffins enriched with protein powder, oats, and blueberries for a power-packed snack.");
                r.setRecipeInstructions("Mix protein powder, oats, blueberries, and eggs; bake in muffin tins until set; serve.");
                r.setMacroCategory("High Protein");
                r.setCalories(240);
                r.setProtein(16);
                r.setFats(8);
                r.setCarbs(30);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 97. Mixed Berry Protein Smoothie
            {
                Recipe r = new Recipe();
                r.setRecipeName("Mixed Berry Protein Smoothie");
                r.setRecipeDescription("A nutrient-rich smoothie blending mixed berries, protein powder, and unsweetened almond milk.");
                r.setRecipeInstructions("Blend mixed berries, protein powder, and almond milk until smooth; serve immediately.");
                r.setMacroCategory("High Protein");
                r.setCalories(250);
                r.setProtein(20);
                r.setFats(6);
                r.setCarbs(32);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 98. Toasted Pumpkin Seeds
            {
                Recipe r = new Recipe();
                r.setRecipeName("Toasted Pumpkin Seeds");
                r.setRecipeDescription("Crunchy roasted pumpkin seeds lightly salted and spiced, perfect for a protein-packed nibble.");
                r.setRecipeInstructions("Roast pumpkin seeds with a dash of salt and spices until crisp; serve.");
                r.setMacroCategory("High Protein");
                r.setCalories(180);
                r.setProtein(9);
                r.setFats(10);
                r.setCarbs(12);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 99. Vegan Protein Balls
            {
                Recipe r = new Recipe();
                r.setRecipeName("Vegan Protein Balls");
                r.setRecipeDescription("No-bake protein balls made from dates, oats, and vegan protein powder, rolled in shredded coconut.");
                r.setRecipeInstructions("Blend dates, oats, and vegan protein powder; form into balls; roll in coconut; chill until set; serve.");
                r.setMacroCategory("High Protein");
                r.setCalories(220);
                r.setProtein(12);
                r.setFats(9);
                r.setCarbs(28);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 100. Spicy Tofu Bites
            {
                Recipe r = new Recipe();
                r.setRecipeName("Spicy Tofu Bites");
                r.setRecipeDescription("Crispy tofu cubes tossed in a spicy chili sauce, perfect for a zesty vegan snack.");
                r.setRecipeInstructions("Cube tofu; toss in a mixture of chili sauce and lime juice; bake until crispy; serve warm.");
                r.setMacroCategory("Balanced");
                r.setCalories(230);
                r.setProtein(16);
                r.setFats(12);
                r.setCarbs(20);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }
//additional recipes/snacks

             // 101. Grilled Turkey Burger
             {
                Recipe r = new Recipe();
                r.setRecipeName("Grilled Turkey Burger");
                r.setRecipeDescription("A lean turkey patty grilled to perfection, served on a whole-grain bun with fresh lettuce and tomato.");
                r.setRecipeInstructions("Form turkey meat into a patty, season, and grill until cooked through. Serve on a bun with lettuce, tomato, and a light spread.");
                r.setMacroCategory("High Protein");
                r.setCalories(600);
                r.setProtein(42);
                r.setFats(18);
                r.setCarbs(55);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 102. Vegetable Stir-Fry with Tofu
            {
                Recipe r = new Recipe();
                r.setRecipeName("Vegetable Stir-Fry with Tofu");
                r.setRecipeDescription("A colorful medley of stir-fried vegetables tossed with crispy tofu in a light soy sauce.");
                r.setRecipeInstructions("Sauté mixed vegetables and tofu cubes in a little oil with soy sauce and garlic. Serve hot.");
                r.setMacroCategory("Balanced");
                r.setCalories(520);
                r.setProtein(26);
                r.setFats(16);
                r.setCarbs(60);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 103. Herb-Roasted Chicken Thighs
            {
                Recipe r = new Recipe();
                r.setRecipeName("Herb-Roasted Chicken Thighs");
                r.setRecipeDescription("Juicy chicken thighs roasted with rosemary, thyme, and garlic.");
                r.setRecipeInstructions("Season chicken thighs with herbs, salt, and pepper; roast until golden and cooked through. Serve with a side of steamed vegetables.");
                r.setMacroCategory("High Protein");
                r.setCalories(650);
                r.setProtein(44);
                r.setFats(22);
                r.setCarbs(40);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 104. Shrimp and Avocado Salad
            {
                Recipe r = new Recipe();
                r.setRecipeName("Shrimp and Avocado Salad");
                r.setRecipeDescription("A fresh salad with grilled shrimp, avocado slices, and mixed greens drizzled with lime dressing.");
                r.setRecipeInstructions("Grill shrimp; toss with avocado, greens, and a zesty lime dressing. Serve immediately.");
                r.setMacroCategory("High Protein");
                r.setCalories(580);
                r.setProtein(40);
                r.setFats(20);
                r.setCarbs(35);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
                recipes.add(r);
            }

            // 105. Beef Stroganoff
            {
                Recipe r = new Recipe();
                r.setRecipeName("Beef Stroganoff");
                r.setRecipeDescription("Tender strips of beef simmered in a creamy mushroom sauce served over egg noodles.");
                r.setRecipeInstructions("Cook beef and mushrooms in a creamy sauce; toss with egg noodles and serve garnished with parsley.");
                r.setMacroCategory("High Protein");
                r.setCalories(720);
                r.setProtein(42);
                r.setFats(28);
                r.setCarbs(80);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 106. Pesto Zucchini Noodles
            {
                Recipe r = new Recipe();
                r.setRecipeName("Pesto Zucchini Noodles");
                r.setRecipeDescription("Zucchini noodles tossed in a fresh basil pesto with cherry tomatoes.");
                r.setRecipeInstructions("Spiralize zucchini; mix with basil pesto and halved cherry tomatoes; serve cold or at room temperature.");
                r.setMacroCategory("Low Carb");
                r.setCalories(430);
                r.setProtein(14);
                r.setFats(26);
                r.setCarbs(22);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 107. Spinach Ricotta Stuffed Shells
            {
                Recipe r = new Recipe();
                r.setRecipeName("Spinach Ricotta Stuffed Shells");
                r.setRecipeDescription("Large pasta shells stuffed with a creamy mixture of spinach and ricotta, baked in marinara sauce.");
                r.setRecipeInstructions("Fill cooked pasta shells with spinach and ricotta mix; top with marinara sauce and bake until bubbly.");
                r.setMacroCategory("Balanced");
                r.setCalories(680);
                r.setProtein(30);
                r.setFats(24);
                r.setCarbs(90);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegetarian"));
                recipes.add(r);
            }

            // 108. Lemon Herb Grilled Salmon
            {
                Recipe r = new Recipe();
                r.setRecipeName("Lemon Herb Grilled Salmon");
                r.setRecipeDescription("Salmon fillets marinated in lemon and herbs, grilled to perfection.");
                r.setRecipeInstructions("Marinate salmon with lemon, herbs, salt, and pepper; grill until flaky; serve with steamed asparagus.");
                r.setMacroCategory("High Protein");
                r.setCalories(540);
                r.setProtein(41);
                r.setFats(18);
                r.setCarbs(30);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
                recipes.add(r);
            }

            // 109. Quinoa & Black Bean Stuffed Peppers
            {
                Recipe r = new Recipe();
                r.setRecipeName("Quinoa & Black Bean Stuffed Peppers");
                r.setRecipeDescription("Bell peppers stuffed with quinoa, black beans, corn, and spices, baked until tender.");
                r.setRecipeInstructions("Fill bell peppers with a mixture of quinoa, black beans, corn, and spices; bake until peppers are soft.");
                r.setMacroCategory("Balanced");
                r.setCalories(630);
                r.setProtein(28);
                r.setFats(16);
                r.setCarbs(80);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegetarian", "gluten_free"));
                recipes.add(r);
            }

            // 110. Baked Eggplant Rollatini
            {
                Recipe r = new Recipe();
                r.setRecipeName("Baked Eggplant Rollatini");
                r.setRecipeDescription("Thin slices of eggplant rolled with ricotta and spinach, baked in marinara sauce.");
                r.setRecipeInstructions("Layer eggplant slices with a ricotta-spinach mixture; roll up and bake in marinara sauce until bubbly.");
                r.setMacroCategory("Balanced");
                r.setCalories(610);
                r.setProtein(26);
                r.setFats(20);
                r.setCarbs(65);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegetarian"));
                recipes.add(r);
            }

            // 111. Chicken Marsala
            {
                Recipe r = new Recipe();
                r.setRecipeName("Chicken Marsala");
                r.setRecipeDescription("Chicken breasts sautéed and simmered in a rich Marsala wine and mushroom sauce.");
                r.setRecipeInstructions("Sauté chicken; add mushrooms and Marsala wine; simmer until sauce thickens; serve over pasta or with veggies.");
                r.setMacroCategory("High Protein");
                r.setCalories(670);
                r.setProtein(43);
                r.setFats(20);
                r.setCarbs(60);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 112. Mushroom and Spinach Pasta
            {
                Recipe r = new Recipe();
                r.setRecipeName("Mushroom and Spinach Pasta");
                r.setRecipeDescription("Pasta tossed with sautéed mushrooms, spinach, and a light garlic cream sauce.");
                r.setRecipeInstructions("Sauté mushrooms and spinach with garlic; toss with pasta and a light cream sauce; serve with parmesan.");
                r.setMacroCategory("Balanced");
                r.setCalories(680);
                r.setProtein(24);
                r.setFats(22);
                r.setCarbs(90);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegetarian"));
                recipes.add(r);
            }

            // 113. Tofu and Vegetable Curry
            {
                Recipe r = new Recipe();
                r.setRecipeName("Tofu and Vegetable Curry");
                r.setRecipeDescription("A hearty curry featuring tofu and mixed vegetables simmered in coconut milk and spices.");
                r.setRecipeInstructions("Sauté tofu and vegetables with curry spices; add coconut milk; simmer until flavors meld; serve with rice.");
                r.setMacroCategory("Low Carb");
                r.setCalories(510);
                r.setProtein(24);
                r.setFats(18);
                r.setCarbs(48);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 114. Grilled Lamb Chops with Mint Sauce
            {
                Recipe r = new Recipe();
                r.setRecipeName("Grilled Lamb Chops with Mint Sauce");
                r.setRecipeDescription("Juicy lamb chops grilled and served with a refreshing mint sauce.");
                r.setRecipeInstructions("Season lamb chops; grill to desired doneness; serve with a homemade mint sauce.");
                r.setMacroCategory("High Protein");
                r.setCalories(720);
                r.setProtein(46);
                r.setFats(28);
                r.setCarbs(40);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 115. Roasted Cauliflower Steak
            {
                Recipe r = new Recipe();
                r.setRecipeName("Roasted Cauliflower Steak");
                r.setRecipeDescription("Thick slices of cauliflower roasted with olive oil, garlic, and spices.");
                r.setRecipeInstructions("Slice cauliflower into steaks; drizzle with olive oil and spices; roast until tender and golden.");
                r.setMacroCategory("Low Carb");
                r.setCalories(400);
                r.setProtein(12);
                r.setFats(16);
                r.setCarbs(30);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 116. Mediterranean Chickpea Salad
            {
                Recipe r = new Recipe();
                r.setRecipeName("Mediterranean Chickpea Salad");
                r.setRecipeDescription("A fresh salad with chickpeas, cucumbers, tomatoes, olives, and feta with a lemon-herb dressing.");
                r.setRecipeInstructions("Mix chickpeas with diced vegetables; toss with olive oil, lemon juice, and herbs; serve chilled.");
                r.setMacroCategory("Balanced");
                r.setCalories(600);
                r.setProtein(22);
                r.setFats(18);
                r.setCarbs(85);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 117. Seared Scallops with Garlic Lemon Butter
            {
                Recipe r = new Recipe();
                r.setRecipeName("Seared Scallops with Garlic Lemon Butter");
                r.setRecipeDescription("Delicate scallops seared to perfection and drizzled with a garlic lemon butter sauce.");
                r.setRecipeInstructions("Sear scallops in butter; add garlic and lemon juice; serve immediately with a garnish of parsley.");
                r.setMacroCategory("High Protein");
                r.setCalories(550);
                r.setProtein(40);
                r.setFats(18);
                r.setCarbs(35);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("dairy_free", "gluten_free"));
                recipes.add(r);
            }

            // 118. BBQ Pulled Pork Sandwich
            {
                Recipe r = new Recipe();
                r.setRecipeName("BBQ Pulled Pork Sandwich");
                r.setRecipeDescription("Slow-cooked pulled pork tossed in tangy barbecue sauce, served on a bun with coleslaw.");
                r.setRecipeInstructions("Cook pork until tender; shred and mix with BBQ sauce; serve on a bun with a side of coleslaw.");
                r.setMacroCategory("High Protein");
                r.setCalories(680);
                r.setProtein(42);
                r.setFats(22);
                r.setCarbs(70);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 119. Stuffed Zucchini Boats
            {
                Recipe r = new Recipe();
                r.setRecipeName("Stuffed Zucchini Boats");
                r.setRecipeDescription("Zucchini halves filled with a mixture of tomatoes, quinoa, and herbs, baked until tender.");
                r.setRecipeInstructions("Scoop zucchini halves; fill with a quinoa and tomato mixture; bake until zucchini is soft; serve warm.");
                r.setMacroCategory("Balanced");
                r.setCalories(630);
                r.setProtein(28);
                r.setFats(16);
                r.setCarbs(80);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegetarian", "gluten_free"));
                recipes.add(r);
            }

            // 120. Miso Glazed Cod
            {
                Recipe r = new Recipe();
                r.setRecipeName("Miso Glazed Cod");
                r.setRecipeDescription("Cod fillets brushed with a savory miso glaze and baked until tender.");
                r.setRecipeInstructions("Marinate cod in miso, soy sauce, and ginger; bake until flaky; serve with steamed greens.");
                r.setMacroCategory("High Protein");
                r.setCalories(540);
                r.setProtein(40);
                r.setFats(14);
                r.setCarbs(38);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
                recipes.add(r);
            }

            // 121. Pork Tenderloin with Apples
            {
                Recipe r = new Recipe();
                r.setRecipeName("Pork Tenderloin with Apples");
                r.setRecipeDescription("Roasted pork tenderloin paired with caramelized apples and a hint of cinnamon.");
                r.setRecipeInstructions("Roast pork tenderloin with apple slices and cinnamon; serve with a drizzle of pan juices.");
                r.setMacroCategory("High Protein");
                r.setCalories(650);
                r.setProtein(43);
                r.setFats(20);
                r.setCarbs(55);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 122. Chicken Piccata
            {
                Recipe r = new Recipe();
                r.setRecipeName("Chicken Piccata");
                r.setRecipeDescription("Chicken breasts sautéed in a lemon caper sauce, served over a light bed of pasta.");
                r.setRecipeInstructions("Sauté chicken; add lemon juice, capers, and a splash of white wine; simmer briefly and serve.");
                r.setMacroCategory("High Protein");
                r.setCalories(640);
                r.setProtein(44);
                r.setFats(18);
                r.setCarbs(60);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("dairy_free", "gluten_free"));
                recipes.add(r);
            }

            // 123. Thai Beef Salad
            {
                Recipe r = new Recipe();
                r.setRecipeName("Thai Beef Salad");
                r.setRecipeDescription("Slices of grilled beef tossed with mixed greens, herbs, and a spicy Thai lime dressing.");
                r.setRecipeInstructions("Grill beef; slice thinly; toss with greens and a spicy lime dressing; serve chilled.");
                r.setMacroCategory("High Protein");
                r.setCalories(600);
                r.setProtein(42);
                r.setFats(18);
                r.setCarbs(45);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
                recipes.add(r);
            }

            // 124. Vegetarian Chili
            {
                Recipe r = new Recipe();
                r.setRecipeName("Vegetarian Chili");
                r.setRecipeDescription("A hearty chili loaded with beans, tomatoes, and spices, perfect for a comforting meal.");
                r.setRecipeInstructions("Combine beans, tomatoes, and chili spices; simmer for an hour; serve hot with a garnish of cilantro.");
                r.setMacroCategory("Balanced");
                r.setCalories(620);
                r.setProtein(24);
                r.setFats(18);
                r.setCarbs(80);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 125. Grilled Shrimp Skewers with Pineapple
            {
                Recipe r = new Recipe();
                r.setRecipeName("Grilled Shrimp Skewers with Pineapple");
                r.setRecipeDescription("Juicy shrimp and pineapple chunks skewered and grilled, offering a sweet and savory flavor.");
                r.setRecipeInstructions("Thread shrimp and pineapple onto skewers; grill until shrimp are pink; serve with a squeeze of lime.");
                r.setMacroCategory("High Protein");
                r.setCalories(580);
                r.setProtein(40);
                r.setFats(16);
                r.setCarbs(50);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
                recipes.add(r);
            }

            // 126. Spaghetti Carbonara
            {
                Recipe r = new Recipe();
                r.setRecipeName("Spaghetti Carbonara");
                r.setRecipeDescription("Classic pasta dish with eggs, parmesan, and turkey bacon for a lighter twist.");
                r.setRecipeInstructions("Cook spaghetti; toss with beaten eggs, parmesan, and crispy turkey bacon; serve immediately.");
                r.setMacroCategory("Balanced");
                r.setCalories(700);
                r.setProtein(35);
                r.setFats(26);
                r.setCarbs(85);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 127. Roasted Red Pepper Soup
            {
                Recipe r = new Recipe();
                r.setRecipeName("Roasted Red Pepper Soup");
                r.setRecipeDescription("A silky, roasted red pepper soup with a touch of cream and fresh basil.");
                r.setRecipeInstructions("Roast red peppers; blend with vegetable broth and a splash of cream; simmer and serve garnished with basil.");
                r.setMacroCategory("Balanced");
                r.setCalories(610);
                r.setProtein(18);
                r.setFats(22);
                r.setCarbs(85);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegetarian", "gluten_free"));
                recipes.add(r);
            }

            // 128. Chicken Alfredo with Broccoli
            {
                Recipe r = new Recipe();
                r.setRecipeName("Chicken Alfredo with Broccoli");
                r.setRecipeDescription("Grilled chicken served over fettuccine in a light alfredo sauce with steamed broccoli.");
                r.setRecipeInstructions("Grill chicken; cook fettuccine and broccoli; toss with a light alfredo sauce; serve warm.");
                r.setMacroCategory("High Protein");
                r.setCalories(720);
                r.setProtein(42);
                r.setFats(24);
                r.setCarbs(80);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 129. Veggie Quesadilla
            {
                Recipe r = new Recipe();
                r.setRecipeName("Veggie Quesadilla");
                r.setRecipeDescription("Whole-grain quesadilla filled with sautéed bell peppers, onions, and cheese.");
                r.setRecipeInstructions("Sauté vegetables; sandwich between tortillas with cheese; cook on a griddle until crispy; serve with salsa.");
                r.setMacroCategory("Balanced");
                r.setCalories(650);
                r.setProtein(22);
                r.setFats(20);
                r.setCarbs(85);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegetarian"));
                recipes.add(r);
            }

            // 130. Beef and Vegetable Kebabs
            {
                Recipe r = new Recipe();
                r.setRecipeName("Beef and Vegetable Kebabs");
                r.setRecipeDescription("Skewered beef cubes and vegetables marinated in herbs and grilled to perfection.");
                r.setRecipeInstructions("Marinate beef and vegetables; thread onto skewers; grill until desired doneness; serve with a side of rice.");
                r.setMacroCategory("High Protein");
                r.setCalories(700);
                r.setProtein(45);
                r.setFats(22);
                r.setCarbs(70);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 131. Lentil and Spinach Stew
            {
                Recipe r = new Recipe();
                r.setRecipeName("Lentil and Spinach Stew");
                r.setRecipeDescription("A hearty stew of lentils and spinach simmered with tomatoes and spices.");
                r.setRecipeInstructions("Combine lentils, spinach, tomatoes, and spices; simmer until lentils are tender; serve hot.");
                r.setMacroCategory("Balanced");
                r.setCalories(620);
                r.setProtein(24);
                r.setFats(16);
                r.setCarbs(85);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 132. Fish Tacos with Mango Salsa
            {
                Recipe r = new Recipe();
                r.setRecipeName("Fish Tacos with Mango Salsa");
                r.setRecipeDescription("Light fish tacos topped with a fresh mango salsa and shredded cabbage.");
                r.setRecipeInstructions("Grill or fry fish; serve in tortillas with mango salsa and cabbage slaw.");
                r.setMacroCategory("High Protein");
                r.setCalories(630);
                r.setProtein(40);
                r.setFats(18);
                r.setCarbs(60);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
                recipes.add(r);
            }

            // 133. Grilled Portobello Burger
            {
                Recipe r = new Recipe();
                r.setRecipeName("Grilled Portobello Burger");
                r.setRecipeDescription("A hearty vegetarian burger using grilled Portobello mushrooms served on a whole-grain bun.");
                r.setRecipeInstructions("Grill Portobello mushrooms; serve on a bun with lettuce, tomato, and a light mayo.");
                r.setMacroCategory("Low Carb");
                r.setCalories(600);
                r.setProtein(18);
                r.setFats(16);
                r.setCarbs(50);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegetarian", "gluten_free"));
                recipes.add(r);
            }

            // 134. Butternut Squash Risotto
            {
                Recipe r = new Recipe();
                r.setRecipeName("Butternut Squash Risotto");
                r.setRecipeDescription("Creamy risotto featuring roasted butternut squash and a hint of sage.");
                r.setRecipeInstructions("Roast butternut squash; cook Arborio rice with broth; stir in squash and sage; finish with parmesan.");
                r.setMacroCategory("Balanced");
                r.setCalories(680);
                r.setProtein(18);
                r.setFats(22);
                r.setCarbs(95);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegetarian"));
                recipes.add(r);
            }

            // 135. Herbed Quinoa with Roasted Vegetables
            {
                Recipe r = new Recipe();
                r.setRecipeName("Herbed Quinoa with Roasted Vegetables");
                r.setRecipeDescription("Fluffy quinoa tossed with a medley of roasted vegetables and fresh herbs.");
                r.setRecipeInstructions("Roast vegetables; mix with cooked quinoa and chopped herbs; drizzle with olive oil; serve warm.");
                r.setMacroCategory("Balanced");
                r.setCalories(640);
                r.setProtein(22);
                r.setFats(18);
                r.setCarbs(85);
                r.setMealType("Meal");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // -------------------------------
            // EXTRA SNACKS (Recipes 136-170)
            // -------------------------------

            // 136. Crispy Kale Chips
            {
                Recipe r = new Recipe();
                r.setRecipeName("Crispy Kale Chips");
                r.setRecipeDescription("Baked kale leaves seasoned with salt and olive oil until crisp.");
                r.setRecipeInstructions("Toss kale with olive oil and salt; bake until crispy; serve as a healthy snack.");
                r.setMacroCategory("Low Carb");
                r.setCalories(140);
                r.setProtein(4);
                r.setFats(8);
                r.setCarbs(10);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 137. Apple Cinnamon Energy Bites
            {
                Recipe r = new Recipe();
                r.setRecipeName("Apple Cinnamon Energy Bites");
                r.setRecipeDescription("No-bake bites made with dried apple, oats, and a sprinkle of cinnamon.");
                r.setRecipeInstructions("Mix oats, dried apple, cinnamon, and a binding syrup; form into balls; chill until firm; serve.");
                r.setMacroCategory("High Protein");
                r.setCalories(200);
                r.setProtein(8);
                r.setFats(6);
                r.setCarbs(28);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 138. Mini Veggie Wraps
            {
                Recipe r = new Recipe();
                r.setRecipeName("Mini Veggie Wraps");
                r.setRecipeDescription("Small wraps filled with hummus, shredded carrots, and leafy greens.");
                r.setRecipeInstructions("Spread hummus on mini tortillas; add veggies; roll tightly; slice and serve.");
                r.setMacroCategory("Balanced");
                r.setCalories(210);
                r.setProtein(6);
                r.setFats(8);
                r.setCarbs(25);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 139. Cottage Cheese and Berry Bowl
            {
                Recipe r = new Recipe();
                r.setRecipeName("Cottage Cheese and Berry Bowl");
                r.setRecipeDescription("A simple bowl of cottage cheese mixed with fresh berries.");
                r.setRecipeInstructions("Mix cottage cheese with assorted berries; drizzle with a little honey; serve chilled.");
                r.setMacroCategory("High Protein");
                r.setCalories(230);
                r.setProtein(20);
                r.setFats(8);
                r.setCarbs(22);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 140. Roasted Chickpea Snack
            {
                Recipe r = new Recipe();
                r.setRecipeName("Roasted Chickpea Snack");
                r.setRecipeDescription("Crunchy roasted chickpeas seasoned with paprika and garlic.");
                r.setRecipeInstructions("Toss chickpeas with olive oil and spices; roast until crispy; serve warm.");
                r.setMacroCategory("High Protein");
                r.setCalories(210);
                r.setProtein(10);
                r.setFats(6);
                r.setCarbs(30);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 141. Banana Nut Bars
            {
                Recipe r = new Recipe();
                r.setRecipeName("Banana Nut Bars");
                r.setRecipeDescription("Homemade bars made with mashed banana, oats, and chopped nuts.");
                r.setRecipeInstructions("Combine mashed banana, oats, and nuts; press into a pan; bake until set; cool and cut into bars.");
                r.setMacroCategory("High Protein");
                r.setCalories(250);
                r.setProtein(10);
                r.setFats(10);
                r.setCarbs(35);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 142. Edamame Hummus with Pita
            {
                Recipe r = new Recipe();
                r.setRecipeName("Edamame Hummus with Pita");
                r.setRecipeDescription("A twist on classic hummus using edamame, served with whole-grain pita.");
                r.setRecipeInstructions("Blend edamame, garlic, lemon juice, and tahini until smooth; serve with pita wedges.");
                r.setMacroCategory("High Protein");
                r.setCalories(240);
                r.setProtein(12);
                r.setFats(8);
                r.setCarbs(30);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 143. Protein Smoothie Shot
            {
                Recipe r = new Recipe();
                r.setRecipeName("Protein Smoothie Shot");
                r.setRecipeDescription("A small, concentrated protein smoothie made with berries and protein powder.");
                r.setRecipeInstructions("Blend berries, protein powder, and a splash of almond milk; serve in a shot glass.");
                r.setMacroCategory("High Protein");
                r.setCalories(180);
                r.setProtein(15);
                r.setFats(4);
                r.setCarbs(22);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 144. Carrot Sticks with Tahini Dip
            {
                Recipe r = new Recipe();
                r.setRecipeName("Carrot Sticks with Tahini Dip");
                r.setRecipeDescription("Crunchy carrot sticks served with a creamy tahini dipping sauce.");
                r.setRecipeInstructions("Cut carrots into sticks; mix tahini with lemon juice and water for a dip; serve together.");
                r.setMacroCategory("Balanced");
                r.setCalories(200);
                r.setProtein(5);
                r.setFats(10);
                r.setCarbs(25);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 145. Cucumber and Mint Yogurt Dip
            {
                Recipe r = new Recipe();
                r.setRecipeName("Cucumber and Mint Yogurt Dip");
                r.setRecipeDescription("A refreshing dip made with Greek yogurt, cucumber, and fresh mint.");
                r.setRecipeInstructions("Mix Greek yogurt with grated cucumber and chopped mint; season with salt and pepper; chill and serve with veggie sticks.");
                r.setMacroCategory("High Protein");
                r.setCalories(220);
                r.setProtein(14);
                r.setFats(8);
                r.setCarbs(24);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 146. Almond Butter Rice Crisps
            {
                Recipe r = new Recipe();
                r.setRecipeName("Almond Butter Rice Crisps");
                r.setRecipeDescription("Crispy rice cakes topped with a spread of almond butter.");
                r.setRecipeInstructions("Spread almond butter on rice crisps; optionally top with sliced banana; serve as a quick snack.");
                r.setMacroCategory("Balanced");
                r.setCalories(210);
                r.setProtein(7);
                r.setFats(10);
                r.setCarbs(25);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 147. Berry Protein Popsicles
            {
                Recipe r = new Recipe();
                r.setRecipeName("Berry Protein Popsicles");
                r.setRecipeDescription("Frozen popsicles made with blended berries and protein powder.");
                r.setRecipeInstructions("Blend berries with protein powder and a little water; pour into molds; freeze until solid; serve.");
                r.setMacroCategory("High Protein");
                r.setCalories(230);
                r.setProtein(18);
                r.setFats(4);
                r.setCarbs(30);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 148. Mixed Seed Trail Mix
            {
                Recipe r = new Recipe();
                r.setRecipeName("Mixed Seed Trail Mix");
                r.setRecipeDescription("A healthy mix of pumpkin, sunflower, and chia seeds with a few dried cranberries.");
                r.setRecipeInstructions("Combine pumpkin, sunflower, and chia seeds with dried cranberries; portion out for a snack.");
                r.setMacroCategory("Balanced");
                r.setCalories(210);
                r.setProtein(8);
                r.setFats(12);
                r.setCarbs(22);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 149. Crispy Seaweed Snacks
            {
                Recipe r = new Recipe();
                r.setRecipeName("Crispy Seaweed Snacks");
                r.setRecipeDescription("Light and crunchy seaweed sheets seasoned with a touch of salt.");
                r.setRecipeInstructions("Bake or microwave seaweed sheets until crisp; sprinkle lightly with salt; serve as a low-calorie snack.");
                r.setMacroCategory("Low Carb");
                r.setCalories(120);
                r.setProtein(3);
                r.setFats(2);
                r.setCarbs(18);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 150. Orange Slices with Pistachios
            {
                Recipe r = new Recipe();
                r.setRecipeName("Orange Slices with Pistachios");
                r.setRecipeDescription("Juicy orange slices paired with a handful of salted pistachios.");
                r.setRecipeInstructions("Peel and segment an orange; serve with a side of lightly salted pistachios.");
                r.setMacroCategory("Balanced");
                r.setCalories(220);
                r.setProtein(6);
                r.setFats(10);
                r.setCarbs(28);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 151. Frozen Fruit Yogurt Cups
            {
                Recipe r = new Recipe();
                r.setRecipeName("Frozen Fruit Yogurt Cups");
                r.setRecipeDescription("Greek yogurt mixed with chopped fruits, frozen in small cups.");
                r.setRecipeInstructions("Mix Greek yogurt with diced fruits; spoon into silicone molds; freeze until firm; serve as a refreshing snack.");
                r.setMacroCategory("High Protein");
                r.setCalories(230);
                r.setProtein(18);
                r.setFats(7);
                r.setCarbs(28);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 152. Protein-Packed Granola Bars
            {
                Recipe r = new Recipe();
                r.setRecipeName("Protein-Packed Granola Bars");
                r.setRecipeDescription("Homemade granola bars loaded with oats, nuts, and protein powder.");
                r.setRecipeInstructions("Mix oats, chopped nuts, and protein powder with a binding syrup; press into a pan; bake until set; cool and cut into bars.");
                r.setMacroCategory("High Protein");
                r.setCalories(240);
                r.setProtein(18);
                r.setFats(9);
                r.setCarbs(30);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 153. Spiced Apple Chips
            {
                Recipe r = new Recipe();
                r.setRecipeName("Spiced Apple Chips");
                r.setRecipeDescription("Thinly sliced apples baked until crisp and sprinkled with cinnamon.");
                r.setRecipeInstructions("Slice apples very thin; sprinkle with cinnamon; bake at a low temperature until crisp; serve.");
                r.setMacroCategory("Low Carb");
                r.setCalories(140);
                r.setProtein(2);
                r.setFats(1);
                r.setCarbs(32);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 154. Pumpkin Spice Energy Balls
            {
                Recipe r = new Recipe();
                r.setRecipeName("Pumpkin Spice Energy Balls");
                r.setRecipeDescription("No-bake energy balls made with pumpkin puree, oats, and pumpkin spice.");
                r.setRecipeInstructions("Mix pumpkin puree, oats, and pumpkin spice; form into balls; refrigerate until firm; serve.");
                r.setMacroCategory("High Protein");
                r.setCalories(210);
                r.setProtein(10);
                r.setFats(8);
                r.setCarbs(26);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 155. Choco-Dipped Strawberries
            {
                Recipe r = new Recipe();
                r.setRecipeName("Choco-Dipped Strawberries");
                r.setRecipeDescription("Fresh strawberries dipped in dark chocolate for a sweet, nutrient-rich snack.");
                r.setRecipeInstructions("Dip clean strawberries in melted dark chocolate; allow to set; serve chilled.");
                r.setMacroCategory("Balanced");
                r.setCalories(180);
                r.setProtein(3);
                r.setFats(10);
                r.setCarbs(22);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 156. Roasted Almonds with Sea Salt
            {
                Recipe r = new Recipe();
                r.setRecipeName("Roasted Almonds with Sea Salt");
                r.setRecipeDescription("Crunchy roasted almonds lightly seasoned with sea salt.");
                r.setRecipeInstructions("Roast almonds in the oven with a sprinkle of sea salt until golden; serve as a protein-packed snack.");
                r.setMacroCategory("High Protein");
                r.setCalories(200);
                r.setProtein(8);
                r.setFats(14);
                r.setCarbs(16);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 157. Zesty Lemon Cashews
            {
                Recipe r = new Recipe();
                r.setRecipeName("Zesty Lemon Cashews");
                r.setRecipeDescription("Roasted cashews tossed in a zesty lemon seasoning for a flavorful snack.");
                r.setRecipeInstructions("Roast cashews; toss with lemon zest and a pinch of salt; serve once cooled.");
                r.setMacroCategory("Balanced");
                r.setCalories(210);
                r.setProtein(7);
                r.setFats(14);
                r.setCarbs(18);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 158. Cranberry Almond Clusters
            {
                Recipe r = new Recipe();
                r.setRecipeName("Cranberry Almond Clusters");
                r.setRecipeDescription("Clusters of almonds and dried cranberries bound with a touch of honey.");
                r.setRecipeInstructions("Mix almonds with dried cranberries and a bit of honey; form clusters; chill until set; serve.");
                r.setMacroCategory("Balanced");
                r.setCalories(230);
                r.setProtein(8);
                r.setFats(15);
                r.setCarbs(24);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 159. Avocado Lime Guacamole Cups
            {
                Recipe r = new Recipe();
                r.setRecipeName("Avocado Lime Guacamole Cups");
                r.setRecipeDescription("Fresh guacamole served in mini lettuce cups with a squeeze of lime.");
                r.setRecipeInstructions("Mash avocado with lime juice, salt, and diced tomatoes; spoon into lettuce cups; serve.");
                r.setMacroCategory("Balanced");
                r.setCalories(220);
                r.setProtein(5);
                r.setFats(15);
                r.setCarbs(20);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 160. Gingered Carrot Juice Shot
            {
                Recipe r = new Recipe();
                r.setRecipeName("Gingered Carrot Juice Shot");
                r.setRecipeDescription("A quick shot of fresh carrot juice with a zing of ginger.");
                r.setRecipeInstructions("Juice fresh carrots and add a small amount of ginger juice; serve chilled as an energy booster.");
                r.setMacroCategory("Low Carb");
                r.setCalories(100);
                r.setProtein(2);
                r.setFats(1);
                r.setCarbs(22);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // 161. Sunflower Seed Bars
            {
                Recipe r = new Recipe();
                r.setRecipeName("Sunflower Seed Bars");
                r.setRecipeDescription("Homemade bars featuring sunflower seeds, oats, and a touch of honey.");
                r.setRecipeInstructions("Mix sunflower seeds, oats, and honey; press into a pan; bake until set; cool and cut into bars.");
                r.setMacroCategory("High Protein");
                r.setCalories(230);
                r.setProtein(9);
                r.setFats(10);
                r.setCarbs(28);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 162. Mango Protein Smoothie
            {
                Recipe r = new Recipe();
                r.setRecipeName("Mango Protein Smoothie");
                r.setRecipeDescription("A refreshing smoothie made with fresh mango, protein powder, and almond milk.");
                r.setRecipeInstructions("Blend mango, protein powder, and almond milk until smooth; serve immediately.");
                r.setMacroCategory("High Protein");
                r.setCalories(240);
                r.setProtein(20);
                r.setFats(6);
                r.setCarbs(32);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 163. Raspberry Chia Jam on Toast
            {
                Recipe r = new Recipe();
                r.setRecipeName("Raspberry Chia Jam on Toast");
                r.setRecipeDescription("Whole-grain toast topped with homemade raspberry chia jam.");
                r.setRecipeInstructions("Simmer raspberries with chia seeds; spread on toasted bread; serve immediately.");
                r.setMacroCategory("Balanced");
                r.setCalories(220);
                r.setProtein(6);
                r.setFats(8);
                r.setCarbs(30);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegetarian", "gluten_free"));
                recipes.add(r);
            }

            // 164. Pineapple Coconut Energy Balls
            {
                Recipe r = new Recipe();
                r.setRecipeName("Pineapple Coconut Energy Balls");
                r.setRecipeDescription("No-bake energy balls made with pineapple, coconut, and oats.");
                r.setRecipeInstructions("Blend pineapple, oats, and a bit of coconut milk; form into balls; refrigerate until firm; serve.");
                r.setMacroCategory("High Protein");
                r.setCalories(210);
                r.setProtein(10);
                r.setFats(9);
                r.setCarbs(26);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 165. Berry Medley Frozen Yogurt
            {
                Recipe r = new Recipe();
                r.setRecipeName("Berry Medley Frozen Yogurt");
                r.setRecipeDescription("Greek yogurt blended with a medley of berries and frozen into a refreshing treat.");
                r.setRecipeInstructions("Blend Greek yogurt with mixed berries; freeze in a shallow tray; break into pieces once set; serve.");
                r.setMacroCategory("High Protein");
                r.setCalories(230);
                r.setProtein(18);
                r.setFats(7);
                r.setCarbs(28);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 166. Chocolate Protein Mug Cake
            {
                Recipe r = new Recipe();
                r.setRecipeName("Chocolate Protein Mug Cake");
                r.setRecipeDescription("A quick and easy mug cake made with protein powder and cocoa, perfect for a snack.");
                r.setRecipeInstructions("Mix protein powder, cocoa, egg, and a bit of almond milk in a mug; microwave until set; serve warm.");
                r.setMacroCategory("High Protein");
                r.setCalories(240);
                r.setProtein(18);
                r.setFats(8);
                r.setCarbs(30);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 167. Peach Protein Smoothie
            {
                Recipe r = new Recipe();
                r.setRecipeName("Peach Protein Smoothie");
                r.setRecipeDescription("A smooth blend of fresh peaches, protein powder, and almond milk.");
                r.setRecipeInstructions("Blend peaches, protein powder, and almond milk until smooth; serve immediately.");
                r.setMacroCategory("High Protein");
                r.setCalories(230);
                r.setProtein(20);
                r.setFats(6);
                r.setCarbs(32);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 168. Spinach and Feta Mini Quiches
            {
                Recipe r = new Recipe();
                r.setRecipeName("Spinach and Feta Mini Quiches");
                r.setRecipeDescription("Mini quiches filled with spinach, feta, and eggs, perfect for a protein-rich snack.");
                r.setRecipeInstructions("Mix eggs with spinach and feta; pour into mini muffin tins; bake until set; serve warm.");
                r.setMacroCategory("High Protein");
                r.setCalories(250);
                r.setProtein(16);
                r.setFats(10);
                r.setCarbs(28);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("gluten_free"));
                recipes.add(r);
            }

            // 169. Apple Almond Butter Rice Cake
            {
                Recipe r = new Recipe();
                r.setRecipeName("Apple Almond Butter Rice Cake");
                r.setRecipeDescription("Rice cake topped with almond butter and thin apple slices for a crunchy, nutritious snack.");
                r.setRecipeInstructions("Spread almond butter on a rice cake; top with thin apple slices; serve immediately.");
                r.setMacroCategory("Balanced");
                r.setCalories(210);
                r.setProtein(7);
                r.setFats(10);
                r.setCarbs(25);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("dairy_free"));
                recipes.add(r);
            }

            // 170. Spiced Pomegranate Seeds
            {
                Recipe r = new Recipe();
                r.setRecipeName("Spiced Pomegranate Seeds");
                r.setRecipeDescription("A light, refreshing snack of pomegranate seeds tossed with a pinch of cinnamon and chili powder.");
                r.setRecipeInstructions("Toss pomegranate seeds with a little cinnamon and chili powder; serve chilled as a zesty snack.");
                r.setMacroCategory("Low Carb");
                r.setCalories(150);
                r.setProtein(3);
                r.setFats(2);
                r.setCarbs(28);
                r.setMealType("Snack");
                r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
                recipes.add(r);
            }

            // -------------------------------
// Additional Generated Recipes - Meals (Recipes 171-220)
// -------------------------------

// 171. Mediterranean Grilled Vegetables Wrap
{
    Recipe r = new Recipe();
    r.setRecipeName("Mediterranean Grilled Vegetables Wrap");
    r.setRecipeDescription("A wrap filled with grilled zucchini, eggplant, red peppers, and crumbled feta, drizzled with olive oil and lemon juice.");
    r.setRecipeInstructions("Grill sliced vegetables until tender; assemble in a whole-grain wrap with crumbled feta and a drizzle of olive oil and lemon juice; serve warm.");
    r.setMacroCategory("Balanced");
    r.setCalories(550);
    r.setProtein(18);
    r.setFats(20);
    r.setCarbs(70);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("vegetarian", "gluten_free"));
    recipes.add(r);
}

// 172. Herbed Chicken with Quinoa Salad
{
    Recipe r = new Recipe();
    r.setRecipeName("Herbed Chicken with Quinoa Salad");
    r.setRecipeDescription("Grilled chicken breast served over a bed of quinoa mixed with fresh herbs and diced vegetables.");
    r.setRecipeInstructions("Marinate chicken with herbs and lemon; grill until cooked through; serve sliced over quinoa tossed with cucumber, tomato, and parsley.");
    r.setMacroCategory("High Protein");
    r.setCalories(620);
    r.setProtein(45);
    r.setFats(15);
    r.setCarbs(60);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 173. Grilled Shrimp with Avocado Salsa
{
    Recipe r = new Recipe();
    r.setRecipeName("Grilled Shrimp with Avocado Salsa");
    r.setRecipeDescription("Juicy grilled shrimp paired with a zesty avocado, tomato, and red onion salsa.");
    r.setRecipeInstructions("Season shrimp with chili and lime; grill quickly; toss diced avocado, tomato, and red onion with lime juice; serve together.");
    r.setMacroCategory("High Protein");
    r.setCalories(580);
    r.setProtein(42);
    r.setFats(18);
    r.setCarbs(45);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
    recipes.add(r);
}

// 174. Spicy Beef and Broccoli Bowl
{
    Recipe r = new Recipe();
    r.setRecipeName("Spicy Beef and Broccoli Bowl");
    r.setRecipeDescription("Thinly sliced beef stir-fried with broccoli in a spicy garlic sauce served over brown rice.");
    r.setRecipeInstructions("Marinate beef in soy and chili sauce; stir-fry with broccoli and garlic; serve over a small portion of brown rice.");
    r.setMacroCategory("High Protein");
    r.setCalories(700);
    r.setProtein(48);
    r.setFats(22);
    r.setCarbs(65);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("dairy_free"));
    recipes.add(r);
}

// 175. Roasted Turkey with Cranberry Sauce
{
    Recipe r = new Recipe();
    r.setRecipeName("Roasted Turkey with Cranberry Sauce");
    r.setRecipeDescription("Oven-roasted turkey breast paired with a tangy homemade cranberry sauce.");
    r.setRecipeInstructions("Season turkey breast and roast until golden; simmer cranberries with orange juice and a touch of honey; serve together.");
    r.setMacroCategory("High Protein");
    r.setCalories(680);
    r.setProtein(46);
    r.setFats(18);
    r.setCarbs(55);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 176. Pan-Seared Tuna Steak
{
    Recipe r = new Recipe();
    r.setRecipeName("Pan-Seared Tuna Steak");
    r.setRecipeDescription("A succulent tuna steak seasoned with black pepper and sea salt, served with a side salad.");
    r.setRecipeInstructions("Sear tuna steak on high heat for a few minutes per side to keep the center rare; serve with mixed greens dressed lightly with olive oil and lemon.");
    r.setMacroCategory("High Protein");
    r.setCalories(520);
    r.setProtein(43);
    r.setFats(14);
    r.setCarbs(30);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
    recipes.add(r);
}

// 177. Mushroom Spinach Stuffed Chicken Breast
{
    Recipe r = new Recipe();
    r.setRecipeName("Mushroom Spinach Stuffed Chicken Breast");
    r.setRecipeDescription("Chicken breast stuffed with sautéed mushrooms and spinach, baked to juicy perfection.");
    r.setRecipeInstructions("Sauté mushrooms and spinach with garlic; slit chicken breasts and stuff with the mixture; bake until cooked through.");
    r.setMacroCategory("High Protein");
    r.setCalories(630);
    r.setProtein(47);
    r.setFats(16);
    r.setCarbs(40);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 178. Cajun Grilled Salmon
{
    Recipe r = new Recipe();
    r.setRecipeName("Cajun Grilled Salmon");
    r.setRecipeDescription("Salmon fillet rubbed with Cajun spices and grilled, served with a squeeze of fresh lemon.");
    r.setRecipeInstructions("Rub salmon with Cajun seasoning; grill until flaky; serve with lemon wedges and a side of steamed broccoli.");
    r.setMacroCategory("High Protein");
    r.setCalories(540);
    r.setProtein(42);
    r.setFats(20);
    r.setCarbs(32);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
    recipes.add(r);
}

// 179. Balsamic Glazed Pork Tenderloin
{
    Recipe r = new Recipe();
    r.setRecipeName("Balsamic Glazed Pork Tenderloin");
    r.setRecipeDescription("Tender pork tenderloin with a tangy balsamic glaze, served with roasted Brussels sprouts.");
    r.setRecipeInstructions("Roast pork tenderloin brushed with a balsamic reduction; serve with roasted Brussels sprouts and carrots.");
    r.setMacroCategory("High Protein");
    r.setCalories(660);
    r.setProtein(44);
    r.setFats(19);
    r.setCarbs(50);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 180. Szechuan Beef Lettuce Wraps
{
    Recipe r = new Recipe();
    r.setRecipeName("Szechuan Beef Lettuce Wraps");
    r.setRecipeDescription("Spicy Szechuan beef served in crisp lettuce leaves with shredded carrots and a drizzle of hoisin.");
    r.setRecipeInstructions("Stir-fry beef with Szechuan sauce and veggies; spoon into lettuce cups; garnish with chopped peanuts.");
    r.setMacroCategory("High Protein");
    r.setCalories(640);
    r.setProtein(46);
    r.setFats(20);
    r.setCarbs(55);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("dairy_free"));
    recipes.add(r);
}

// 181. Roasted Vegetable Pasta
{
    Recipe r = new Recipe();
    r.setRecipeName("Roasted Vegetable Pasta");
    r.setRecipeDescription("Pasta tossed with a medley of oven-roasted vegetables and a light garlic tomato sauce.");
    r.setRecipeInstructions("Roast seasonal vegetables; mix with cooked pasta and garlic tomato sauce; finish with fresh basil.");
    r.setMacroCategory("Balanced");
    r.setCalories(710);
    r.setProtein(24);
    r.setFats(22);
    r.setCarbs(105);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("vegetarian"));
    recipes.add(r);
}

// 182. Herbed Lamb Chops with Mint Yogurt
{
    Recipe r = new Recipe();
    r.setRecipeName("Herbed Lamb Chops with Mint Yogurt");
    r.setRecipeDescription("Juicy lamb chops grilled with rosemary and thyme, served with a cooling mint yogurt sauce.");
    r.setRecipeInstructions("Grill lamb chops seasoned with herbs; serve with a side of mint yogurt sauce and a fresh salad.");
    r.setMacroCategory("High Protein");
    r.setCalories(750);
    r.setProtein(48);
    r.setFats(28);
    r.setCarbs(35);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 183. Lemon Garlic Tilapia
{
    Recipe r = new Recipe();
    r.setRecipeName("Lemon Garlic Tilapia");
    r.setRecipeDescription("Light tilapia fillets baked with lemon, garlic, and fresh dill.");
    r.setRecipeInstructions("Season tilapia with lemon, garlic, and dill; bake until flaky; serve with steamed green beans.");
    r.setMacroCategory("High Protein");
    r.setCalories(510);
    r.setProtein(41);
    r.setFats(12);
    r.setCarbs(38);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
    recipes.add(r);
}

// 184. Vegetarian Stuffed Acorn Squash
{
    Recipe r = new Recipe();
    r.setRecipeName("Vegetarian Stuffed Acorn Squash");
    r.setRecipeDescription("Roasted acorn squash halves filled with a savory mixture of wild rice, cranberries, and nuts.");
    r.setRecipeInstructions("Roast acorn squash; fill with cooked wild rice, cranberries, and toasted walnuts; bake briefly and serve.");
    r.setMacroCategory("Balanced");
    r.setCalories(600);
    r.setProtein(15);
    r.setFats(22);
    r.setCarbs(85);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("vegetarian", "gluten_free"));
    recipes.add(r);
}

// 185. Chicken and Wild Rice Casserole
{
    Recipe r = new Recipe();
    r.setRecipeName("Chicken and Wild Rice Casserole");
    r.setRecipeDescription("A comforting casserole combining shredded chicken, wild rice, and vegetables in a light cream sauce.");
    r.setRecipeInstructions("Mix cooked wild rice, shredded chicken, and mixed vegetables with a light cream sauce; bake until bubbly.");
    r.setMacroCategory("High Protein");
    r.setCalories(680);
    r.setProtein(44);
    r.setFats(20);
    r.setCarbs(70);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 186. Pesto Chicken with Zoodles
{
    Recipe r = new Recipe();
    r.setRecipeName("Pesto Chicken with Zoodles");
    r.setRecipeDescription("Grilled chicken tossed with zucchini noodles and a vibrant basil pesto.");
    r.setRecipeInstructions("Grill chicken and slice; spiralize zucchini; toss with basil pesto and serve immediately.");
    r.setMacroCategory("High Protein");
    r.setCalories(580);
    r.setProtein(42);
    r.setFats(18);
    r.setCarbs(35);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
    recipes.add(r);
}

// 187. Spicy Chickpea and Spinach Curry
{
    Recipe r = new Recipe();
    r.setRecipeName("Spicy Chickpea and Spinach Curry");
    r.setRecipeDescription("A hearty vegan curry with chickpeas and spinach simmered in a spiced tomato sauce.");
    r.setRecipeInstructions("Sauté onions and garlic; add chickpeas, tomatoes, and spices; simmer and stir in fresh spinach at the end.");
    r.setMacroCategory("Balanced");
    r.setCalories(540);
    r.setProtein(20);
    r.setFats(16);
    r.setCarbs(70);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 188. Grilled Portobello Steak
{
    Recipe r = new Recipe();
    r.setRecipeName("Grilled Portobello Steak");
    r.setRecipeDescription("Marinated Portobello mushrooms grilled to perfection as a hearty vegetarian main.");
    r.setRecipeInstructions("Marinate Portobello caps in balsamic vinegar and garlic; grill until tender; serve with a side salad.");
    r.setMacroCategory("Low Carb");
    r.setCalories(430);
    r.setProtein(12);
    r.setFats(18);
    r.setCarbs(28);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("vegetarian", "gluten_free"));
    recipes.add(r);
}

// 189. Teriyaki Salmon Bowl
{
    Recipe r = new Recipe();
    r.setRecipeName("Teriyaki Salmon Bowl");
    r.setRecipeDescription("Grilled salmon glazed with teriyaki sauce served over brown rice with steamed broccoli.");
    r.setRecipeInstructions("Glaze salmon with teriyaki sauce; grill until cooked; serve over brown rice with broccoli.");
    r.setMacroCategory("High Protein");
    r.setCalories(680);
    r.setProtein(44);
    r.setFats(20);
    r.setCarbs(70);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 190. Moroccan Chicken Tagine
{
    Recipe r = new Recipe();
    r.setRecipeName("Moroccan Chicken Tagine");
    r.setRecipeDescription("A spiced stew of chicken, apricots, and almonds simmered with Moroccan spices.");
    r.setRecipeInstructions("Brown chicken pieces; add apricots, almonds, and a blend of Moroccan spices; simmer until tender; serve with couscous.");
    r.setMacroCategory("High Protein");
    r.setCalories(720);
    r.setProtein(46);
    r.setFats(24);
    r.setCarbs(60);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 191. Roasted Beef with Root Vegetables
{
    Recipe r = new Recipe();
    r.setRecipeName("Roasted Beef with Root Vegetables");
    r.setRecipeDescription("Slow-roasted beef served with a medley of carrots, parsnips, and turnips.");
    r.setRecipeInstructions("Season beef roast; roast with chopped root vegetables until tender; serve with pan juices.");
    r.setMacroCategory("High Protein");
    r.setCalories(750);
    r.setProtein(50);
    r.setFats(28);
    r.setCarbs(55);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 192. Grilled Vegetable and Hummus Flatbread
{
    Recipe r = new Recipe();
    r.setRecipeName("Grilled Vegetable and Hummus Flatbread");
    r.setRecipeDescription("Flatbread topped with grilled mixed vegetables and a generous spread of hummus.");
    r.setRecipeInstructions("Grill assorted vegetables; spread hummus on flatbread; top with vegetables and drizzle with olive oil; serve warm.");
    r.setMacroCategory("Balanced");
    r.setCalories(660);
    r.setProtein(18);
    r.setFats(22);
    r.setCarbs(85);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 193. Shrimp and Broccoli Stir-Fry
{
    Recipe r = new Recipe();
    r.setRecipeName("Shrimp and Broccoli Stir-Fry");
    r.setRecipeDescription("Quick stir-fry of shrimp and broccoli in a savory garlic sauce.");
    r.setRecipeInstructions("Sauté shrimp and broccoli with garlic and a splash of soy sauce; serve immediately.");
    r.setMacroCategory("High Protein");
    r.setCalories(600);
    r.setProtein(40);
    r.setFats(18);
    r.setCarbs(50);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
    recipes.add(r);
}

// 194. Chicken Tikka Masala
{
    Recipe r = new Recipe();
    r.setRecipeName("Chicken Tikka Masala");
    r.setRecipeDescription("Tender chicken pieces in a creamy, spiced tomato sauce.");
    r.setRecipeInstructions("Marinate chicken in yogurt and spices; grill and then simmer in a spiced tomato sauce; serve with basmati rice.");
    r.setMacroCategory("High Protein");
    r.setCalories(700);
    r.setProtein(44);
    r.setFats(22);
    r.setCarbs(65);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("dairy_free"));
    recipes.add(r);
}

// 195. Crispy Fish and Sweet Potato Fries
{
    Recipe r = new Recipe();
    r.setRecipeName("Crispy Fish and Sweet Potato Fries");
    r.setRecipeDescription("Lightly battered fish served with baked sweet potato fries.");
    r.setRecipeInstructions("Coat fish in a light batter; bake with sweet potato fries until crispy; serve with tartar sauce.");
    r.setMacroCategory("High Protein");
    r.setCalories(710);
    r.setProtein(42);
    r.setFats(20);
    r.setCarbs(70);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 196. Zesty Lime Chicken with Avocado Salsa
{
    Recipe r = new Recipe();
    r.setRecipeName("Zesty Lime Chicken with Avocado Salsa");
    r.setRecipeDescription("Grilled chicken breast served with a refreshing avocado and lime salsa.");
    r.setRecipeInstructions("Marinate chicken with lime and spices; grill until cooked; top with diced avocado, tomato, and lime juice.");
    r.setMacroCategory("High Protein");
    r.setCalories(630);
    r.setProtein(43);
    r.setFats(17);
    r.setCarbs(45);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
    recipes.add(r);
}

// 197. Spinach and Mushroom Lasagna
{
    Recipe r = new Recipe();
    r.setRecipeName("Spinach and Mushroom Lasagna");
    r.setRecipeDescription("Layers of lasagna noodles with a rich mixture of spinach, mushrooms, and low-fat cheese.");
    r.setRecipeInstructions("Layer cooked noodles with sautéed spinach and mushrooms; add tomato sauce and cheese; bake until bubbly.");
    r.setMacroCategory("Balanced");
    r.setCalories(750);
    r.setProtein(35);
    r.setFats(28);
    r.setCarbs(90);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("vegetarian"));
    recipes.add(r);
}

// 198. Roasted Duck with Orange Glaze
{
    Recipe r = new Recipe();
    r.setRecipeName("Roasted Duck with Orange Glaze");
    r.setRecipeDescription("Crispy roasted duck served with a sweet and tangy orange glaze.");
    r.setRecipeInstructions("Roast duck until crispy; brush with an orange and honey glaze during the last minutes of cooking; serve with steamed greens.");
    r.setMacroCategory("High Protein");
    r.setCalories(780);
    r.setProtein(44);
    r.setFats(30);
    r.setCarbs(40);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 199. Beef Bulgogi Bowl
{
    Recipe r = new Recipe();
    r.setRecipeName("Beef Bulgogi Bowl");
    r.setRecipeDescription("Korean-style marinated beef served over rice with pickled vegetables.");
    r.setRecipeInstructions("Marinate thinly sliced beef in a sweet-savory sauce; stir-fry quickly; serve over rice with kimchi and scallions.");
    r.setMacroCategory("High Protein");
    r.setCalories(730);
    r.setProtein(45);
    r.setFats(22);
    r.setCarbs(65);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("dairy_free"));
    recipes.add(r);
}

// 200. Vegan Lentil Shepherd's Pie
{
    Recipe r = new Recipe();
    r.setRecipeName("Vegan Lentil Shepherd's Pie");
    r.setRecipeDescription("A hearty pie with spiced lentils topped with mashed potatoes and baked until golden.");
    r.setRecipeInstructions("Cook lentils with vegetables and spices; top with mashed potatoes; bake until the top is crispy and golden.");
    r.setMacroCategory("Balanced");
    r.setCalories(700);
    r.setProtein(26);
    r.setFats(18);
    r.setCarbs(100);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 201. Grilled Swordfish with Tomato Relish
{
    Recipe r = new Recipe();
    r.setRecipeName("Grilled Swordfish with Tomato Relish");
    r.setRecipeDescription("Thick swordfish steaks grilled and topped with a fresh tomato and basil relish.");
    r.setRecipeInstructions("Grill swordfish steaks; prepare a relish with diced tomatoes, basil, and olive oil; top the fish before serving.");
    r.setMacroCategory("High Protein");
    r.setCalories(640);
    r.setProtein(43);
    r.setFats(18);
    r.setCarbs(35);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
    recipes.add(r);
}

// 202. Chicken and Avocado Salad
{
    Recipe r = new Recipe();
    r.setRecipeName("Chicken and Avocado Salad");
    r.setRecipeDescription("Grilled chicken mixed with avocado, mixed greens, and a light citrus dressing.");
    r.setRecipeInstructions("Slice grilled chicken and avocado; toss with mixed greens and a citrus vinaigrette; serve chilled.");
    r.setMacroCategory("High Protein");
    r.setCalories(600);
    r.setProtein(42);
    r.setFats(22);
    r.setCarbs(40);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 203. Herbed Pork Chops with Apple Slaw
{
    Recipe r = new Recipe();
    r.setRecipeName("Herbed Pork Chops with Apple Slaw");
    r.setRecipeDescription("Juicy pork chops seasoned with herbs, served with a crisp apple and cabbage slaw.");
    r.setRecipeInstructions("Season pork chops with rosemary and thyme; grill until cooked; serve with a fresh slaw made from apples and cabbage.");
    r.setMacroCategory("High Protein");
    r.setCalories(670);
    r.setProtein(44);
    r.setFats(20);
    r.setCarbs(50);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 204. Grilled Mahi Mahi Tacos
{
    Recipe r = new Recipe();
    r.setRecipeName("Grilled Mahi Mahi Tacos");
    r.setRecipeDescription("Mahi mahi fillets grilled and served in soft tortillas with cabbage slaw and a squeeze of lime.");
    r.setRecipeInstructions("Grill mahi mahi with a touch of spice; flake and serve in tortillas with shredded cabbage and lime crema.");
    r.setMacroCategory("High Protein");
    r.setCalories(630);
    r.setProtein(42);
    r.setFats(18);
    r.setCarbs(55);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
    recipes.add(r);
}

// 205. Roasted Cauliflower Steak with Tahini Sauce
{
    Recipe r = new Recipe();
    r.setRecipeName("Roasted Cauliflower Steak with Tahini Sauce");
    r.setRecipeDescription("Thick slices of cauliflower roasted and drizzled with a creamy tahini and lemon sauce.");
    r.setRecipeInstructions("Cut cauliflower into thick steaks; roast with olive oil and spices; drizzle with tahini sauce before serving.");
    r.setMacroCategory("Low Carb");
    r.setCalories(480);
    r.setProtein(16);
    r.setFats(22);
    r.setCarbs(40);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 206. Spicy Turkey Meatballs with Zoodles
{
    Recipe r = new Recipe();
    r.setRecipeName("Spicy Turkey Meatballs with Zoodles");
    r.setRecipeDescription("Lean turkey meatballs served over zucchini noodles in a spicy marinara sauce.");
    r.setRecipeInstructions("Mix ground turkey with spices; form meatballs and bake; serve over spiralized zucchini with marinara sauce.");
    r.setMacroCategory("High Protein");
    r.setCalories(600);
    r.setProtein(43);
    r.setFats(16);
    r.setCarbs(35);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
    recipes.add(r);
}

// 207. Baked Cod with Tomato Basil Sauce
{
    Recipe r = new Recipe();
    r.setRecipeName("Baked Cod with Tomato Basil Sauce");
    r.setRecipeDescription("Mild cod fillets baked in a fragrant tomato basil sauce.");
    r.setRecipeInstructions("Place cod fillets in a baking dish; cover with a sauce of tomatoes, basil, and garlic; bake until flaky.");
    r.setMacroCategory("High Protein");
    r.setCalories(560);
    r.setProtein(42);
    r.setFats(14);
    r.setCarbs(38);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
    recipes.add(r);
}

// 208. Vegetarian Ratatouille
{
    Recipe r = new Recipe();
    r.setRecipeName("Vegetarian Ratatouille");
    r.setRecipeDescription("A classic French stew of eggplant, zucchini, bell peppers, and tomatoes seasoned with herbs.");
    r.setRecipeInstructions("Sauté mixed vegetables with garlic and herbs; simmer in tomato sauce until tender; serve hot.");
    r.setMacroCategory("Low Carb");
    r.setCalories(500);
    r.setProtein(14);
    r.setFats(16);
    r.setCarbs(60);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 209. Pineapple Chicken Stir-Fry
{
    Recipe r = new Recipe();
    r.setRecipeName("Pineapple Chicken Stir-Fry");
    r.setRecipeDescription("Stir-fried chicken with pineapple chunks, bell peppers, and a tangy sauce.");
    r.setRecipeInstructions("Stir-fry chicken with bell peppers; add pineapple and a sweet-savory sauce; serve over jasmine rice.");
    r.setMacroCategory("High Protein");
    r.setCalories(680);
    r.setProtein(44);
    r.setFats(18);
    r.setCarbs(65);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 210. Garlic Butter Shrimp Pasta
{
    Recipe r = new Recipe();
    r.setRecipeName("Garlic Butter Shrimp Pasta");
    r.setRecipeDescription("Succulent shrimp tossed with pasta in a rich garlic butter sauce and a sprinkle of parsley.");
    r.setRecipeInstructions("Sauté shrimp in garlic and butter; toss with cooked pasta and fresh parsley; serve immediately.");
    r.setMacroCategory("High Protein");
    r.setCalories(720);
    r.setProtein(38);
    r.setFats(24);
    r.setCarbs(85);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("dairy_free"));
    recipes.add(r);
}

// 211. Vegan Black Bean and Sweet Potato Chili
{
    Recipe r = new Recipe();
    r.setRecipeName("Vegan Black Bean and Sweet Potato Chili");
    r.setRecipeDescription("A hearty chili with black beans, sweet potatoes, and tomatoes simmered with spices.");
    r.setRecipeInstructions("Combine black beans, diced sweet potatoes, tomatoes, and chili spices; simmer until flavors meld; serve with fresh cilantro.");
    r.setMacroCategory("Balanced");
    r.setCalories(650);
    r.setProtein(24);
    r.setFats(16);
    r.setCarbs(90);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 212. Grilled Chicken Fajita Bowl
{
    Recipe r = new Recipe();
    r.setRecipeName("Grilled Chicken Fajita Bowl");
    r.setRecipeDescription("Sizzling grilled chicken with peppers and onions served over rice with avocado.");
    r.setRecipeInstructions("Grill marinated chicken with sliced bell peppers and onions; serve over rice and top with avocado and salsa.");
    r.setMacroCategory("High Protein");
    r.setCalories(690);
    r.setProtein(44);
    r.setFats(20);
    r.setCarbs(60);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 213. Sesame Crusted Ahi Tuna
{
    Recipe r = new Recipe();
    r.setRecipeName("Sesame Crusted Ahi Tuna");
    r.setRecipeDescription("Ahi tuna lightly crusted with sesame seeds and seared to perfection.");
    r.setRecipeInstructions("Coat tuna steak in sesame seeds; sear on high heat for a short time; slice and serve with a soy dipping sauce.");
    r.setMacroCategory("High Protein");
    r.setCalories(540);
    r.setProtein(41);
    r.setFats(16);
    r.setCarbs(30);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
    recipes.add(r);
}

// 214. Herb Roasted Turkey Breast
{
    Recipe r = new Recipe();
    r.setRecipeName("Herb Roasted Turkey Breast");
    r.setRecipeDescription("Turkey breast roasted with a blend of herbs and spices, served with a light gravy.");
    r.setRecipeInstructions("Season turkey breast with rosemary, thyme, and garlic; roast until juicy and tender; serve with a drizzle of gravy.");
    r.setMacroCategory("High Protein");
    r.setCalories(670);
    r.setProtein(44);
    r.setFats(18);
    r.setCarbs(40);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 215. Vegan Mushroom Risotto
{
    Recipe r = new Recipe();
    r.setRecipeName("Vegan Mushroom Risotto");
    r.setRecipeDescription("Creamy risotto made with Arborio rice, wild mushrooms, and vegetable broth.");
    r.setRecipeInstructions("Sauté mushrooms; gradually add warm vegetable broth to Arborio rice while stirring until creamy; season to taste.");
    r.setMacroCategory("Balanced");
    r.setCalories(680);
    r.setProtein(18);
    r.setFats(22);
    r.setCarbs(95);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 216. Grilled Eggplant and Chickpea Salad
{
    Recipe r = new Recipe();
    r.setRecipeName("Grilled Eggplant and Chickpea Salad");
    r.setRecipeDescription("Grilled eggplant tossed with chickpeas, cherry tomatoes, and a lemon-tahini dressing.");
    r.setRecipeInstructions("Grill eggplant slices; combine with chickpeas and halved cherry tomatoes; toss with a lemon-tahini dressing; serve at room temperature.");
    r.setMacroCategory("Balanced");
    r.setCalories(600);
    r.setProtein(20);
    r.setFats(18);
    r.setCarbs(75);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 217. Lemon Pepper Tilapia with Asparagus
{
    Recipe r = new Recipe();
    r.setRecipeName("Lemon Pepper Tilapia with Asparagus");
    r.setRecipeDescription("Light tilapia fillets seasoned with lemon pepper, served with roasted asparagus.");
    r.setRecipeInstructions("Season tilapia with lemon pepper; roast with asparagus spears until tender; serve with a wedge of lemon.");
    r.setMacroCategory("High Protein");
    r.setCalories(520);
    r.setProtein(41);
    r.setFats(12);
    r.setCarbs(38);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free", "dairy_free"));
    recipes.add(r);
}

// 218. Roasted Lamb with Rosemary Potatoes
{
    Recipe r = new Recipe();
    r.setRecipeName("Roasted Lamb with Rosemary Potatoes");
    r.setRecipeDescription("Tender lamb roast served with rosemary-infused roasted potatoes.");
    r.setRecipeInstructions("Roast lamb with garlic and rosemary; add potatoes halfway through cooking; serve with a drizzle of pan juices.");
    r.setMacroCategory("High Protein");
    r.setCalories(750);
    r.setProtein(46);
    r.setFats(28);
    r.setCarbs(55);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 219. Spicy Beef Tacos
{
    Recipe r = new Recipe();
    r.setRecipeName("Spicy Beef Tacos");
    r.setRecipeDescription("Seasoned ground beef served in soft tortillas with salsa, lettuce, and avocado.");
    r.setRecipeInstructions("Cook ground beef with taco spices; assemble in tortillas with shredded lettuce, salsa, and sliced avocado; serve with lime.");
    r.setMacroCategory("High Protein");
    r.setCalories(680);
    r.setProtein(45);
    r.setFats(22);
    r.setCarbs(65);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("dairy_free"));
    recipes.add(r);
}

// 220. Grilled Vegetable Quinoa Salad
{
    Recipe r = new Recipe();
    r.setRecipeName("Grilled Vegetable Quinoa Salad");
    r.setRecipeDescription("A vibrant salad combining grilled seasonal vegetables with protein-rich quinoa.");
    r.setRecipeInstructions("Grill a mix of vegetables; toss with cooked quinoa, olive oil, and lemon juice; serve at room temperature.");
    r.setMacroCategory("Balanced");
    r.setCalories(640);
    r.setProtein(22);
    r.setFats(18);
    r.setCarbs(85);
    r.setMealType("Meal");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// -------------------------------
// Additional Generated Recipes - Snacks (Recipes 221-270)
// -------------------------------

// 221. Crispy Baked Zucchini Chips
{
    Recipe r = new Recipe();
    r.setRecipeName("Crispy Baked Zucchini Chips");
    r.setRecipeDescription("Thinly sliced zucchini baked until crisp with a sprinkle of sea salt.");
    r.setRecipeInstructions("Slice zucchini thinly; toss with a little olive oil and salt; bake at 200°C until crispy; serve as a low-cal snack.");
    r.setMacroCategory("Low Carb");
    r.setCalories(140);
    r.setProtein(4);
    r.setFats(7);
    r.setCarbs(15);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 222. Mango Lime Fruit Salad
{
    Recipe r = new Recipe();
    r.setRecipeName("Mango Lime Fruit Salad");
    r.setRecipeDescription("A refreshing mix of diced mango, pineapple, and kiwi tossed with lime juice.");
    r.setRecipeInstructions("Dice seasonal fruits; toss with fresh lime juice and a sprinkle of mint; serve chilled.");
    r.setMacroCategory("Balanced");
    r.setCalories(210);
    r.setProtein(3);
    r.setFats(1);
    r.setCarbs(55);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 223. Protein-Packed Deviled Eggs
{
    Recipe r = new Recipe();
    r.setRecipeName("Protein-Packed Deviled Eggs");
    r.setRecipeDescription("Hard-boiled eggs filled with a creamy, high-protein yolk mixture spiced with paprika.");
    r.setRecipeInstructions("Halve boiled eggs; mix yolks with Greek yogurt, mustard, and paprika; fill egg whites; serve chilled.");
    r.setMacroCategory("High Protein");
    r.setCalories(180);
    r.setProtein(13);
    r.setFats(10);
    r.setCarbs(2);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 224. Roasted Spicy Almonds
{
    Recipe r = new Recipe();
    r.setRecipeName("Roasted Spicy Almonds");
    r.setRecipeDescription("Almonds roasted with a touch of cayenne and smoked paprika for a spicy crunch.");
    r.setRecipeInstructions("Toss almonds with olive oil and spices; roast until fragrant; allow to cool before serving.");
    r.setMacroCategory("High Protein");
    r.setCalories(210);
    r.setProtein(8);
    r.setFats(14);
    r.setCarbs(10);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 225. Banana Oat Breakfast Cookies
{
    Recipe r = new Recipe();
    r.setRecipeName("Banana Oat Breakfast Cookies");
    r.setRecipeDescription("Soft cookies made with mashed banana, oats, and a dash of cinnamon for a quick snack.");
    r.setRecipeInstructions("Mix mashed banana, oats, and cinnamon; form cookies and bake until set; serve warm or store for later.");
    r.setMacroCategory("High Protein");
    r.setCalories(240);
    r.setProtein(6);
    r.setFats(8);
    r.setCarbs(40);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free", "vegetarian"));
    recipes.add(r);
}

// 226. Greek Yogurt with Honey and Walnuts
{
    Recipe r = new Recipe();
    r.setRecipeName("Greek Yogurt with Honey and Walnuts");
    r.setRecipeDescription("Creamy Greek yogurt drizzled with honey and sprinkled with crunchy walnuts.");
    r.setRecipeInstructions("Spoon Greek yogurt into a bowl; drizzle with honey and top with chopped walnuts; serve chilled.");
    r.setMacroCategory("High Protein");
    r.setCalories(270);
    r.setProtein(20);
    r.setFats(12);
    r.setCarbs(25);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 227. Carrot Ginger Smoothie
{
    Recipe r = new Recipe();
    r.setRecipeName("Carrot Ginger Smoothie");
    r.setRecipeDescription("A vibrant smoothie blending fresh carrots with a hint of ginger and orange.");
    r.setRecipeInstructions("Blend chopped carrots with orange juice, a small piece of ginger, and ice until smooth; serve immediately.");
    r.setMacroCategory("Low Carb");
    r.setCalories(200);
    r.setProtein(4);
    r.setFats(2);
    r.setCarbs(45);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 228. Cucumber Mint Refresher
{
    Recipe r = new Recipe();
    r.setRecipeName("Cucumber Mint Refresher");
    r.setRecipeDescription("A light, hydrating snack of sliced cucumber sprinkled with fresh mint and a splash of lime.");
    r.setRecipeInstructions("Slice cucumber; drizzle with lime juice and top with chopped mint; serve chilled.");
    r.setMacroCategory("Low Carb");
    r.setCalories(110);
    r.setProtein(2);
    r.setFats(1);
    r.setCarbs(18);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 229. Crispy Baked Kale Fries
{
    Recipe r = new Recipe();
    r.setRecipeName("Crispy Baked Kale Fries");
    r.setRecipeDescription("Kale leaves tossed in olive oil and baked until crisp, lightly salted.");
    r.setRecipeInstructions("Toss kale with olive oil and salt; bake at 200°C until crispy; serve as a nutritious snack.");
    r.setMacroCategory("Low Carb");
    r.setCalories(150);
    r.setProtein(4);
    r.setFats(8);
    r.setCarbs(10);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 230. Mini Avocado Toasts
{
    Recipe r = new Recipe();
    r.setRecipeName("Mini Avocado Toasts");
    r.setRecipeDescription("Small slices of toasted whole-grain bread topped with mashed avocado and a dash of chili flakes.");
    r.setRecipeInstructions("Toast mini slices of whole-grain bread; spread with mashed avocado seasoned with salt and chili flakes; serve immediately.");
    r.setMacroCategory("Balanced");
    r.setCalories(220);
    r.setProtein(5);
    r.setFats(12);
    r.setCarbs(25);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegetarian", "gluten_free"));
    recipes.add(r);
}

// 231. Berry Almond Parfait
{
    Recipe r = new Recipe();
    r.setRecipeName("Berry Almond Parfait");
    r.setRecipeDescription("Layers of mixed berries, almond slivers, and low-fat yogurt for a refreshing treat.");
    r.setRecipeInstructions("Layer Greek yogurt with mixed berries and almonds in a glass; drizzle with a little honey; serve chilled.");
    r.setMacroCategory("High Protein");
    r.setCalories(260);
    r.setProtein(18);
    r.setFats(10);
    r.setCarbs(30);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 232. Chocolate Dipped Banana Bites
{
    Recipe r = new Recipe();
    r.setRecipeName("Chocolate Dipped Banana Bites");
    r.setRecipeDescription("Sliced banana pieces dipped in dark chocolate and chilled until set.");
    r.setRecipeInstructions("Slice bananas; dip each piece in melted dark chocolate; place on parchment paper and chill until firm; serve as a sweet snack.");
    r.setMacroCategory("Balanced");
    r.setCalories(230);
    r.setProtein(4);
    r.setFats(10);
    r.setCarbs(35);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 233. Roasted Cashew Nuts
{
    Recipe r = new Recipe();
    r.setRecipeName("Roasted Cashew Nuts");
    r.setRecipeDescription("Cashew nuts roasted with a pinch of salt for a crunchy, protein-rich snack.");
    r.setRecipeInstructions("Spread cashews on a baking sheet; roast at 180°C until lightly browned; sprinkle with salt; serve once cooled.");
    r.setMacroCategory("High Protein");
    r.setCalories(220);
    r.setProtein(7);
    r.setFats(15);
    r.setCarbs(12);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 234. Cottage Cheese and Peach Bowl
{
    Recipe r = new Recipe();
    r.setRecipeName("Cottage Cheese and Peach Bowl");
    r.setRecipeDescription("Creamy cottage cheese topped with fresh peach slices and a drizzle of honey.");
    r.setRecipeInstructions("Spoon cottage cheese into a bowl; top with sliced peaches and a drizzle of honey; serve chilled.");
    r.setMacroCategory("High Protein");
    r.setCalories(240);
    r.setProtein(20);
    r.setFats(8);
    r.setCarbs(28);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 235. Pumpkin Seed Energy Balls
{
    Recipe r = new Recipe();
    r.setRecipeName("Pumpkin Seed Energy Balls");
    r.setRecipeDescription("No-bake energy balls made with pumpkin seeds, oats, and a touch of honey.");
    r.setRecipeInstructions("Combine pumpkin seeds, oats, and honey; form into small balls; chill until firm; serve as a quick energy snack.");
    r.setMacroCategory("High Protein");
    r.setCalories(210);
    r.setProtein(8);
    r.setFats(10);
    r.setCarbs(26);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 236. Strawberry Protein Shake
{
    Recipe r = new Recipe();
    r.setRecipeName("Strawberry Protein Shake");
    r.setRecipeDescription("A refreshing shake blending fresh strawberries with protein powder and almond milk.");
    r.setRecipeInstructions("Blend strawberries, protein powder, and almond milk until smooth; serve chilled.");
    r.setMacroCategory("High Protein");
    r.setCalories(240);
    r.setProtein(20);
    r.setFats(6);
    r.setCarbs(32);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 237. Tangy Lemon Pistachio Mix
{
    Recipe r = new Recipe();
    r.setRecipeName("Tangy Lemon Pistachio Mix");
    r.setRecipeDescription("Pistachios tossed with lemon zest and a pinch of sea salt for a zesty snack.");
    r.setRecipeInstructions("Toss roasted pistachios with lemon zest and sea salt; serve as a tangy, crunchy snack.");
    r.setMacroCategory("High Protein");
    r.setCalories(230);
    r.setProtein(8);
    r.setFats(14);
    r.setCarbs(16);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 238. Vegan Edamame Snack
{
    Recipe r = new Recipe();
    r.setRecipeName("Vegan Edamame Snack");
    r.setRecipeDescription("Steamed edamame pods sprinkled with a little sea salt.");
    r.setRecipeInstructions("Steam edamame until tender; sprinkle with salt; serve warm.");
    r.setMacroCategory("High Protein");
    r.setCalories(200);
    r.setProtein(17);
    r.setFats(8);
    r.setCarbs(15);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free"));
    recipes.add(r);
}

// 239. Apple Cinnamon Rice Cake
{
    Recipe r = new Recipe();
    r.setRecipeName("Apple Cinnamon Rice Cake");
    r.setRecipeDescription("A crunchy rice cake topped with almond butter, apple slices, and a sprinkle of cinnamon.");
    r.setRecipeInstructions("Spread almond butter on a rice cake; top with thin apple slices and a dash of cinnamon; serve immediately.");
    r.setMacroCategory("Balanced");
    r.setCalories(210);
    r.setProtein(7);
    r.setFats(10);
    r.setCarbs(25);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("dairy_free"));
    recipes.add(r);
}

// 240. Roasted Beet Hummus with Veggies
{
    Recipe r = new Recipe();
    r.setRecipeName("Roasted Beet Hummus with Veggies");
    r.setRecipeDescription("A vibrant hummus blended with roasted beets, served with fresh veggie sticks.");
    r.setRecipeInstructions("Roast beets; blend with chickpeas, tahini, and lemon juice; serve with sliced bell peppers and carrots.");
    r.setMacroCategory("Balanced");
    r.setCalories(230);
    r.setProtein(8);
    r.setFats(10);
    r.setCarbs(30);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 241. Spicy Sriracha Popcorn
{
    Recipe r = new Recipe();
    r.setRecipeName("Spicy Sriracha Popcorn");
    r.setRecipeDescription("Air-popped popcorn tossed with a spicy Sriracha seasoning.");
    r.setRecipeInstructions("Pop popcorn; toss with a light coating of Sriracha and a dash of salt; serve immediately.");
    r.setMacroCategory("Low Carb");
    r.setCalories(180);
    r.setProtein(3);
    r.setFats(5);
    r.setCarbs(30);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 242. Mini Chia Pudding Cups
{
    Recipe r = new Recipe();
    r.setRecipeName("Mini Chia Pudding Cups");
    r.setRecipeDescription("Small cups of chia pudding made with almond milk and a touch of vanilla.");
    r.setRecipeInstructions("Mix chia seeds with almond milk and vanilla; refrigerate overnight in small cups; top with berries before serving.");
    r.setMacroCategory("Balanced");
    r.setCalories(200);
    r.setProtein(6);
    r.setFats(10);
    r.setCarbs(28);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 243. Ginger Peach Smoothie
{
    Recipe r = new Recipe();
    r.setRecipeName("Ginger Peach Smoothie");
    r.setRecipeDescription("A refreshing smoothie blending fresh peaches with a hint of ginger.");
    r.setRecipeInstructions("Blend peeled peaches, a small piece of ginger, and ice with a splash of almond milk until smooth; serve immediately.");
    r.setMacroCategory("Balanced");
    r.setCalories(220);
    r.setProtein(6);
    r.setFats(4);
    r.setCarbs(40);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 244. Avocado and Lime Guacamole Dip
{
    Recipe r = new Recipe();
    r.setRecipeName("Avocado and Lime Guacamole Dip");
    r.setRecipeDescription("Creamy guacamole made with ripe avocado, lime juice, and diced tomato.");
    r.setRecipeInstructions("Mash avocado; mix with lime juice, diced tomato, and salt; serve with baked tortilla chips.");
    r.setMacroCategory("Balanced");
    r.setCalories(210);
    r.setProtein(4);
    r.setFats(14);
    r.setCarbs(20);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 245. Mixed Berry Protein Bars
{
    Recipe r = new Recipe();
    r.setRecipeName("Mixed Berry Protein Bars");
    r.setRecipeDescription("Homemade protein bars loaded with oats, dried berries, and a touch of honey.");
    r.setRecipeInstructions("Mix oats, dried berries, and protein powder with honey; press into a pan; bake until set; cool and cut into bars.");
    r.setMacroCategory("High Protein");
    r.setCalories(260);
    r.setProtein(18);
    r.setFats(9);
    r.setCarbs(30);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 246. Crispy Lentil Crackers
{
    Recipe r = new Recipe();
    r.setRecipeName("Crispy Lentil Crackers");
    r.setRecipeDescription("Homemade crackers made from red lentil flour and spices, baked until crunchy.");
    r.setRecipeInstructions("Mix red lentil flour with water and spices; roll thinly and cut into crackers; bake until crispy; serve as a savory snack.");
    r.setMacroCategory("Low Carb");
    r.setCalories(210);
    r.setProtein(8);
    r.setFats(6);
    r.setCarbs(28);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 247. Tropical Fruit Medley
{
    Recipe r = new Recipe();
    r.setRecipeName("Tropical Fruit Medley");
    r.setRecipeDescription("A colorful mix of pineapple, mango, and kiwi chunks for a refreshing snack.");
    r.setRecipeInstructions("Dice tropical fruits; mix together and chill; serve as a light, refreshing snack.");
    r.setMacroCategory("Balanced");
    r.setCalories(190);
    r.setProtein(3);
    r.setFats(1);
    r.setCarbs(45);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 248. Zesty Orange Protein Smoothie
{
    Recipe r = new Recipe();
    r.setRecipeName("Zesty Orange Protein Smoothie");
    r.setRecipeDescription("A vibrant smoothie blending fresh orange juice with protein powder and a hint of ginger.");
    r.setRecipeInstructions("Blend fresh orange juice, protein powder, a small piece of ginger, and ice until smooth; serve immediately.");
    r.setMacroCategory("High Protein");
    r.setCalories(220);
    r.setProtein(20);
    r.setFats(4);
    r.setCarbs(30);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 249. Herbed Ricotta on Toast
{
    Recipe r = new Recipe();
    r.setRecipeName("Herbed Ricotta on Toast");
    r.setRecipeDescription("Whole-grain toast topped with creamy ricotta mixed with fresh herbs and a drizzle of honey.");
    r.setRecipeInstructions("Spread ricotta mixed with chopped basil and thyme on toasted bread; drizzle with honey; serve immediately.");
    r.setMacroCategory("High Protein");
    r.setCalories(240);
    r.setProtein(14);
    r.setFats(10);
    r.setCarbs(28);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 250. Frozen Yogurt and Berry Bites
{
    Recipe r = new Recipe();
    r.setRecipeName("Frozen Yogurt and Berry Bites");
    r.setRecipeDescription("Small bites of Greek yogurt mixed with berries and frozen into refreshing snacks.");
    r.setRecipeInstructions("Mix Greek yogurt with chopped berries; spoon into mini molds; freeze until solid; serve as a cool treat.");
    r.setMacroCategory("High Protein");
    r.setCalories(230);
    r.setProtein(18);
    r.setFats(7);
    r.setCarbs(28);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 251. Pineapple Mint Smoothie
{
    Recipe r = new Recipe();
    r.setRecipeName("Pineapple Mint Smoothie");
    r.setRecipeDescription("A refreshing smoothie blending pineapple with fresh mint and a splash of coconut water.");
    r.setRecipeInstructions("Blend pineapple chunks with mint leaves and coconut water until smooth; serve chilled.");
    r.setMacroCategory("Balanced");
    r.setCalories(220);
    r.setProtein(4);
    r.setFats(2);
    r.setCarbs(50);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 252. Spiced Pear Slices
{
    Recipe r = new Recipe();
    r.setRecipeName("Spiced Pear Slices");
    r.setRecipeDescription("Fresh pear slices lightly sprinkled with cinnamon and nutmeg.");
    r.setRecipeInstructions("Slice a ripe pear; dust with a mix of cinnamon and nutmeg; serve as a simple, aromatic snack.");
    r.setMacroCategory("Low Carb");
    r.setCalories(150);
    r.setProtein(2);
    r.setFats(1);
    r.setCarbs(35);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 253. Chocolate Almond Energy Balls
{
    Recipe r = new Recipe();
    r.setRecipeName("Chocolate Almond Energy Balls");
    r.setRecipeDescription("No-bake energy balls made with almond butter, oats, and a touch of cocoa powder.");
    r.setRecipeInstructions("Mix almond butter, oats, cocoa powder, and a little honey; form into balls; chill until firm; serve as a quick energy boost.");
    r.setMacroCategory("High Protein");
    r.setCalories(250);
    r.setProtein(15);
    r.setFats(11);
    r.setCarbs(30);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 254. Vegan Coconut Macaroons
{
    Recipe r = new Recipe();
    r.setRecipeName("Vegan Coconut Macaroons");
    r.setRecipeDescription("Chewy macaroons made from shredded coconut and a touch of maple syrup.");
    r.setRecipeInstructions("Mix shredded coconut with maple syrup and a pinch of salt; form into small mounds; bake until golden; cool and serve.");
    r.setMacroCategory("Low Carb");
    r.setCalories(210);
    r.setProtein(3);
    r.setFats(14);
    r.setCarbs(18);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 255. Roasted Brussels Sprouts Snack
{
    Recipe r = new Recipe();
    r.setRecipeName("Roasted Brussels Sprouts Snack");
    r.setRecipeDescription("Crispy roasted Brussels sprouts drizzled with a balsamic reduction.");
    r.setRecipeInstructions("Halve Brussels sprouts; toss with olive oil and roast until crisp; drizzle with balsamic reduction; serve warm.");
    r.setMacroCategory("Low Carb");
    r.setCalories(200);
    r.setProtein(6);
    r.setFats(10);
    r.setCarbs(22);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 256. Blueberry Banana Oat Bars
{
    Recipe r = new Recipe();
    r.setRecipeName("Blueberry Banana Oat Bars");
    r.setRecipeDescription("Homemade oat bars loaded with blueberries and mashed banana for natural sweetness.");
    r.setRecipeInstructions("Mix oats with mashed banana and blueberries; press into a pan; bake until set; cool and cut into bars.");
    r.setMacroCategory("High Protein");
    r.setCalories(250);
    r.setProtein(10);
    r.setFats(9);
    r.setCarbs(35);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 257. Crispy Carrot Chips
{
    Recipe r = new Recipe();
    r.setRecipeName("Crispy Carrot Chips");
    r.setRecipeDescription("Thinly sliced carrots baked until crisp and lightly salted.");
    r.setRecipeInstructions("Slice carrots very thinly; toss with olive oil and salt; bake at 180°C until crispy; serve as a crunchy snack.");
    r.setMacroCategory("Low Carb");
    r.setCalories(160);
    r.setProtein(3);
    r.setFats(4);
    r.setCarbs(28);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 258. Grapefruit and Honey Salad
{
    Recipe r = new Recipe();
    r.setRecipeName("Grapefruit and Honey Salad");
    r.setRecipeDescription("A tangy salad of segmented grapefruit drizzled with honey and a sprinkle of mint.");
    r.setRecipeInstructions("Segment grapefruit; drizzle with honey and top with chopped mint; serve chilled.");
    r.setMacroCategory("Low Carb");
    r.setCalories(170);
    r.setProtein(3);
    r.setFats(1);
    r.setCarbs(38);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 259. Protein-Packed Mixed Nuts
{
    Recipe r = new Recipe();
    r.setRecipeName("Protein-Packed Mixed Nuts");
    r.setRecipeDescription("A mix of almonds, walnuts, and pistachios lightly salted for a satisfying snack.");
    r.setRecipeInstructions("Combine a variety of unsalted nuts; lightly roast if desired; serve in small portions.");
    r.setMacroCategory("High Protein");
    r.setCalories(230);
    r.setProtein(9);
    r.setFats(15);
    r.setCarbs(18);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 260. Roasted Pepper Guacamole
{
    Recipe r = new Recipe();
    r.setRecipeName("Roasted Pepper Guacamole");
    r.setRecipeDescription("Creamy guacamole blended with roasted red peppers for extra sweetness and depth.");
    r.setRecipeInstructions("Roast red peppers; blend with avocado, lime, and salt; serve with baked tortilla chips.");
    r.setMacroCategory("Balanced");
    r.setCalories(210);
    r.setProtein(4);
    r.setFats(14);
    r.setCarbs(22);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 261. Lemon Thyme Popcorn
{
    Recipe r = new Recipe();
    r.setRecipeName("Lemon Thyme Popcorn");
    r.setRecipeDescription("Air-popped popcorn tossed with lemon zest and dried thyme for a savory snack.");
    r.setRecipeInstructions("Pop popcorn; toss with a little olive oil, lemon zest, and dried thyme; serve immediately.");
    r.setMacroCategory("Low Carb");
    r.setCalories(170);
    r.setProtein(4);
    r.setFats(5);
    r.setCarbs(28);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 262. Berry Citrus Smoothie
{
    Recipe r = new Recipe();
    r.setRecipeName("Berry Citrus Smoothie");
    r.setRecipeDescription("A refreshing smoothie combining mixed berries with a splash of citrus juice.");
    r.setRecipeInstructions("Blend mixed berries with orange juice and a bit of water until smooth; serve chilled.");
    r.setMacroCategory("Balanced");
    r.setCalories(210);
    r.setProtein(5);
    r.setFats(3);
    r.setCarbs(45);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 263. Spicy Roasted Edamame
{
    Recipe r = new Recipe();
    r.setRecipeName("Spicy Roasted Edamame");
    r.setRecipeDescription("Edamame pods roasted with chili powder and sea salt for a zesty snack.");
    r.setRecipeInstructions("Toss edamame with a little olive oil, chili powder, and salt; roast until crisp; serve warm.");
    r.setMacroCategory("High Protein");
    r.setCalories(200);
    r.setProtein(16);
    r.setFats(7);
    r.setCarbs(18);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 264. Mini Veggie Frittata Bites
{
    Recipe r = new Recipe();
    r.setRecipeName("Mini Veggie Frittata Bites");
    r.setRecipeDescription("Bite-sized frittatas loaded with vegetables and baked in a mini muffin tin.");
    r.setRecipeInstructions("Whisk eggs with chopped veggies and herbs; pour into mini muffin tins; bake until set; serve warm or at room temperature.");
    r.setMacroCategory("High Protein");
    r.setCalories(240);
    r.setProtein(14);
    r.setFats(10);
    r.setCarbs(20);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 265. Vanilla Almond Yogurt Dip
{
    Recipe r = new Recipe();
    r.setRecipeName("Vanilla Almond Yogurt Dip");
    r.setRecipeDescription("A smooth yogurt dip flavored with vanilla and toasted almonds, perfect with fruit.");
    r.setRecipeInstructions("Mix Greek yogurt with vanilla extract and chopped toasted almonds; chill and serve with sliced apples.");
    r.setMacroCategory("High Protein");
    r.setCalories(220);
    r.setProtein(14);
    r.setFats(8);
    r.setCarbs(24);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 266. Cinnamon Quinoa Porridge
{
    Recipe r = new Recipe();
    r.setRecipeName("Cinnamon Quinoa Porridge");
    r.setRecipeDescription("Warm quinoa porridge flavored with cinnamon and a touch of maple syrup.");
    r.setRecipeInstructions("Cook quinoa in almond milk with cinnamon; stir in a little maple syrup; serve warm topped with berries.");
    r.setMacroCategory("High Protein");
    r.setCalories(230);
    r.setProtein(10);
    r.setFats(6);
    r.setCarbs(35);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free", "vegetarian"));
    recipes.add(r);
}

// 267. Fresh Strawberry Cups
{
    Recipe r = new Recipe();
    r.setRecipeName("Fresh Strawberry Cups");
    r.setRecipeDescription("Halved strawberries filled with a dollop of whipped Greek yogurt.");
    r.setRecipeInstructions("Slice strawberries in half; fill with a spoonful of lightly sweetened Greek yogurt; serve immediately.");
    r.setMacroCategory("High Protein");
    r.setCalories(190);
    r.setProtein(8);
    r.setFats(4);
    r.setCarbs(30);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 268. Tangy Mango Salsa with Chips
{
    Recipe r = new Recipe();
    r.setRecipeName("Tangy Mango Salsa with Chips");
    r.setRecipeDescription("Fresh mango salsa served with baked tortilla chips for a vibrant snack.");
    r.setRecipeInstructions("Dice mango, red onion, and cilantro; mix with lime juice; serve with baked tortilla chips.");
    r.setMacroCategory("Balanced");
    r.setCalories(210);
    r.setProtein(3);
    r.setFats(4);
    r.setCarbs(45);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}

// 269. Pumpkin Spice Yogurt
{
    Recipe r = new Recipe();
    r.setRecipeName("Pumpkin Spice Yogurt");
    r.setRecipeDescription("Greek yogurt blended with pumpkin puree and pumpkin spice for a seasonal treat.");
    r.setRecipeInstructions("Mix Greek yogurt with pumpkin puree and a pinch of pumpkin spice; serve chilled with a drizzle of honey.");
    r.setMacroCategory("High Protein");
    r.setCalories(210);
    r.setProtein(18);
    r.setFats(7);
    r.setCarbs(25);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("gluten_free"));
    recipes.add(r);
}

// 270. Herbal Green Tea Energy Bites
{
    Recipe r = new Recipe();
    r.setRecipeName("Herbal Green Tea Energy Bites");
    r.setRecipeDescription("No-bake energy bites infused with matcha green tea and rolled in shredded coconut.");
    r.setRecipeInstructions("Mix dates, oats, matcha powder, and a little almond butter; form into small balls; roll in shredded coconut; refrigerate until firm; serve.");
    r.setMacroCategory("High Protein");
    r.setCalories(230);
    r.setProtein(8);
    r.setFats(9);
    r.setCarbs(28);
    r.setMealType("Snack");
    r.setDietaryTags(Arrays.asList("vegan", "gluten_free", "vegetarian"));
    recipes.add(r);
}



                  

            

            // Finally, save them all in one go
            recipeRepository.saveAll(recipes);
        };
    }
}
