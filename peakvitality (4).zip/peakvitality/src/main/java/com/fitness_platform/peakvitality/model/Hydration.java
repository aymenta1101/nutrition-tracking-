package com.fitness_platform.peakvitality.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "hydration")
public class Hydration {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String userId;
    private int cups;
    private LocalDate date; // Store the date separately

    public Hydration() {}

    public Hydration(String userId, int cups, LocalDate date) {
        this.userId = userId;
        this.cups = cups;
        this.date = date;
    }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public int getCups() { return cups; }
    public void setCups(int cups) { this.cups = cups; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }
}
