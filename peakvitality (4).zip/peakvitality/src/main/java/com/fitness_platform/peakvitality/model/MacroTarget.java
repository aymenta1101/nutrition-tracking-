package com.fitness_platform.peakvitality.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//utility class for meal plan generation, stores the users macro targets within a single object
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor //lombok to reduce boilerplate
public class MacroTarget {
    private int proteinTarget;
    private int carbTarget;
    private int fatTarget; //values used to calculate macro targets per meal during dietary planning
    
}
