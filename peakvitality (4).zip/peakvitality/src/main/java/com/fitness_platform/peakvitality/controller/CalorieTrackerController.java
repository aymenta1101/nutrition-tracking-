package com.fitness_platform.peakvitality.controller;

import com.fitness_platform.peakvitality.model.CalorieEntry;
import com.fitness_platform.peakvitality.service.CalorieTrackerService;
import com.fitness_platform.peakvitality.model.CaloriePlan;
import com.fitness_platform.peakvitality.repository.CaloriePlanRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/calories")
@RequiredArgsConstructor // Lombok: dependency injection
public class CalorieTrackerController {
    private final CalorieTrackerService service;
    @Autowired
    private CaloriePlanRepository planRepository;

    @PostMapping
    public CalorieEntry logCalories(@RequestParam Long userId, @RequestParam int calories) {
        return service.logCalories(userId, calories);
    }

    @PostMapping("/plans")
    public ResponseEntity<CaloriePlan> saveCaloriePlan(@RequestBody CaloriePlan plan) {
        CaloriePlan saved = planRepository.save(plan);
        return ResponseEntity.ok(saved);                  //Change for test 5
    }

    @GetMapping
    public List<CalorieEntry> getEntries(@RequestParam Long userId) {
        return service.getEntries(userId);
    }
}