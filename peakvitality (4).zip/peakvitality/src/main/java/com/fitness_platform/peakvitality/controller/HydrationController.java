package com.fitness_platform.peakvitality.controller;

import com.fitness_platform.peakvitality.model.Hydration;
import com.fitness_platform.peakvitality.repository.HydrationRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/hydration")
public class HydrationController {
    private final HydrationRepository hydrationRepository;

    public HydrationController(HydrationRepository hydrationRepository) {
        this.hydrationRepository = hydrationRepository;
    }

    @PostMapping("/{userId}")
    public ResponseEntity<Hydration> addHydration(@PathVariable String userId, @RequestBody Hydration hydration) {
        if (hydration == null || userId.isEmpty() || hydration.getCups() <= 0) {
            return ResponseEntity.badRequest().build();
        }

        hydration.setUserId(userId);
        hydration.setDate(LocalDate.now()); // Store today's date
        return ResponseEntity.ok(hydrationRepository.save(hydration));
    }

    @GetMapping("/{userId}/{date}")
    public ResponseEntity<List<Hydration>> getHydrationByDate(@PathVariable String userId, @PathVariable String date) {
        return ResponseEntity.ok(hydrationRepository.findByUserIdAndDate(userId, LocalDate.parse(date)));
    }

    @GetMapping("/{userId}")
    public ResponseEntity<List<Hydration>> getHydrationDates(@PathVariable String userId) {
        return ResponseEntity.ok(hydrationRepository.findByUserId(userId));
    }

    @DeleteMapping("/{userId}/{date}")
    public ResponseEntity<String> clearHydrationByDate(@PathVariable String userId, @PathVariable String date) {
        hydrationRepository.deleteByUserIdAndDate(userId, LocalDate.parse(date));
        return ResponseEntity.ok("Hydration data for " + date + " cleared.");
    }
}
