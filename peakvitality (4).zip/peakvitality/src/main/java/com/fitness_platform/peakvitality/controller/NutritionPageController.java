package com.fitness_platform.peakvitality.controller;

import com.fitness_platform.peakvitality.model.FoodEntry;
import com.fitness_platform.peakvitality.service.FoodService;
import com.fitness_platform.peakvitality.service.MacroCalculatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/nutrition/dashboard")
public class NutritionPageController {

    @Autowired
    private MacroCalculatorService macroCalculatorService;

    @Autowired
    private FoodService foodService;

    @GetMapping
    public String dashboard(Model model) {
        model.addAttribute("foods", foodService.getAllFoods());
        return "nutrient-dashboard";
    }

    @PostMapping("/calculate-macros")
    public String calculateMacros(@RequestParam double weight,
                                  @RequestParam double height,
                                  Model model) {
        MacroCalculatorService.Macros macros = macroCalculatorService.calculateMacros(weight, height);
        model.addAttribute("recommendedMacros", macros);
        model.addAttribute("foods", foodService.getAllFoods());
        return "nutrient-dashboard";
    }

    @PostMapping("/add-food")
    public String addFoodEntry(@RequestParam Long foodId,
                               @RequestParam double quantity,
                               Model model) {
        foodService.addFoodEntry(foodId, quantity);
        model.addAttribute("foods", foodService.getAllFoods());
        return "redirect:/nutrition/dashboard";
    }

    @GetMapping("/progress")
    public String showProgress(Model model) {
        List<FoodEntry> entries = foodService.getWeeklyEntries();

        // Group entries by date and calculate totals
        Map<LocalDate, Map<String, Double>> dailySummaries = entries.stream()
                .collect(Collectors.groupingBy(
                        FoodEntry::getDate,
                        Collectors.collectingAndThen(
                                Collectors.toList(),
                                list -> {
                                    double protein = list.stream().mapToDouble(FoodEntry::getProtein).sum();
                                    double carbs = list.stream().mapToDouble(FoodEntry::getCarbs).sum();
                                    double fats = list.stream().mapToDouble(FoodEntry::getFats).sum();
                                    return Map.of(
                                            "protein", protein,
                                            "carbs", carbs,
                                            "fats", fats,
                                            "calories", protein * 4 + carbs * 4 + fats * 9
                                    );
                                }
                        )
                ));

        model.addAttribute("weeklyEntries", entries); // For the chart
        model.addAttribute("dailySummaries", dailySummaries); // For the table
        return "progress";
    }
}