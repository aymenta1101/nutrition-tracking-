package com.fitness_platform.peakvitality.controller;

import com.fitness_platform.peakvitality.model.DailyPlan;
import com.fitness_platform.peakvitality.model.MacroTarget;
import com.fitness_platform.peakvitality.model.Recipe;
import com.fitness_platform.peakvitality.repository.RecipeRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;


//controller class for all operations related to dietary planning

@Controller
public class DietaryPlanningController {

    @Autowired
    private RecipeRepository recipeRepository;

    @GetMapping("/dietary-planning")
    public String showForm(Model model, CsrfToken csrfToken) {
        model.addAttribute("_csrf", csrfToken);
        model.addAttribute("recipe", new Recipe());

        model.addAttribute("showTable", false); // Hide table by default
        return "dietary-planning";
    }

    @GetMapping("/dietary-planning.html")
    public String redirectToDietaryPlanning() {
        return "redirect:/dietary-planning";
    }

    @PostMapping("/dietary-planning/submit")
    public String processForm(

            @RequestParam(value = "goal", required = false) String goal,
            @RequestParam(value = "calories", required = false, defaultValue = "0") int calories,
            @RequestParam(value = "maintenance", required = false, defaultValue = "0") int maintenance,
            @RequestParam(value = "macro", required = false) String macro,
            @RequestParam(value = "dietaryPreferences[]", required = false) List<String> dietaryPreferences,
            Model model //get each form input, store within variables
    ) {
        //validation for inputs
        if (goal == null || goal.isEmpty() || macro == null || macro.isEmpty() || calories == 0 || maintenance == 0) {
            model.addAttribute("formError", "Please fill out all required fields");
            model.addAttribute("recipe", new Recipe());
            return "dietary-planning";
        }
        System.out.println("Goal: " + goal);
        System.out.println("Target Calories: " + calories);
        System.out.println("Maintenance: " + maintenance);
        System.out.println("Macro preference: " + macro); //test to print all stored info
        // Print dietary preferences (if selected)
        if (dietaryPreferences != null && !dietaryPreferences.isEmpty()) {
            System.out.println("Dietary Preferences: " + String.join(", ", dietaryPreferences));
        } else {
            System.out.println("No dietary preferences selected.");
        }
        MacroTarget macroTarget = calculateMacroTarget(macro, calories);
        int proteinTarget = macroTarget.getProteinTarget();
        int carbTarget = macroTarget.getCarbTarget();
        int fatTarget = macroTarget.getFatTarget();
        //calculate macro targets suing the macroTarget class.

        double mealCalTarget = calories * 0.75 / 3.0;
        double snackCalTarget = calories * 0.25 / 3.0;
        //target cals per meal/snack (75/25% split)

        int mealProteinTarget = (int) Math.round(proteinTarget * 0.75 / 3);
        int snackProteinTarget = (int) Math.round(proteinTarget * 0.25 / 3);
        //calculate protein target per meal/snack

        int mealCarbTarget = (int) Math.round(carbTarget * 0.75 / 3);
        int snackCarbTarget = (int) Math.round(carbTarget * 0.25 / 3);
        //calculate carb target per meal/snack

        int mealFatTarget = (int) Math.round(fatTarget * 0.75 / 3);
        int snackFatTarget = (int) Math.round(fatTarget * 0.25 / 3);
        //calculate fat target per meal/snack

        List<Recipe> allRecipes = recipeRepository.findAll(); //first, fetch all recipes

        List<Recipe> dietaryFilterRecipes = filterDietaryTags(allRecipes, dietaryPreferences); //then filter by dietary tags/preferences

        List<Recipe> mealMatches = filterMealsForTarget(dietaryFilterRecipes, mealCalTarget, mealCarbTarget, mealFatTarget, mealProteinTarget);
        List<Recipe> snackMatches = filterSnacksForTarget(dietaryFilterRecipes, snackCalTarget, snackCarbTarget, snackFatTarget, snackProteinTarget);
        //then, filter for meals and snacks that fit the users cal and macro goals 

        //generate weekly plan using the meals/snacks that match
        List<DailyPlan> weeklyPlan = generateWeeklyPlan(mealMatches, snackMatches);

        if (weeklyPlan == null) {
            model.addAttribute("errorMessage", "We could not find enough recipes to fit your goals. please consider uploading your own recipes, or change your requirements!");
            model.addAttribute("showTable", true); //error handling if not enough recipes found
        } else {
            model.addAttribute("weeklyPlan", weeklyPlan);
            model.addAttribute("showTable", true); // Show table after submit

        }


        System.out.println("showTable value: " + model.getAttribute("showTable"));

        model.addAttribute("recipe", new Recipe());

        return "dietary-planning";
    }

    @PostMapping("/recipes")
    public String uploadRecipe(@Valid @ModelAttribute Recipe recipe, BindingResult bindingResult, Model model) {
        //error handling
        if (bindingResult.hasErrors()) {
            model.addAttribute("recipeError", "Recipe not uploaded correctly. please ensure all fields are completed correctly"); //add error message to be displayed
            System.out.println("Error: Recipe not uploaded");
            //return to home
            return "dietary-planning";
        }
        recipeRepository.save(recipe); //save recipe to database
        System.out.println("Uploaded recipe: " + recipe.getRecipeName());

        model.addAttribute("uploadSuccess", "Recipe uploaded!");

        model.addAttribute("recipe", new Recipe());

        model.addAttribute("showTable", false);


        return "dietary-planning";


    }

    private MacroTarget calculateMacroTarget(String macro, int calories) {
        double proteinPercent, carbPercent, fatPercent;
        switch (macro.toLowerCase()) { //Assign macro split (percentage wise) depending on user selection
            case "high_protein":
                proteinPercent = 0.45;
                carbPercent = 0.35;
                fatPercent = 0.2;
                break;
            case "balanced":
                proteinPercent = 0.35;
                carbPercent = 0.4;
                fatPercent = 0.25;
                break;
            case "low_carb":
                proteinPercent = 0.45;
                carbPercent = 0.25;
                fatPercent = 0.3;
            default:
                proteinPercent = 0.35;
                carbPercent = 0.35;
                fatPercent = 0.3;
                break;
        }
        int proteinTarget = (int) Math.round((calories * proteinPercent) / 4);
        int carbTarget = (int) Math.round((calories * carbPercent) / 4);
        int fatTarget = (int) Math.round((calories * fatPercent) / 9);
        return new MacroTarget(proteinTarget, carbTarget, fatTarget); //calculate user daily protein target, carb target, and fat target. this is based of nutrition information that says carbs and protein is 4 cals per gram, whereas fats is 9 cals per gram


    }

    private List<Recipe> filterMealsForTarget(List<Recipe> recipes, double mealCalTarget, int mealCarbTarget, int mealFatTarget, int mealProteinTarget) {
        double calRange = 200;
        double proteinRange = 18;
        double carbRange = 18;
        double fatRange = 17; //define acceptable deviation range from calorie/macro targets

        List<Recipe> meals = recipes.stream()
                .filter(r -> "Meal".equalsIgnoreCase(r.getMealType()))
                .collect(Collectors.toList());
        //get a filtered list that only contains type MEAL (not snack)

        return meals.stream()
                .filter(r -> Math.abs(r.getCalories() - mealCalTarget) <= calRange) //within 200 cals above/below target cals
                .filter(r -> Math.abs(r.getProtein() - mealProteinTarget) <= proteinRange) //within 18 grams above/below target protein
                .filter(r -> Math.abs(r.getCarbs() - mealCarbTarget) <= carbRange) //within 18 grams above/below target carbs
                .filter(r -> Math.abs(r.getFats() - mealFatTarget) <= fatRange) //within 17 grams above/below target fats
                .collect(Collectors.toList());
        //return a list of all MEALS that fit within the acceptable threshold


    }

    private List<Recipe> filterSnacksForTarget(List<Recipe> recipes, double snackCalTarget, int snackCarbTarget, int snackFatTarget, int snackProteinTarget) {
        double calRange = 120.0;
        double proteinRange = 13;
        double carbRange = 13;
        double fatRange = 13;

        List<Recipe> snacks = recipes.stream()
                .filter(r -> "Snack".equalsIgnoreCase(r.getMealType()))
                .collect(Collectors.toList());
        //get a list that filters only meal type SNACK

        return snacks.stream()
                .filter(r -> Math.abs(r.getCalories() - snackCalTarget) <= calRange)
                .filter(r -> Math.abs(r.getProtein() - snackProteinTarget) <= proteinRange)
                .filter(r -> Math.abs(r.getCarbs() - snackCarbTarget) <= carbRange)
                .filter(r -> Math.abs(r.getFats() - snackFatTarget) <= fatRange) //same functionality  as method 'filterMealsForTarget'
                .collect(Collectors.toList());
        //return a list of all snacks that fit within acceptable threshold

    }

    private List<Recipe> filterDietaryTags(List<Recipe> recipes, List<String> dietaryTags) {
        if (dietaryTags == null || dietaryTags.isEmpty()) {
            return recipes;
        }
        return recipes.stream()
                .filter(r -> r.getDietaryTags() != null && r.getDietaryTags().containsAll(dietaryTags))
                .collect(Collectors.toList());
        //return a list of all recipes that contains ALL of the users dietary tags, and  also checks that the recipes
    }

    private List<DailyPlan> generateWeeklyPlan(List<Recipe> mealMatches, List<Recipe> snackMatches) {
        if (mealMatches.size() < 12) {
            System.out.println("not enough meals found");
            System.out.println("Total meals found:" + mealMatches.size());
            return null; //not enough meals found even with repeats: add a prompt for users to upload some of their own recipes, or adjust their goals and try again.
        }
        List<Recipe> selectedMeals = pickRandomRecipes(mealMatches, 21);

        //pick 21 random meals using helper method

        //shuffle the selected meals to ensure random distribution
        Collections.shuffle(selectedMeals);
        Random rand = new Random(); //used later for random snack selection


        List<DailyPlan> weeklyPlan = new ArrayList<>(); //define the weekly plan array outside the loop

        //spread selected meals and snacks across a 7 day meal plan
        for (int day = 0; day < 7; day++) {
            int index = day * 3;
            //each day gets 3 meals, 3 snacks. so this means from the total list of 21 randomly selected meals day 1 will get indexes 0,1,2. day 2 will get 3,4,5 and so on. 

            //Take 3 meals and  for each day, by creating a subList within the days calculated index.
            List<Recipe> dayMeals = selectedMeals.subList(index, index + 3);

            List<Recipe> daySnacks = new ArrayList<>();
            for (int i = 0; i < 3; i++) {
                //pick 3 random snacks for each day
                Recipe randomSnack = snackMatches.get(rand.nextInt(snackMatches.size()));
                daySnacks.add(randomSnack);
            }


            List<Recipe> dayRecipes = new ArrayList<>(); //create a new arrayList to combine meals and snacks into one
            dayRecipes.addAll(dayMeals);
            dayRecipes.addAll(daySnacks);
            //add both meals and snacks to the full day list

            //now this list can be used to calculate daily macro totals, using getter methods.
            int totalDailyCals = dayRecipes.stream().mapToInt(r -> r.getCalories()).sum();
            int totalDailyProtein = dayRecipes.stream().mapToInt(r -> r.getProtein()).sum();
            int totalDailyCarbs = dayRecipes.stream().mapToInt(r -> r.getCarbs()).sum();
            int totalDailyFats = dayRecipes.stream().mapToInt(r -> r.getFats()).sum();

            //create DailyPlan object to be added to the weekly plan list (this class is defined in the model folder)
            DailyPlan dayPlan = new DailyPlan(dayRecipes, totalDailyCals, totalDailyProtein, totalDailyCarbs, totalDailyFats);
            weeklyPlan.add(dayPlan);
        }
        return weeklyPlan;

    }

    private List<Recipe> pickRandomRecipes(List<Recipe> recipeList, int total) {
        List<Recipe> differentMeals = new ArrayList<>(recipeList); //copy the inputted list into a temp variable so it isnt modified
        Collections.shuffle(differentMeals); //randomize order of recipes within the  list
        System.out.println("Total recipes found: " + differentMeals.size());

        //check if there are enough recipes to return 'total' (when allowing for recipes to appear up to 2 times)
        if ((differentMeals.size() * 2) < total) {
            return null;
        }

        List<Recipe> Selected = new ArrayList<>();
        List<Recipe> Repeats = new ArrayList<>();
        //initalise list objects for both selected recipes and potential repeats (if there arent enough unique recipes)

        for (Recipe r : differentMeals) {
            if (Selected.size() < total) {
                Selected.add(r); //add each recipe to the selected list (in previously randomised order)
                Repeats.add(r); // add a recipe thats been used to the repeats list
            } else {
                break; //break loop if total is reached
            }
        }

        //if total still isnt reached, start adding repeats
        //first randomise repeats list order
        Collections.shuffle(Repeats);
        for (Recipe r : Repeats) {
            if (Selected.size() < total) {
                Selected.add(r);

            } else {
                break;
            }
        }


        return Selected; //return 'total'Selected recipes
    }


}




