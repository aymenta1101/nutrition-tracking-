package com.fitness_platform.peakvitality.service;

import org.springframework.stereotype.Service;

import com.fitness_platform.peakvitality.model.WorkoutTool;
import com.fitness_platform.peakvitality.repository.WorkoutRepository;

import java.util.List;

@Service
public class WorkoutService {
    private final WorkoutRepository repository;

    public WorkoutService(WorkoutRepository repository) {
        this.repository = repository;
    }

    public WorkoutTool saveWorkout(WorkoutTool workout) {
        return repository.save(workout);
    }

    public List<WorkoutTool> getAllWorkouts() {
        return repository.findAll();
    }
}

