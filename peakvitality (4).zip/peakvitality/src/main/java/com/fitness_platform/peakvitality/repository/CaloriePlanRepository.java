package com.fitness_platform.peakvitality.repository;

import com.fitness_platform.peakvitality.model.CaloriePlan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CaloriePlanRepository extends JpaRepository<CaloriePlan, Long> {
}