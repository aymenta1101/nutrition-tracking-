package com.fitness_platform.peakvitality.model;

import jakarta.persistence.*;

@Entity
public class WorkoutTool {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;     // Exercise name
    private String type;     // Strength, Cardio, Flexibility
    private int duration;    // Duration in minutes (for cardio/flexibility)
    private int sets;        // For strength workouts
    private int reps;        // For strength workouts

    // Constructors
    public WorkoutTool() {}

    public WorkoutTool(String name, String type, int duration, int sets, int reps) {
        this.name = name;
        this.type = type;
        this.duration = duration;
        this.sets = sets;
        this.reps = reps;
    }

    // Getters and Setters
    public Long getId() { return id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public int getDuration() { return duration; }
    public void setDuration(int duration) { this.duration = duration; }

    public int getSets() { return sets; }
    public void setSets(int sets) { this.sets = sets; }

    public int getReps() { return reps; }
    public void setReps(int reps) { this.reps = reps; }
}
