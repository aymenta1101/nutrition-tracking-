package com.fitness_platform.peakvitality.model;

import lombok.*;
import jakarta.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "habits")

public class Habit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_ID", nullable = false)
    private User user;

    private String habitName;
    private int targetGoal;
    private int score;
    private String habitTime;
    

public Habit(User user, Long habitID, String habitName, int targetGoal, int score, String habitTime) {
    this.habitName = habitName;
    this.targetGoal = targetGoal;
    this.score = score;
    this.habitTime = habitTime;
    }
}
