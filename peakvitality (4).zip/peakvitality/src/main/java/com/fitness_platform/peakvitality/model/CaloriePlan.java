package com.fitness_platform.peakvitality.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CaloriePlan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;
    private int age;
    private String gender;
    private float height;
    private float weight;
    private float targetWeight;
    private String pace;
    private int weeksToGoal;
    private LocalDate targetDate;

    @ElementCollection
    private List<Integer> weeklyTargets; //Change for test 5
}