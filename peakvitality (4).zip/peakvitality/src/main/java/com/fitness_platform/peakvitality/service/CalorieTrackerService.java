package com.fitness_platform.peakvitality.service;

import com.fitness_platform.peakvitality.model.CalorieEntry;
import com.fitness_platform.peakvitality.repository.CalorieEntryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CalorieTrackerService {
    private final CalorieEntryRepository repository;

    public CalorieEntry logCalories(Long userId, int calories) {
        LocalDate today = LocalDate.now();
        List<CalorieEntry> existing = repository.findByUserIdAndDate(userId, today);
        
        if (!existing.isEmpty()) {
            CalorieEntry entry = existing.get(0);
            entry.setCalories(entry.getCalories() + calories);
            return repository.save(entry);
        } else {
            CalorieEntry entry = new CalorieEntry();
            entry.setUserId(userId);
            entry.setCalories(calories);
            entry.setDate(today);
            return repository.save(entry);
        }
    }

    public List<CalorieEntry> getEntries(Long userId) {
        return repository.findByUserId(userId);
    }
}