package com.fitness_platform.peakvitality.service;

import com.fitness_platform.peakvitality.repository.HydrationRepository;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import java.time.LocalDate;

@Service
public class HydrationResetService {
    private final HydrationRepository hydrationRepository;

    public HydrationResetService(HydrationRepository hydrationRepository) {
        this.hydrationRepository = hydrationRepository;
    }

    @Scheduled(cron = "0 0 0 * * ?") // Runs every day at midnight
    public void resetDailyHydration() {
        LocalDate today = LocalDate.now();
        hydrationRepository.deleteByUserIdAndDate("user123", today);
    }
}
