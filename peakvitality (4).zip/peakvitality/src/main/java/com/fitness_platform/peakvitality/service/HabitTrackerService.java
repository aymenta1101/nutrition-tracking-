package com.fitness_platform.peakvitality.service;

import com.fitness_platform.peakvitality.model.Habit;
import com.fitness_platform.peakvitality.model.User;
import com.fitness_platform.peakvitality.repository.HabitRepository;
import com.fitness_platform.peakvitality.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class HabitTrackerService {

    private final HabitRepository habitRepository;
    private final UserRepository userRepository;

    public HabitTrackerService(HabitRepository habitRepository, UserRepository userRepository) {
        this.habitRepository = habitRepository;
        this.userRepository = userRepository;
    }

    public List<Habit> getHabitByName(Long userId, String habitName) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with ID: " + userId));
        return habitRepository.findByUserAndHabitName(user, habitName);
    }

    public List<Habit> getHabitsByUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with ID: " + userId));
        return habitRepository.findByUser(user);
    }

    public Habit createHabit(Habit habit, Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with ID: " + userId));
        habit.setUser(user);
        return habitRepository.save(habit);
    }

    public void deleteHabit(Long userId, String habitName) {
        Habit habit = habitRepository.findByUserIdAndHabitName(userId, habitName)
                .orElseThrow(() -> new EntityNotFoundException("Habit not found for user ID: " + userId + " with name: " + habitName));
        habitRepository.delete(habit);
    }

    public Habit savedHabit(Habit habit, Long userId) {
        User user = userRepository.findById(userId).
                orElseThrow(() -> new EntityNotFoundException("Habit cannot be saved"));
        habit.setUser(user);
        return habitRepository.save(habit);
    }
}
