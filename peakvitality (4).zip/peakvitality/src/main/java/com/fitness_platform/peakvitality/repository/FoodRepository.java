package com.fitness_platform.peakvitality.repository;

import com.fitness_platform.peakvitality.model.Food;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface FoodRepository extends JpaRepository<Food, Long> {

    Optional<Food> findByName(String name);
}