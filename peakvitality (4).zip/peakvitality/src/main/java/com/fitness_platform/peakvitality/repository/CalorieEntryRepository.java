package com.fitness_platform.peakvitality.repository;

import com.fitness_platform.peakvitality.model.CalorieEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;

public interface CalorieEntryRepository extends JpaRepository<CalorieEntry, Long> {
    List<CalorieEntry> findByUserId(Long userId);
    List<CalorieEntry> findByUserIdAndDate(Long userId, LocalDate date);
}