package com.fitness_platform.peakvitality.repository;

import com.fitness_platform.peakvitality.model.Hydration;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;

public interface HydrationRepository extends JpaRepository<Hydration, Long> {
    List<Hydration> findByUserIdAndDate(String userId, LocalDate date);
    List<Hydration> findByUserId(String userId);
    void deleteByUserIdAndDate(String userId, LocalDate date);
}
