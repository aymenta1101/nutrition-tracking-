package com.fitness_platform.peakvitality.service;


import org.springframework.stereotype.Service;

@Service
public class MacroCalculatorService {
    public static class Macros {
        public double protein;
        public double carbs;
        public double fats;

        public Macros(double protein, double carbs, double fats) {
            this.protein = protein;
            this.carbs = carbs;
            this.fats = fats;
        }
    }

    // Simplified Mifflin-St Jeor for BMR and macro calculation
    public Macros calculateMacros(double weightKg, double heightCm) {
        double bmr = 10 * weightKg + 6.25 * heightCm - 5 * 25 + 5; // Assume age 25, male
        double calories = bmr * 1.55; // Moderate activity level

        // 30% protein, 40% carbs, 30% fats
        double protein = (calories * 0.3) / 4;
        double carbs = (calories * 0.4) / 4;
        double fats = (calories * 0.3) / 9;

        return new Macros(protein, carbs, fats);
    }
}