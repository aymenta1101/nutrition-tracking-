package com.fitness_platform.peakvitality.controller;
import com.fitness_platform.peakvitality.model.Habit;
import com.fitness_platform.peakvitality.repository.HabitRepository;
import com.fitness_platform.peakvitality.service.HabitTrackerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api/create-habit")
public class HabitTrackerController {

    @Autowired
    private HabitTrackerService habitTrackerService;

    private final HabitRepository habitRepository;

    public HabitTrackerController(HabitRepository habitRepository){
        this.habitRepository = habitRepository;
    }
    @GetMapping("/Create")
    public String showHabitForm() {
        return "create-habit";
    }
    @PostMapping
    public ResponseEntity<Habit> createHabit(@RequestBody Habit habit) {
        Habit savedHabit = habitRepository.save(habit);
        return ResponseEntity.ok(savedHabit);
    }

    @GetMapping("/edit")
    public ResponseEntity<List<Habit>> getAllHabits() {
        List<Habit> habits = habitRepository.findAll();
        return ResponseEntity.ok(habits);
    }  

    @GetMapping("/{userId}")
    public ResponseEntity<Habit> getHabitById(@PathVariable Long ID) {
        Optional<Habit> habit = habitRepository.findById(ID);
        return habit.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{userId}")
    public ResponseEntity<Object> deleteHabit(@PathVariable Long id) {
        return habitRepository.findById(id).map(habit -> {
            habitRepository.delete(habit);
            return ResponseEntity.noContent().build();
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/add")
    @ResponseBody
    public String addHabit(@RequestBody Habit habit){
        habitTrackerService.savedHabit(habit, null);
        return "Habit created";
    }
    
}