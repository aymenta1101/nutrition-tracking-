package com.fitness_platform.peakvitality.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.fitness_platform.peakvitality.model.Recipe;
//repository class, acts as a data access layer used for CRUD operations including filtering, adding and deleting recipes within the h2 database.
public interface RecipeRepository extends JpaRepository<Recipe, Long> {
    
    
}
