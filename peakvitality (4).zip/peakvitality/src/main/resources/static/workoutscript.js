let lastGeneratedWorkout = [];

const workoutData = {
  strength: ["Push-Ups", "Squats", "Dumbbell Rows", "Lunges", "Plank", "Deadlifts"],
  cardio: ["Jumping Jacks", "Burpees", "High Knees", "Mountain Climbers", "Jump Rope", "Running in Place"],
  flexibility: ["Yoga Stretches", "Hamstring Stretch", "Shoulder Rolls", "Side Bends", "Cat-Cow Stretch", "Toe Touches"]
};

// Show or hide fields based on selected workout type
document.getElementById("goal").addEventListener("change", function () {
  const isStrength = this.value === "strength";

  // Show/hide duration
  document.getElementById("duration").style.display = isStrength ? "none" : "block";
  document.getElementById("duration").previousElementSibling.style.display = isStrength ? "none" : "block";

  // Show/hide sets and reps (only for strength)
  document.getElementById("sets").style.display = isStrength ? "block" : "none";
  document.getElementById("sets-label").style.display = isStrength ? "block" : "none";
  document.getElementById("reps").style.display = isStrength ? "block" : "none";
  document.getElementById("reps-label").style.display = isStrength ? "block" : "none";
});

function getRandomExercises(exerciseList, totalDuration, isStrength) {
  let exercises = [...exerciseList];
  let selectedExercises = [];
  let remainingTime = totalDuration;

  while (remainingTime > 0 && exercises.length > 0) {
    let randomIndex = Math.floor(Math.random() * exercises.length);
    let selectedExercise = exercises.splice(randomIndex, 1)[0];

    let duration = isStrength ? 0 : Math.min(remainingTime, Math.floor(Math.random() * 11) + 5);
    let sets = isStrength ? (Math.floor(Math.random() * 3) + 3) : null; // Random 3-5 sets
    let reps = isStrength ? (Math.floor(Math.random() * 10) + 5) : null; // Random 5-15 reps

    selectedExercises.push({ name: selectedExercise, duration, sets, reps });
    remainingTime -= duration;
  }

  return selectedExercises;
}

function generateWorkout() {
  const goal = document.getElementById("goal").value;
  const duration = parseInt(document.getElementById("duration").value, 10);
  const isStrength = goal === "strength";

  const setsInput = parseInt(document.getElementById("sets").value, 10);
  const repsInput = parseInt(document.getElementById("reps").value, 10);

  if (isStrength && (setsInput <= 0 || repsInput <= 0 || isNaN(setsInput) || isNaN(repsInput))) {
    alert("Please enter a valid number greater than 0 for both sets and reps.");
    return; // Stop the function if input is invalid
  }

  const workoutList = document.getElementById("workout-list");
  const totalDurationElement = document.getElementById("total-duration");

  let selectedExercises = getRandomExercises(workoutData[goal], duration, isStrength);

  workoutList.innerHTML = ""; 
  let totalTime = 0;

  selectedExercises.forEach(exercise => {
    const li = document.createElement("li");

    if (isStrength) {
      li.textContent = `${exercise.name} - ${setsInput} sets of ${repsInput} reps`;
    } else {
      li.textContent = `${exercise.name} - ${exercise.duration} minutes`;
      totalTime += exercise.duration;
    }

    workoutList.appendChild(li);
  });

  totalDurationElement.innerHTML = isStrength
    ? `<strong>Strength Workout:</strong> Based on sets & reps`
    : `<strong>Total Duration:</strong> ${totalTime} minutes`;

  document.getElementById("save-button").style.display = "block";
}


function saveWorkout() {
  const goal = document.getElementById("goal").value;
  const duration = parseInt(document.getElementById("duration").value, 10);
  const isStrength = goal === "strength";
  const sets = isStrength ? parseInt(document.getElementById("sets").value) : 0;
  const reps = isStrength ? parseInt(document.getElementById("reps").value) : 0;

  const workoutListItems = document.querySelectorAll("#workout-list li");

  // Send one POST request per exercise
  workoutListItems.forEach(item => {
    const name = item.textContent.split(" - ")[0]; // Get the exercise name
    const singleWorkout = {
      name: name,
      type: goal,
      duration: isStrength ? 0 : duration, // You can adjust per-exercise duration if needed
      sets: isStrength ? sets : 0,
      reps: isStrength ? reps : 0
    };

    fetch("http://localhost:8080/api/workouts/save", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(singleWorkout)
    })
    .then(response => {
      if (response.ok) {
        console.log(`Saved workout: ${name}`);
      } else {
        console.error("Failed to save workout.");
      }
    })
    .catch(error => {
      console.error("Error saving workout:", error);
    });
  });

  alert("Workout saved!");
}

