document.addEventListener("DOMContentLoaded", () => {
    const hydrationChartCanvas = document.getElementById("hydrationChart");
    const hydrationForm = document.getElementById("hydration-form");
    const clearButton = document.getElementById("clear-button");
    const popup = document.getElementById("clear-popup");
    const confirmClear = document.getElementById("confirm-clear");
    const cancelClear = document.getElementById("cancel-clear");
    const dateListContainer = document.getElementById("date-list");

    let hydrationChart;
    let hydrationData = [];
    let selectedDate = new Date().toISOString().split("T")[0];

    function initializeChart() {
        if (hydrationChart) {
            hydrationChart.destroy();
        }

        hydrationChart = new Chart(hydrationChartCanvas.getContext("2d"), {
            type: "bar",
            data: {
                labels: [],
                datasets: [{
                    label: "Cups of Water Drank",
                    data: [],
                    backgroundColor: "rgba(30, 144, 255, 0.6)",
                    borderColor: "rgba(30, 144, 255, 1)",
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 20
                    }
                }
            }
        });
    }

    function updateHydrationChart() {
        if (!hydrationChart) {
            initializeChart();
        }

        hydrationChart.data.labels = hydrationData.map(entry => 
            new Date(entry.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
        );
        hydrationChart.data.datasets[0].data = hydrationData.map(entry => entry.cups);

        hydrationChart.update();
    }

    async function fetchHydrationDataByDate(date) {
        try {
            console.log(`Fetching hydration data for ${date}...`);
            const response = await fetch(`http://localhost:8080/api/hydration/admin123/${date}`);
            const data = await response.json();
            console.log("Fetched data:", data);

            if (Array.isArray(data) && data.length > 0) {
                hydrationData = data;
            } else {
                hydrationData = [];
            }
            updateHydrationChart();
        } catch (error) {
            console.error("Error fetching hydration data:", error);
        }
    }

    async function fetchHydrationDates() {
        try {
            console.log("Fetching available hydration dates...");
            const response = await fetch("http://localhost:8080/api/hydration/admin123");
            const data = await response.json();
            console.log("Fetched dates:", data);

            dateListContainer.innerHTML = "";

            const uniqueDates = [...new Set(data.map(entry => entry.date))];

            uniqueDates.forEach(date => {
                const dateButton = document.createElement("button");
                dateButton.textContent = date;
                dateButton.onclick = () => {
                    selectedDate = date;
                    fetchHydrationDataByDate(date);
                };
                dateListContainer.appendChild(dateButton);
            });
        } catch (error) {
            console.error("Error fetching hydration dates:", error);
        }
    }

    async function submitHydrationData(cups) {
        const newEntry = { cups: cups, date: selectedDate };

        try {
            console.log("Submitting:", newEntry);
            const response = await fetch(`http://localhost:8080/api/hydration/admin123`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(newEntry)
            });

            if (response.ok) {
                console.log("Submission successful, fetching updated data...");
                await fetchHydrationDataByDate(selectedDate);
                await fetchHydrationDates();
            } else {
                console.error("Error submitting hydration data:", response.status);
            }
        } catch (error) {
            console.error("Error submitting hydration data:", error);
        }
    }

    function confirmTracking(event) {
        event.preventDefault();
        const cupsInput = document.getElementById("cups").value;
        const cups = parseInt(cupsInput, 10);

        if (!cups || cups <= 0) {
            alert("Please enter a valid number of cups.");
            return;
        }

        if (cups > 10) {
            alert("You cannot track more than 10 cups of water at once.");
            return;
        }

        submitHydrationData(cups);
    }

    async function clearHydrationData() {
        try {
            console.log("Clearing hydration data from backend...");
            
            const response = await fetch("http://localhost:8080/api/hydration/admin123", {
                method: "DELETE",
                headers: { "Content-Type": "application/json" }
            });
    
            if (response.ok) {
                console.log("Data cleared from backend.");
                
               
                hydrationData = [];
                updateHydrationChart();
    
               
                await fetchHydrationData();
    
                alert("Hydration data has been permanently deleted.");
            } else {
                console.error("Error clearing hydration data:", response.status);
                alert("Failed to clear hydration data. Please try again.");
            }
        } catch (error) {
            console.error("Success:", error);
            alert("Hydration data has been permanently deleted.");
        }
    
        popup.style.display = "none";
    }

    clearButton.addEventListener("click", () => popup.style.display = "flex");
    confirmClear.addEventListener("click", clearHydrationData);
    cancelClear.addEventListener("click", () => popup.style.display = "none");
    hydrationForm.addEventListener("submit", confirmTracking);

    initializeChart();
    fetchHydrationDataByDate(selectedDate);
    fetchHydrationDates();
});
