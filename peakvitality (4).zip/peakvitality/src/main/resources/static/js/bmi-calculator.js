function calculateBMI() 
        {
            const height = parseFloat(document.getElementById('height').value) / 100; // Convert cm to meters
            const weight = parseFloat(document.getElementById('weight').value);
            if (!height || !weight || height <= 0 || weight <= 0) 
            {
                alert('Please enter valid height and weight values.');
                return;
            }
            const bmi = (weight / (height * height)).toFixed(2);

            if (bmi < 16.5) {
                category = 'Severely underweight';
                description = 'This is a very low BMI, indicating severe malnutrition or other health issues. Seek medical advice.';
            } else if (bmi < 18.5) {
                category = 'Underweight';
                description = 'Being underweight may lead to health issues like fatigue and weakened immunity.';
            } else if (bmi < 25) {
                category = 'Normal weight';
                description = 'You have a healthy BMI. Keep up your balanced diet and regular exercise.';
            } else if (bmi < 30) {
                category = 'Overweight';
                description = 'This BMI indicates excess weight. Consider a healthier diet and increased physical activity.';
            } else {
                category = 'Obese';
                description = 'This BMI indicates obesity, which increases the risk of various health problems. Consult a healthcare provider.';
            }

            document.getElementById('bmiResult').innerHTML = `Your BMI is: ${bmi} (<strong>${category}</strong>)<br><br>${description}`;
         }