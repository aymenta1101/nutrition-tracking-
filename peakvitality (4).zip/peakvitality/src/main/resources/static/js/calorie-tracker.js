const API_BASE_URL = 'http://localhost:8080/api/calories';

async function postCalories(userId, calories) {
  const response = await fetch(`${API_BASE_URL}?userId=${userId}&calories=${calories}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  });
  return await response.json();
}

async function getCalories(userId) {
  const response = await fetch(`${API_BASE_URL}?userId=${userId}`);
  return await response.json();
}

async function savePlanToBackend(userId, planData) {
    const today = new Date();
    const entries = weeklyTargets.map((calories, index) => {
      const date = new Date(today);
      date.setDate(today.getDate() + index * 7); // 1 entry per week
      return {
        calories,
        date: date.toISOString().split("T")[0]
      };
    });
  
    const payload = {
      userId,
      age: parseInt(planData.userData.age),
      gender: planData.userData.gender,
      height: parseFloat(planData.userData.height),
      weight: parseFloat(planData.userData.weight),
      targetWeight: parseFloat(planData.userData.targetWeight),
      pace: planData.userData.weightChangePace,
      weeksToGoal: entries.length,
      targetDate: new Date(new Date().setDate(today.getDate() + entries.length * 7)).toISOString().split("T")[0],
      weeklyTargets: weeklyTargets //Change for test 5
    };
  
    const response = await fetch(`${API_BASE_URL}/plans`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
  
    return await response.json();
}

let barChart, lineChart;
let weeklyTargets = [];
let calorieLogs = [];
let lastLogTime = 0;

// Temporary Migration Code to fix localStorage format before I use backend
/*
const weeklyTargetsData = localStorage.getItem("weeklyTargets");
if (weeklyTargetsData) {
    const currentData = JSON.parse(localStorage.getItem("calorieTrackerData") || "{}");
    const parsedOld = JSON.parse(weeklyTargetsData);
    
    localStorage.setItem("calorieTrackerData", JSON.stringify({
        ...currentData,
        weeklyTargets: parsedOld.targets || currentData.weeklyTargets || [],
        userData: {
            ...(currentData.userData || {}),
            weight: parsedOld.userWeight || currentData.userData?.weight || "",
            targetWeight: parsedOld.targetWeight || currentData.userData?.targetWeight || "",
            weightChangePace: parsedOld.weightChangePace || currentData.userData?.weightChangePace || ""
        }
    }));
    
    localStorage.removeItem("weeklyTargets"); // Clean up old format
    console.log("Migration completed - old data moved to calorieTrackerData");
}
*/
// End of Migration Code

document.addEventListener("DOMContentLoaded", async () => {
    initialiseCharts();
    setupEventListeners();
    loadData();
});

function initialiseCharts(){
    const calorieCtx = document.getElementById("calorieBarChart").getContext("2d");
    calorieBarChart = new Chart(calorieCtx, {
        type: "bar",
        data: {
            labels: [],
            datasets: [{
                label: "Weekly Target Calories",
                data: [],
                backgroundColor: "#66bb6a",
                borderColor: "#388e3c",
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: "top"
                },
                title: {
                    display: true,
                    text: "Weekly Target Calories"
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: "Calories (kcal)"
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: "Weeks"
                    }
                }
            }
        }
    });
    const progressCtx = document.getElementById("calorieLineChart").getContext("2d");
    lineChart = new Chart(progressCtx, {
        type: "line",
        data: {
            labels: [],
            datasets: [{
                label: "Daily Calorie Target",
                data: [],
                backgroundColor: "#42a5f5",
                borderColor: "#1e88e5",
                fill: true,
                tension: 0.1
            }]},
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: "top"
                },
                title: {
                    display: true,
                    text: "Daily Calorie Intake vs Target"
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: "Calories (kcal)"
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: "Days"
                    }
                }
            }
        }

    });
}

function setupEventListeners(){
    //Profile Inputs
    
    document.getElementById("generateButton").addEventListener("click", generatePlan);
    document.getElementById("logCalorieButton").addEventListener("click", logCalories);

    document.querySelectorAll(".time-filter").forEach(button => {
        button.addEventListener("click", () => {
            document.querySelectorAll(".time-filter").forEach(btn => btn.classList.remove("active"));
            button.classList.add("active");
            filterChartData(parseInt(button.dataset.days));
        });
    });
}

function getActivityMultiplier(exerciseFrequency){
    switch (exerciseFrequency){
        case 1:
            return 1.2;
        case 2:
            return 1.375;
        case 3:
            return 1.55;
        case 4:
            return 1.725;
        case 5:
            return 1.9;
        default:
            return 1.2; 
    }
}

function calculateTDEE(){
    let age = parseInt(document.getElementById("userAge").value);
    let gender = document.getElementById("userGender").value;
    let height = parseFloat(document.getElementById("userHeight").value);
    let weight = parseFloat(document.getElementById("userWeight").value);
    let exerciseFrequency = parseFloat(document.getElementById("exerciseFrequency").value);
    let activityMultiplier = getActivityMultiplier(exerciseFrequency);

    let bmr;
    if (gender === "male"){
        bmr = 10 * weight + 6.25 * height - 5 * age + 5;
    }
    else if (gender === "female"){
        bmr = 10 * weight + 6.25 * height - 5 * age - 161;
    }

    if (!age || !gender || !height || !weight || !exerciseFrequency){
        return;
    }
    
    let tdee = Math.round(bmr * activityMultiplier);
    document.getElementById("currentCalorieMaintenance").innerText = `${tdee} kcal/day`;
    return tdee;
}

function getWeightChangePace(){
    let pace = document.getElementById("weightChangePace").value;
    if (pace === "normal"){
        return 0.5; 
    }
    else if (pace === "strict"){
        return 1; 
    }
    else{
        console.log("Error: Invalid weight change pace selected.");
        return 0;
    }
}

function calculateWeeklyTargets(){
    let targets = [];
    let tdee = calculateTDEE();
    let weightChangePace = getWeightChangePace();
    let userWeight = parseFloat(document.getElementById("userWeight").value);
    let targetWeight = parseFloat(document.getElementById("targetWeight").value);
    let weeksRequired = Math.ceil(Math.abs(targetWeight - userWeight) / weightChangePace);
    let isGaining = targetWeight > userWeight;
    let isLosing = targetWeight < userWeight;

    for (let i = 0; i < weeksRequired; i++){
        if (weightChangePace === 0.5){
            if (isGaining){
                if (i === 0){
                    targets.push(Math.round(tdee + 500));
                }
                else{
                    targets.push(Math.round(targets[i-1] + 8));
                }
            }
            else if (isLosing){
                if (i === 0){
                    targets.push(Math.round(tdee - 500));
                }
                else{
                    targets.push(Math.round(targets[i-1] - 8));
                }
            }
            else{
                console.log("Error");
            }
        }
        
        else if (weightChangePace === 1){
            if (isGaining){
                if (i === 0){
                    targets.push(Math.round(tdee + 1000));
                }
                else{
                    targets.push(Math.round(targets[i-1] + 16));
                }
            }
            else if (isLosing){
                if (i === 0){
                    targets.push(Math.round(tdee - 1000));
                }
                else{
                    targets.push(Math.round(targets[i-1] - 16));
                }
            }
            else{
                console.log("Error");
            }
        }
        else{
            console.log("Error");
        }
    }

    return targets;
     
}

function validatePlanInputs(){
    let age = parseInt(document.getElementById("userAge").value);
    let gender = document.getElementById("userGender").value;
    let height = parseFloat(document.getElementById("userHeight").value);
    let weight = parseFloat(document.getElementById("userWeight").value);
    let exerciseFrequency = document.getElementById("exerciseFrequency").value;
    let targetWeight = parseFloat(document.getElementById("targetWeight").value);
    let weightChangePace = document.getElementById("weightChangePace").value;

    //Checks all fields are filled in
    if (!age || !gender || !height || !weight || !exerciseFrequency || !targetWeight || !weightChangePace){
        alert("Please fill in all fields before generating a plan.");
        return false;
    }

    //Checks numeric fields are valid numbers
    if (age < 16 || age > 100){
        alert("Please enter a valid age (16-100).");
        return false;
    }
    if (height < 100 || height > 250){
        alert("Please enter a valid height (100-250 cm).");
        return false;
    }
    if (weight < 30 || weight > 300){
        alert("Please enter a valid weight (30-300 kg).");
        return false;
    }
    if (targetWeight < 40 || targetWeight > 300){
        alert("Please enter a valid target weight (40-300 kg).");
        return false;
    }
    return true;
}

async function generatePlan(){
    if (!validatePlanInputs()){
        return;
    }

    let pace = getWeightChangePace();
    let currentWeight = parseFloat(document.getElementById("userWeight").value);
    let targetWeight = parseFloat(document.getElementById("targetWeight").value);
    let weeksRequired = Math.ceil(Math.abs(targetWeight - currentWeight) / pace);

    let targetDate = new Date();
    targetDate.setDate(targetDate.getDate() + weeksRequired * 7);
    document.getElementById("targetDateInfo").innerHTML = 
        `<p><strong>Weeks Required to reach Target:</strong> ${weeksRequired}</p>
        <p><strong>Target Date:</strong> ${targetDate.toLocaleDateString()}</p>
        `;

    weeklyTargets = calculateWeeklyTargets();

    updateBarChart();

    //savePlanToBackend(weeksRequired, weeklyTargets);
    const userId = 1;  // 🔁 use a placeholder for now
    const planData = {
        userData: {
            age: document.getElementById("userAge").value,
            gender: document.getElementById("userGender").value,
            height: document.getElementById("userHeight").value,
            weight: document.getElementById("userWeight").value,
            targetWeight: document.getElementById("targetWeight").value,
            weightChangePace: document.getElementById("weightChangePace").value,
        }
    };
    
    savePlanToBackend(userId, planData);
}
    



function updateBarChart(){
    let labels = weeklyTargets.map((_, index) => `Week ${index + 1}`);
    calorieBarChart.data.labels = labels;
    calorieBarChart.data.datasets[0].data = weeklyTargets;
    calorieBarChart.update();
}

function checkLogTime(){
    let now = new Date();
    let lastLog = lastLogTime ? new Date(lastLogTime) : null;

    if (lastLog && (now - lastLog) < 24 * 3600 * 1000){
        let nextLogTime = new Date(lastLog);
        nextLogTime.setDate(nextLogTime.getDate() + 1);
        nextLogTime.setHours(19, 0, 0);

        if (now < nextLogTime){
            document.getElementById("timeLockMessage").classList.remove("hidden");
            document.getElementById("nextLogTime").textContent =
                nextLogTime.toLocaleString([], {hour: '2-digit', minute: '2-digit'});
            document.getElementById("logCalorieButton").disabled = true;
            return true;
        }
    }
    document.getElementById("timeLockMessage").classList.add("hidden");
    document.getElementById("logCalorieButton").disabled = false;
    return false;

}

async function logCalories(){
    if (checkLogTime()) {
        return;
    }

    let calorieInput = parseFloat(document.getElementById("calorieInput").value);
    let calories = parseFloat(calorieInput);
    const userID = 1;

    if (isNaN(calories) || calories <= 0){
        alert("Please enter a valid calorie amount.");
        return;
    }

    let today = new Date().toISOString().split("T")[0];
    await postCalories(userID, calories);
    let existingIndex = calorieLogs.findIndex(log => log.date === today);

    if (existingIndex >= 0){
        calorieLogs[existingIndex].calories += calories;
    }
    else{
        calorieLogs.push({date: today, calories: calories});
    }

    lastLogTime = new Date().toISOString();
    document.getElementById("logFeedback").textContent = `Logged ${calories} calories for ${today}`;
    document.getElementById("calorieInput").value = ""; // Clear input field

    checkLogTime();
    updateLineChart();
    //saveData();
}

function updateLineChart(daysToShow = 7){
    let sortedLogs = [...calorieLogs].sort((a, b) => new Date(a.date) - new Date(b.date));

    let filteredLogs = sortedLogs;
    if (daysToShow > 0 && daysToShow !== "all"){
        let cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - daysToShow);
        filteredLogs = sortedLogs.filter(log => new Date(log.date) >= cutoffDate);

    }

    lineChart.data.labels = filteredLogs.map(log => new Date(log.date).toLocaleDateString());
    lineChart.data.datasets[0].data = filteredLogs.map(log => log.calories);
    lineChart.update();
}

function filterChartData(days){
    updateLineChart(days);
}

function saveData(){
    const dataToSave = {
        weeklyTargets,
        calorieLogs,
        lastLogTime,
        userData: {
            age: document.getElementById("userAge").value,
            gender: document.getElementById("userGender").value,
            height: document.getElementById("userHeight").value,
            weight: document.getElementById("userWeight").value,
            exerciseFrequency: document.getElementById("exerciseFrequency").value,
            targetWeight: document.getElementById("targetWeight").value,
            weightChangePace: document.getElementById("weightChangePace").value
        },
        currentWeek: 1,
        startDate: new Date().toISOString()
    };
    localStorage.setItem("calorieTrackerData", JSON.stringify(dataToSave));
}


async function loadData() {
    try {
        const userId = 1; // Use actual logged-in user ID
        
        // Load from backend
        const response = await fetch(`/api/calories?userId=${userId}`);
        const entries = await response.json();
        
        // Transform to frontend format
        calorieLogs = entries.map(entry => ({
            date: entry.date,
            calories: entry.calories
        }));

        const planResponse = await fetch(`/api/calories/plans?userId=${userId}`);
        const planData = await planResponse.json();
        
        // Load from localStorage as fallback
        const savedData = JSON.parse(localStorage.getItem("calorieTrackerData") || "{}");
        if (document.getElementById("userAge").value &&
            document.getElementById("userGender").value &&
            document.getElementById("userHeight").value &&
            document.getElementById("userWeight").value &&
            document.getElementById("exerciseFrequency").value){
                calculateTDEE();
        }
        
        // Update charts
        if (calorieLogs.length > 0) updateLineChart();
        
    } catch (error) {
        console.error("Loading failed, using localStorage fallback", error);
        // Fallback to localStorage if backend fails
        const savedData = JSON.parse(localStorage.getItem("calorieTrackerData") || "{}");
        calorieLogs = savedData.calorieLogs || [];
        weeklyTargets = savedData.weeklyTargets || [];
        if (calorieLogs.length > 0) updateLineChart();
        if (weeklyTargets.length > 0) updateBarChart();
    }
}