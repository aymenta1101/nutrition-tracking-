document.addEventListener("DOMContentLoaded", function () {
    document.querySelector("form").addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent form from reloading

        let username = document.getElementById("username").value;
        let email = document.getElementById("email").value;
        let password = document.getElementById("password").value;
        let confirmPassword = document.getElementById("confirm-password").value;

        let errorMessage = document.getElementById("error-message");
        let successMessage = document.getElementById("success-message");

        // Client-side Validation
        if (password !== confirmPassword) {
            errorMessage.textContent = "Passwords do not match!";
            errorMessage.style.display = "block";
            successMessage.style.display = "none";
            return;
        }

        if (password.length < 6) {
            errorMessage.textContent = "Password must be at least 6 characters long!";
            errorMessage.style.display = "block";
            successMessage.style.display = "none";
            return;
        }

        // Send Data to Backend using JSON
        fetch("/api/register", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ username, email, password }) // Send as JSON
        })
        .then(response => response.json()) // Convert response to JSON
        .then(data => {
            if (data.success) {
                successMessage.textContent = data.message;
                successMessage.style.display = "block";
                errorMessage.style.display = "none";

                // Redirect to login page after successful registration
                setTimeout(function() {
                    window.location.href = "/login";  // Change this to your login page URL
                }, 2000);  // Wait for 2 seconds before redirect
            } else {
                // If the email is already taken, redirect to the login page
                if (data.message.includes("email already taken")) {
                    errorMessage.textContent = data.message;
                    errorMessage.style.display = "block";
                    successMessage.style.display = "none";

                    // Redirect to login page if email is already taken
                    setTimeout(function() {
                        window.location.href = "/login";  // Change this to your login page URL
                    }, 2000);  // Wait for 2 seconds before redirect
                } else {
                    errorMessage.textContent = data.message || "Registration failed!";
                    errorMessage.style.display = "block";
                    successMessage.style.display = "none";
                }
            }
        })
        .catch(error => {
            errorMessage.textContent = "Error connecting to server!";
            errorMessage.style.display = "block";
            successMessage.style.display = "none";
        });
    });
});
