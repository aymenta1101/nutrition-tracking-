document.addEventListener('DOMContentLoaded', function () {
    const subtract = document.getElementById("sub");
    const addition = document.getElementById("add");

    const habitHome = document.getElementById("Home");
    const indexHome = document.getElementById("home");
    const performanceHome = document.getElementById("home-perf");

    const counterLabel = document.getElementById("Score");
    const editButton = document.getElementById("edit");
    const viewHabit = document.getElementById("View");
    const performance = document.getElementById("perf");
    const createHabit = document.getElementById("create");

    const saveButton = document.getElementById("save");
    const goal = document.getElementById("GoalN");

    let selectedHabit = JSON.parse(localStorage.getItem('selectedHabit')) || null;
    let count = selectedHabit ? selectedHabit.score || 0 : 0;

    if (window.location.pathname.endsWith('habit-tracking.html') && selectedHabit) {
        document.getElementById('displayHabit').textContent = selectedHabit.name;
        document.getElementById('GoalN').textContent = selectedHabit.goal;
        document.getElementById('Score').textContent = count;
    }

    if (addition && counterLabel) {
        addition.onclick = function () {
            count++;
            counterLabel.textContent = count;
        };
    }

    if (subtract && counterLabel) {
        subtract.onclick = function () {
            if (count > 0) {
                count--;
                counterLabel.textContent = count;
            }
        };
    }

    if (viewHabit) {
        viewHabit.onclick = function () {
            window.location.href = "existing-habits.html";
        };
    }

    if (performance) {
        performance.onclick = function () {
            window.location.href = "track-performance.html";
        };
    }

    if (habitHome) {
        habitHome.onclick = function () {
            window.location.href = "index.html";
        };
    }

    if (performanceHome) {
        performanceHome.onclick = function () {
            window.location.href = "index.html";
        };
    }

    if (createHabit) {
        createHabit.onclick = function () {
            window.location.href = "create-habit.html";
        };
    }

    if (indexHome) {
        indexHome.onclick = function () {
            window.location.href = "index.html";
        };
    }

    if (saveButton) {
        saveButton.onclick = function () {
            saveScore();
            window.location.href = "existing-habits.html";
        };
    }

    function saveScore() {
        let selectedHabit = JSON.parse(localStorage.getItem('selectedHabit'));
        if (selectedHabit) {
            let habits = JSON.parse(localStorage.getItem('habits')) || [];
            const habitIndex = habits.findIndex(habit => habit.name === selectedHabit.name);

            selectedHabit.score = count;
            localStorage.setItem('selectedHabit', JSON.stringify(selectedHabit));

            if (habitIndex !== -1) {
                habits[habitIndex].score = count;
                localStorage.setItem('habits', JSON.stringify(habits));
            }
        }
    }

    function saveHabit() {
        const habitName = document.getElementById('habit-name')?.value;
        const targetGoal = document.getElementById('target-goal')?.value;
        const time = document.getElementById('time')?.value;

        if (!habitName || !targetGoal || !time) {
            console.error("Please fill out all fields before saving.");
            return;
        }

        const habit = {
            name: habitName,
            goal: targetGoal,
            time: time,
            score: 0
        };

        let habits = JSON.parse(localStorage.getItem('habits')) || [];
        habits.push(habit);
        localStorage.setItem('habits', JSON.stringify(habits));
        localStorage.setItem('selectedHabit', JSON.stringify(habit));

        window.location.href = 'existing-habits.html';
    }

    function loadHabits() {
        const habits = JSON.parse(localStorage.getItem('habits')) || [];
        const habitsGrid = document.querySelector('.habits-grid');

        if (!habitsGrid) {
            console.error("No habits grid found.");
            return;
        }

        habitsGrid.innerHTML = '';

        habits.forEach((habit, index) => {
            if (habit.score === undefined) habit.score = 0;

            const habitDiv = document.createElement('div');
            habitDiv.id = 'habit';
            habitDiv.innerHTML = `
                <h3>Habit Name: ${habit.name}</h3>
                <h3>Target Goal: ${habit.goal}</h3>
                <h3>Score: ${habit.score}</h3>
                <h3>Time: ${habit.time}</h3>
                <button class="btn" id="edit" data-index="${index}">Edit</button>
            `;
            habitsGrid.appendChild(habitDiv);
        });

        document.querySelectorAll("#edit").forEach(button => {
            button.onclick = function () {
                const index = button.getAttribute('data-index');
                const habits = JSON.parse(localStorage.getItem('habits')) || [];
                const selectedHabit = habits[index];

                localStorage.setItem('selectedHabit', JSON.stringify(selectedHabit));
                window.location.href = "habit-tracking.html";
            };
        });
    }

    if (window.location.pathname.endsWith('existing-habits.html')) {
        loadHabits();
    }

    const createButton = document.getElementById('Create');
    if (createButton) {
        createButton.addEventListener('click', function (event) {
            event.preventDefault();
            saveHabit();
        });
    }
});
document.addEventListener('DOMContentLoaded', function () {
    if (window.location.pathname.endsWith('habit-tracking.html')) {
        const selectedHabit = JSON.parse(localStorage.getItem('selectedHabit'));

        if (selectedHabit) {
            document.getElementById('displayHabit').textContent = selectedHabit.name;
            document.getElementById('GoalN').textContent = selectedHabit.goal;
            document.getElementById('Score').textContent = selectedHabit.score || 0;
        }

        const deleteButton = document.getElementById('delete');
        if (deleteButton) {
            deleteButton.onclick = function () {
                deleteHabit(selectedHabit.name);
            };
        }
    }
});

function deleteHabit(habitName) {
    let habits = JSON.parse(localStorage.getItem('habits')) || [];

    habits = habits.filter(habit => habit.name !== habitName);

    localStorage.setItem('habits', JSON.stringify(habits));

    localStorage.removeItem('selectedHabit');

    window.location.href = 'existing-habits.html';
}